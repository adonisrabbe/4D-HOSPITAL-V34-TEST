> **Historical snapshot — superseded for current release instructions.** This file records an earlier project state. For the current lockfile, workflow, and release-gate status, use `CURRENT_RELEASE_TRUTH_BN.md` and `RELEASE_GATE_REPORT_V3.2_BN.md`.

# 4D Hospital — A-to-Z Final Recheck 2026-09-28

## Advanced Research Laboratory v2
- Evidence Quality, Bayesian, SPRT, Information Theory, higher-order transition/context tree, change-point, null-model, FDR, redundancy graph, stability surface, motif, symbolic discovery, conformal calibration ও meta-evidence যোগ করা হয়েছে।
- Investigator panel-এ Advanced Research Laboratory v2 summary যুক্ত হয়েছে।
- Research Constitution: sample/OOS/FDR/redundancy/null/stability gate চালু হয়েছে।

## নতুনভাবে পাওয়া ও সংশোধিত সমস্যা
1. ResearchCycleView-এর JSX ternary-তে malformed `: {tab==='catalog'?` syntax ছিল; এটি `: tab==='catalog' ?` করে সংশোধন করা হয়েছে।
2. Investigator Research Panel যোগ করা হয়েছে।
3. Local/free Research Investigator engine যোগ করা হয়েছে।
4. Mathematical evidence numeric properties-এর mean/drift semantics বজায় রাখা হয়েছে।
5. Redundancy warnings ও uniform exact-number null reference UI-তে যোগ হয়েছে।

## Static/runtime checks
- 107 engine: PASS
- 28 active signals: PASS
- 6 research layers: PASS
- Research cycle E2E: PASS
- Storage/security audit: PASS
- Mathematical research audit: PASS
- Stability audit: PASS
- Investigator audit: PASS
- 92 TS/TSX files syntax-transpile audit: PASS
- ZIP integrity: PASS
- Advanced Research static audit: PASS
- Advanced Research standalone compile + 250-row runtime smoke test: PASS
- TS/TSX syntax audit: PASS (93 files)

## Environment-only gates
- package-lock.json: এখনও নেই; fake integrity data তৈরি করা হয়নি।
- Full `tsc -p tsconfig.json`: node_modules/type definitions অনুপস্থিত থাকায় environment blocked (`vite/client`).
- Android SDK/Gradle/device: বর্তমান sandbox-এ নেই; APK/device E2E তাই certify করা হয়নি।
- Fully bundled offline OCR on a real Android build: এখনও device/build gate।

## Free policy
Paid API, paid subscription, paid backend বাধ্যতামূলক করা হয়নি।
