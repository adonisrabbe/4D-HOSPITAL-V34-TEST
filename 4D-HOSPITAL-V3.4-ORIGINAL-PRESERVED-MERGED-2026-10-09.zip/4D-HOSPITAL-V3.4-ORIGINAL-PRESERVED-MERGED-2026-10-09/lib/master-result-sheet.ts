import { buildFinalResultReport, type FinalCandidate, type FinalKind } from './final-result-engine';
import { ACTIVE_SIGNAL_CATALOG } from './scorer';
import type { CanonicalDraw } from './canonical-data';

/**
 * Master Result Sheet v2
 *
 * The Master Result is the final research aggregation surface. It is deliberately
 * downstream of the complete pipeline: 107 analyses -> 11 Parts -> 28 signal
 * families -> Mathematical -> Investigator -> Advanced/Scientific/Validation ->
 * Evidence Fusion. It ranks evidence; it does not claim future certainty.
 */
export const MASTER_RESULT_VERSION = 'master-result-sheet-v2.0';
export type MasterBand = 'HOT'|'COLD'|'STABLE'|'EMERGING'|'DECLINING'|'CONSENSUS'|'CONFLICT'|'HIGH_EVIDENCE'|'MEDIUM_EVIDENCE'|'LOW_EVIDENCE';
export type MasterLevel = '5D'|'4D'|'3D'|'2D'|'1D';
export interface MasterSheetCandidate {
  level: MasterLevel;
  set: number;
  band: MasterBand;
  value: string;
  score: number;
  count: number;
  source: string;
  evidence: string;
  consensus: number;
  conflict: number;
  warning?: string;
}
export interface MasterSensorSnapshot {
  name: string;
  status: 'READY'|'LIMITED'|'BLOCKED';
  detail: string;
}
export interface MasterResearchBundle {
  rank:number;
  band:MasterBand;
  fiveD:string;
  fourD:string;
  threeD:string;
  twoD:string;
  oneD:string;
  score:number;
  consensus:number;
  conflict:number;
  evidence:string;
  source:string;
  sensorProfile?: {core107:number;signals28:number;mathematics:number;investigator:number;advanced:number;scientific:number;validation:number};
}
export interface MasterResultSheet {
  version: string;
  levels: {'5D':MasterSheetCandidate[];'4D':MasterSheetCandidate[];'3D':MasterSheetCandidate[];'2D':MasterSheetCandidate[];'1D':MasterSheetCandidate[]};
  requestedSets: {'5D':5;'4D':4;'3D':4;'2D':4;'1D':4};
  coverage: {analysis107:number;parts11:number;modules28:number};
  traceability: {datasetFingerprint:string;calculationVersion:string;fusionVersion:string};
  sensorSummary: {activeModules:number;support:number;conflict:number;insufficient:number;readyLayers:number;limitedLayers:number;blockedLayers:number};
  sensors: MasterSensorSnapshot[];
  researchSets10: MasterResearchBundle[];
  boundary: string[];
}

const warning = 'Historical research evidence only; not a future-outcome or winning-probability guarantee.';
const unique = <T,>(xs:T[], key:(x:T)=>string):T[] => {
  const seen = new Set<string>();
  const out:T[]=[];
  for(const x of xs){const k=key(x); if(seen.has(k)) continue; seen.add(k); out.push(x);}
  return out;
};

function candidateScore(x:FinalCandidate):number { return Number((x.score ?? 0).toFixed(1)); }
function toMaster(level:MasterLevel, band:MasterBand, x:FinalCandidate, set:number, sourceSuffix=''):MasterSheetCandidate {
  const e=x.evidence;
  const consensus=Math.max(0, Math.min(28, e?.sensors?.signals28 ?? 0));
  const conflicts=Math.max(0, Math.round(e?.conflictLayers ?? 0));
  const evidenceLabel=e?.disposition==='TAKE'?'HIGH EVIDENCE':e?.disposition==='WATCH'?'MEDIUM EVIDENCE':e?.disposition==='DROP'?'CONFLICT / LOW EVIDENCE':'INSUFFICIENT DATA';
  return {level,set,band,value:x.value,score:candidateScore(x),count:x.count,source:`${x.source}${sourceSuffix}`,evidence:evidenceLabel,consensus,conflict:conflicts,warning};
}

function splitHotCold(kindHot:FinalKind, kindCold:FinalKind, report:ReturnType<typeof buildFinalResultReport>, level:MasterLevel, total:number):MasterSheetCandidate[] {
  const hot=(report.findings[kindHot]??[]).map((x,i)=>toMaster(level,'HOT',x,i+1));
  const cold=(report.findings[kindCold]??[]).map((x,i)=>toMaster(level,'COLD',x,i+1));
  // Keep the user's requested total while guaranteeing both evidence lanes when data permits.
  const hotN=Math.ceil(total/2), coldN=total-hotN;
  const selected=unique([...hot.slice(0,hotN),...cold.slice(0,coldN)],x=>x.value);
  if(selected.length<total) selected.push(...unique([...hot,...cold],x=>x.value).filter(x=>!selected.some(y=>y.value===x.value)).slice(0,total-selected.length));
  return selected.slice(0,total).map((x,i)=>({...x,set:i+1}));
}

function digitStats(rows:CanonicalDraw[]) {
  const hot=Array(10).fill(0) as number[];
  const recent=Array(10).fill(0) as number[];
  const ordered=[...rows].sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id);
  for(const r of ordered){
    for(const field of [r.first,r.second,r.third]){
      if(!/^\d{4}$/.test(field)) continue;
      for(const ch of field) hot[Number(ch)]++;
    }
  }
  const tail=ordered.slice(Math.max(0,ordered.length-50));
  for(const r of tail){
    for(const field of [r.first,r.second,r.third]){
      if(!/^\d{4}$/.test(field)) continue;
      for(const ch of field) recent[Number(ch)]++;
    }
  }
  return {hot,recent};
}


function buildResearchSets10(rows:CanonicalDraw[], report:ReturnType<typeof buildFinalResultReport>):MasterResearchBundle[] {
  const observed = Array.from(new Set(rows.flatMap(r => [r.first,r.second,r.third,...(r.special??[]),...(r.consolation??[])].filter(v => /^\d{4}$/.test(v)))));
  const fusion = report.fusion;
  const frequencyMap = new Map<string, number>();
  for(const r of rows){
    for(const v of [r.first,r.second,r.third,...(r.special??[]),...(r.consolation??[])]){
      if(/^\d{4}$/.test(v)) frequencyMap.set(v,(frequencyMap.get(v)??0)+1);
    }
  }
  const scored = observed.map(value => {
    const e = fusion.candidates[value];
    const frequency = frequencyMap.get(value)??0;
    const score = Number(((e?.score ?? 0) * 0.8 + Math.min(100, frequency * 4) * 0.2).toFixed(1));
    const band:MasterBand = e?.disposition === 'TAKE' ? 'HOT' : e?.disposition === 'DROP' ? 'COLD' : 'STABLE';
    return {value, score, band, e, frequency};
  }).sort((a,b)=>b.score-a.score||b.frequency-a.frequency||a.value.localeCompare(b.value)).slice(0,10);
  const digitCounts=Array(10).fill(0) as number[];
  for(const r of rows) for(const v of [r.first,r.second,r.third]) if(/^\d{4}$/.test(v)) for(const ch of v) digitCounts[Number(ch)]++;
  const digitRank=[...Array(10).keys()].sort((a,b)=>digitCounts[b]-digitCounts[a]||a-b);
  return scored.map((x,i)=>{
    const four=x.value;
    const bestDigit=String(digitRank[i%digitRank.length] ?? four[0]);
    const trip=four.slice(0,3);
    const pair=four.slice(0,2);
    const single=four.split('').sort((a,b)=>digitCounts[Number(b)]-digitCounts[Number(a)]||Number(a)-Number(b))[0] ?? four[0];
    const e=x.e;
    return {
      rank:i+1, band:x.band, fiveD:`${bestDigit}${four}`, fourD:four, threeD:trip, twoD:pair, oneD:single,
      score:x.score, consensus:Math.max(0,Math.min(28,e?.sensors?.signals28??0)), conflict:Math.max(0,Math.round(e?.conflictLayers??0)),
      evidence:e?.disposition==='TAKE'?'HIGH EVIDENCE':e?.disposition==='WATCH'?'MEDIUM EVIDENCE':e?.disposition==='DROP'?'CONFLICT / LOW EVIDENCE':'INSUFFICIENT DATA',
      source:'10-set research bundle: full historical 4D candidate pool + 107/28 evidence fusion; 5D/3D/2D/1D are derived views of the same evidence-ranked bundle.',
      sensorProfile:e?.sensors ? {...e.sensors} : undefined
    };
  });
}

function derive5D(rows:CanonicalDraw[], report:ReturnType<typeof buildFinalResultReport>):MasterSheetCandidate[] {
  const {hot,recent}=digitStats(rows);
  const digits=[...Array(10).keys()].sort((a,b)=>hot[b]-hot[a]||recent[b]-recent[a]||a-b);
  const coldDigits=[...Array(10).keys()].sort((a,b)=>recent[a]-recent[b]||hot[a]-hot[b]||a-b);
  const four=unique([...report.findings.HOT_4D,...report.findings.COOL_4D],x=>x.value).slice(0,12);
  const pool:Array<{value:string;score:number;band:MasterBand;source:string;count:number;consensus:number;conflict:number}> = [];
  const digitPool=unique([...digits.slice(0,5),...coldDigits.slice(0,5)],x=>String(x));
  for(const x of four){
    for(const d of digitPool){
      const hotRank=digits.indexOf(d), coldRank=coldDigits.indexOf(d);
      const hotDigit=hotRank>=0 && hotRank<5;
      const rank=hotDigit?hotRank:coldRank;
      const digitScore=Math.max(0,100-rank*9);
      const score=Math.max(0,Math.min(100,x.score*.70+digitScore*.30));
      pool.push({
        value:`${d}${x.value}`,
        score,
        band:hotDigit?'HOT':'COLD',
        source:`Derived composite: digit sensor (${hotDigit?'HOT':'COLD'} digit evidence) + observed 4D candidate ${x.value}`,
        count:x.count,
        consensus:x.evidence?.sensors?.signals28??0,
        conflict:x.evidence?.conflictLayers??0
      });
    }
  }
  const ranked=unique(pool,x=>x.value).sort((a,b)=>b.score-a.score||b.consensus-a.consensus||a.conflict-b.conflict).slice(0,5);
  return ranked.map((x,i)=>({level:'5D',set:i+1,band:x.band,value:x.value,score:Number(x.score.toFixed(1)),count:x.count,source:x.source,evidence:x.score>=70?'HIGH EVIDENCE':x.score>=45?'MEDIUM EVIDENCE':'LOW EVIDENCE',consensus:x.consensus,conflict:x.conflict,warning:'5D is a derived composite from observed 4D + digit evidence; it is not an observed historical 5D outcome.'}));
}

export function buildMasterResultSheet(input:CanonicalDraw[]):MasterResultSheet {
  const report=buildFinalResultReport(input);
  const levels={
    '5D':derive5D(input,report),
    '4D':splitHotCold('HOT_4D','COOL_4D',report,'4D',4),
    '3D':splitHotCold('HOT_3D','COOL_3D',report,'3D',4),
    '2D':splitHotCold('HOT_PAIR','COOL_PAIR',report,'2D',4),
    '1D':splitHotCold('HOT_SINGLE','COOL_SINGLE',report,'1D',4),
  } as MasterResultSheet['levels'];
  const layers=report.fusion.layerSummary;
  const readyLayers=layers.filter(x=>x.status==='READY').length;
  const limitedLayers=layers.filter(x=>x.status==='LIMITED').length;
  const blockedLayers=layers.filter(x=>x.status==='BLOCKED').length;
  const support=report.analysis.support, conflict=report.analysis.conflict, insufficient=report.analysis.insufficient;
  return {
    version:MASTER_RESULT_VERSION,
    levels,
    requestedSets:{'5D':5,'4D':4,'3D':4,'2D':4,'1D':4},
    coverage:{analysis107:report.analysis.total,parts11:11,modules28:ACTIVE_SIGNAL_CATALOG.length},
    traceability:{datasetFingerprint:report.dataset.fingerprint,calculationVersion:report.analysis.calculationVersion,fusionVersion:report.fusion.version},
    sensorSummary:{activeModules:ACTIVE_SIGNAL_CATALOG.length,support,conflict,insufficient,readyLayers,limitedLayers,blockedLayers},
    sensors:layers.map(x=>({name:x.layer,status:x.status as 'READY'|'LIMITED'|'BLOCKED',detail:x.detail})),
    researchSets10:buildResearchSets10(input,report),
    boundary:[
      'Master Result is an evidence-ranking surface built from the full research pipeline; it is not a guaranteed future prediction.',
      '5D is a derived composite from observed 4D and digit evidence; historical 5D observations are not assumed.',
      'HOT and COLD are separate evidence lanes; COLD means lower/recently absent historical signal, not a promise of reversal.',
      'Consensus and conflict remain visible. Missing/limited sensors reduce evidence quality rather than being silently promoted to certainty.',
      'Every candidate carries dataset fingerprint, calculation version, source layer, evidence state, consensus and conflict counts.'
    ]
  };
}
