/**
 * 4D HOSPITAL — Master Evidence Fusion / Sensor Layer
 *
 * This is the arbitration boundary for the final result. It does not invent
 * numbers. It combines independent-ish evidence families, keeps redundancy
 * visible, and exposes support/contradiction instead of treating every module
 * as an independent vote.
 */
import { run107Analysis, type Analysis107Result } from './analysis-engine-107';
import { buildInvestigatorReport } from './investigator';
import { buildScientificCoreV3 } from './scientific-core-v3';
import { runPatternEngine, type DrawEntry, type EngineAnalysis } from './scorer';
import { analyzeMathEvidence } from './number-theory-lab';
import type { CanonicalDraw } from './canonical-data';

export type SensorDisposition = 'TAKE'|'WATCH'|'DROP'|'INSUFFICIENT_DATA';
export interface SensorLayerEvidence { layer:string; status:'SUPPORT'|'NEUTRAL'|'CONFLICT'|'INSUFFICIENT'; strength:number; detail:string; }
export interface MasterCandidateEvidence {
  value:string; score:number; disposition:SensorDisposition;
  supportLayers:number; conflictLayers:number; neutralLayers:number;
  sensors:{core107:number; signals28:number; mathematics:number; investigator:number; advanced:number; scientific:number; validation:number};
  layers:SensorLayerEvidence[];
  reasons:string[]; warnings:string[];
}
export interface MasterEvidenceFusionReport {
  version:'master-fusion-sensor-v2';
  dataset:{records:number;valid4D:number};
  engineCoverage:{core107:number;signals28:number;mathProperties:number;investigatorFindings:number;advancedTests:number};
  scientific:{status:string;failureRisk:string;gates:number};
  candidates:Record<string,MasterCandidateEvidence>;
  layerSummary:{layer:string;status:'READY'|'LIMITED'|'BLOCKED';detail:string}[];
}

const clamp=(x:number,a=0,b=100)=>Math.max(a,Math.min(b,x));
const status=(x:number,lo=40,hi=65):SensorLayerEvidence['status']=>x>=hi?'SUPPORT':x<=lo?'CONFLICT':'NEUTRAL';
const toDraw=(r:CanonicalDraw):DrawEntry=>({first:r.first,second:r.second,third:r.third,special:r.special??[],consolation:r.consolation??[],date:r.date});

type StructuralProfile = {
  n:number;
  pos:number[][];
  sums:number[];
  patterns:Record<string,number>;
  residues:Record<number,number[]>;
  observedPairs:Map<string,number>;
  observedTrips:Map<string,number>;
  observedPerm:Map<string,number>;
  digits:number[];
  globalGate:number;
};

function structuralPattern(d:string):string {
  return d[0]===d[1]&&d[1]===d[2]&&d[2]===d[3]?'AAAA':
    new Set(d).size===2&&d[0]===d[1]&&d[2]===d[3]&&d[0]!==d[2]?'AABB':
    new Set(d).size===2&&d[0]===d[2]&&d[1]===d[3]&&d[0]!==d[1]?'ABAB':
    new Set(d).size===2&&d[0]===d[3]&&d[1]===d[2]&&d[0]!==d[1]?'ABBA':
    new Set(d).size===4?'ABCD':'AABC';
}

function buildStructuralProfile(rows:CanonicalDraw[], coreResults:Analysis107Result[]):StructuralProfile {
  const valid=rows.filter(r=>/^\d{4}$/.test(r.first));
  const pos=Array.from({length:4},()=>Array(10).fill(0) as number[]);
  const sums=Array(37).fill(0) as number[];
  const patterns:Record<string,number>={};
  const residues:Record<number,number[]>={};
  for(const m of [2,3,4,5,7,9,10,11]) residues[m]=Array(m).fill(0);
  const observedPairs=new Map<string,number>(), observedTrips=new Map<string,number>(), observedPerm=new Map<string,number>();
  const digits=Array(10).fill(0) as number[];
  for(const r of valid){
    const d=r.first.split('');
    d.forEach((ch,i)=>{pos[i][Number(ch)]++;digits[Number(ch)]++;});
    const sum=d.reduce((a,x)=>a+Number(x),0); sums[sum]++;
    const pat=structuralPattern(r.first); patterns[pat]=(patterns[pat]??0)+1;
    for(const m of [2,3,4,5,7,9,10,11]) residues[m][Number(r.first)%m]++;
    for(const [a,b] of [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]){
      const k=d[a]+d[b]; observedPairs.set(k,(observedPairs.get(k)??0)+1);
    }
    for(const [a,b,c] of [[0,1,2],[0,1,3],[0,2,3],[1,2,3]]){
      const k=d[a]+d[b]+d[c]; observedTrips.set(k,(observedTrips.get(k)??0)+1);
    }
    const k=d.slice().sort().join(''); observedPerm.set(k,(observedPerm.get(k)??0)+1);
  }
  const n=valid.length;
  const available=coreResults.filter(x=>x.applicable).length;
  const globalSupport=available?coreResults.filter(x=>x.evidence==='SUPPORT').length/available:0;
  const globalConflict=available?coreResults.filter(x=>x.evidence==='CONFLICT').length/available:0;
  const globalGate=Math.max(0,Math.min(1,0.5+0.5*globalSupport-0.5*globalConflict));
  return {n,pos,sums,patterns,residues,observedPairs,observedTrips,observedPerm,digits,globalGate};
}

function candidate107StructuralScore(value:string, profile:StructuralProfile):number {
  if(!/^\d{4}$/.test(value) || !profile.n) return 0;
  const n=profile.n;
  const posScore=value.split('').reduce((s,ch,i)=>s+profile.pos[i][Number(ch)]/n,0)/4;
  const digitScore=value.split('').reduce((s,ch)=>s+profile.digits[Number(ch)]/(n*4),0)/4;
  const sum=Number(value.split('').reduce((a,x)=>a+Number(x),0));
  const sumScore=Math.min(1,(profile.sums[sum]??0)/n*10);
  const pat=structuralPattern(value);
  const patternScore=Math.min(1,(profile.patterns[pat]??0)/n*10);
  const residueScore=[2,3,4,5,7,9,10,11].reduce((a,m)=>a+(profile.residues[m]?.[Number(value)%m]??0)/n,0)/8;
  const pairKeys=[value[0]+value[1],value[0]+value[2],value[0]+value[3],value[1]+value[2],value[1]+value[3],value[2]+value[3]];
  const pairScore=Math.min(1,pairKeys.reduce((s,k)=>s+(profile.observedPairs.get(k)??0),0)/Math.max(1,n*6)*4);
  const tripKeys=[value.slice(0,3),value.slice(0,2)+value[3],value[0]+value.slice(2),value.slice(1)];
  const tripScore=Math.min(1,tripKeys.reduce((s,k)=>s+(profile.observedTrips.get(k)??0),0)/Math.max(1,n*4)*4);
  const permScore=Math.min(1,(profile.observedPerm.get(value.split('').sort().join(''))??0)/n*10);
  return Math.round(Math.max(0,Math.min(100,(0.18*posScore+0.14*digitScore+0.10*sumScore+0.10*patternScore+0.12*residueScore+0.12*pairScore+0.08*tripScore+0.06*permScore+0.10*profile.globalGate)*100))*10)/10;
}

export function buildMasterEvidenceFusion(rows:CanonicalDraw[], candidateValues?:string[], precomputedCore?:Analysis107Result[]):MasterEvidenceFusionReport {
  const ordered=[...rows].filter(r=>/^\d{4}$/.test(r.first)).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id);
  const core={analyses107:precomputedCore??run107Analysis(ordered)};
  const structuralProfile=buildStructuralProfile(ordered,core.analyses107);
  const candidateUniverse=[...new Set((candidateValues?.filter(x=>/^\d{4}$/.test(x)) ?? ordered.map(r=>r.first)))];
  const signal=runPatternEngine(ordered.map(toDraw),200,{useAdaptive:false,lightweight:true,candidateValues:candidateUniverse});
  const investigator=buildInvestigatorReport(ordered);
  const nums=ordered.map(r=>r.first).filter(x=>/^\d{4}$/.test(x));
  const math=analyzeMathEvidence(nums);
  const scientific=buildScientificCoreV3(nums);
  const wanted=candidateValues?.filter(x=>/^\d{4}$/.test(x)) ?? signal.scores.slice(0,40).map(x=>x.num);
  const unique=[...new Set(wanted)];
  const signalMap=new Map(signal.scores.map(x=>[x.num,x]));
  const candidateMap:Record<string,MasterCandidateEvidence>={};
  for(const value of unique){
    const s=signalMap.get(value);
    const signalScore=s?.confidence??0;
    const strong=s?.signalsAgreed??0;
    const signalEvidence=clamp(signalScore);
    const analysis107Candidate=candidate107StructuralScore(value,structuralProfile);
    const mathStable=math.filter(x=>x.status==='STABLE').length;
    const mathDrift=math.filter(x=>x.status==='DRIFT').length;
    const mathScore=clamp(50 + (mathStable-mathDrift)*4 + (investigator.digitEntropy>0?5:0));
    const invAlerts=investigator.findings.filter(x=>x.severity==='ALERT').length;
    const invWatch=investigator.findings.filter(x=>x.severity==='WATCH').length;
    const invScore=clamp(72-invAlerts*15-invWatch*5);
    const fdrReady=investigator.advancedResearch.globalFdr.length>0;
    const advScore=clamp((fdrReady?68:48)+(investigator.advancedResearch.redundancy.length>0?-8:0));
    const validationScore=clamp(50 + (signal.backtest.exact4DRate*.35) + (signal.backtest.anyDigitRate*.2));
    const sciScore=scientific.profile.overallStatus==='SUPPORTED'?82:scientific.profile.overallStatus==='WEAK_SUPPORT'?62:scientific.profile.overallStatus==='CONFLICT'?38:scientific.profile.overallStatus==='INSUFFICIENT_DATA'?25:50;
    const sensors={core107:analysis107Candidate,signals28:signalEvidence,mathematics:mathScore,investigator:invScore,advanced:advScore,scientific:sciScore,validation:validationScore};
    const layers:SensorLayerEvidence[]=[
      {layer:'107 Core',status:status(sensors.core107),strength:sensors.core107,detail:`candidate structural relevance from 107-core + global 107 evidence gate; ${core.analyses107.length}/107 analyses executed`},
      {layer:'28 Signals',status:status(sensors.signals28),strength:sensors.signals28,detail:`${strong}/${28} signal families materially aligned`},
      {layer:'Mathematical',status:status(sensors.mathematics),strength:sensors.mathematics,detail:`${mathStable} stable / ${mathDrift} drift properties`},
      {layer:'Investigator',status:status(sensors.investigator),strength:sensors.investigator,detail:`${invAlerts} alert / ${invWatch} watch findings`},
      {layer:'Advanced Research',status:status(sensors.advanced),strength:sensors.advanced,detail:`FDR ${fdrReady?'available':'limited'}; redundancy edges ${investigator.advancedResearch.redundancy.length}`},
      {layer:'Scientific Core',status:status(sensors.scientific),strength:sensors.scientific,detail:`${scientific.profile.overallStatus}; failure risk ${scientific.failureIntelligence.riskLevel}`},
      {layer:'Validation/OOS',status:status(sensors.validation),strength:sensors.validation,detail:`exact-4D backtest ${signal.backtest.exact4DRate}% / partial-digit ${signal.backtest.anyDigitRate}%`},
    ];
    const support=layers.filter(x=>x.status==='SUPPORT').length, conflict=layers.filter(x=>x.status==='CONFLICT').length;
    const score=clamp(layers.reduce((a,x)=>a+x.strength,0)/layers.length - conflict*7);
    const disposition:SensorDisposition=ordered.length<30?'INSUFFICIENT_DATA':score>=68&&conflict<=1?'TAKE':score<=42||conflict>=4?'DROP':'WATCH';
    const reasons:string[]=[]; const warnings:string[]=[];
    if(support) reasons.push(`${support} evidence families support this candidate.`);
    if(strong>=14) reasons.push('Broad 28-signal agreement is present.');
    if(conflict) warnings.push(`${conflict} evidence families conflict; consensus is not treated as proof.`);
    if(investigator.advancedResearch.redundancy.length) warnings.push('Some research features are mathematically/redundantly related; duplicate votes are not counted independently.');
    if(scientific.gates.some(g=>g.status==='BLOCK')) warnings.push('A scientific process gate is blocked; promotion is restricted.');
    candidateMap[value]={value,score:Number(score.toFixed(1)),disposition,supportLayers:support,conflictLayers:conflict,neutralLayers:layers.length-support-conflict,sensors:Object.fromEntries(Object.entries(sensors).map(([k,v])=>[k,Number(v.toFixed(1))])) as MasterCandidateEvidence['sensors'],layers,reasons,warnings};
  }
  return {version:'master-fusion-sensor-v2',dataset:{records:rows.length,valid4D:ordered.length},engineCoverage:{core107:core.analyses107.length,signals28:28,mathProperties:math.length,investigatorFindings:investigator.findings.length,advancedTests:investigator.advancedResearch.globalFdr.length+Object.keys(investigator.advancedResearch.nullTests).length},scientific:{status:scientific.profile.overallStatus,failureRisk:scientific.failureIntelligence.riskLevel,gates:scientific.gates.length},candidates:candidateMap,layerSummary:[
    {layer:'107 Core Analysis',status:'READY',detail:`${core.analyses107.length} analyses`},
    {layer:'28 Signal Sensor',status:ordered.length>=5?'READY':'LIMITED',detail:'candidate-level signal ranking + reliability/backtest'},
    {layer:'Mathematical',status:math.length?'READY':'LIMITED',detail:`${math.length} mathematical properties`},
    {layer:'Investigator',status:investigator.findings.length?'READY':'LIMITED',detail:`${investigator.findings.length} investigator findings`},
    {layer:'Advanced Research / FDR',status:investigator.advancedResearch.globalFdr.length?'READY':'LIMITED',detail:`${investigator.advancedResearch.globalFdr.length} global FDR families`},
    {layer:'Scientific Process Control',status:scientific.gates.some(g=>g.status==='BLOCK')?'BLOCKED':'READY',detail:scientific.profile.overallStatus},
  ]};
}
