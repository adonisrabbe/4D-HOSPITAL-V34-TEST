/** Deterministic dataset fingerprint used to verify durable storage and backups. */
export interface DatasetIntegrity {
  count: number;
  fingerprint: string;
}

export function datasetFingerprint<T>(rows: T[]): string {
  const text = JSON.stringify(rows);
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return `4dh-${(h >>> 0).toString(16).padStart(8, '0')}`;
}

export function datasetIntegrity<T>(rows: T[]): DatasetIntegrity {
  return { count: rows.length, fingerprint: datasetFingerprint(rows) };
}
