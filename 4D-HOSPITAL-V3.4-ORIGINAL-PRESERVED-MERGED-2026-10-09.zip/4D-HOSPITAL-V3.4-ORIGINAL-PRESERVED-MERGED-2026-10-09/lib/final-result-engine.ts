import { buildMasterEvidenceFusion, type MasterCandidateEvidence } from './master-evidence-fusion';
import { run107Analysis } from './analysis-engine-107';
import { buildAdvancedResearchReport } from './advanced-research-lab';
import { isCanonicalDraw, type CanonicalDraw } from './canonical-data';

export type FinalKind = 'HOT_4D'|'COOL_4D'|'PAIR'|'HOT_PAIR'|'COOL_PAIR'|'SINGLE'|'HOT_SINGLE'|'COOL_SINGLE'|'HOT_3D'|'COOL_3D';
export type FinalDecision = 'SUPPORTED'|'WEAK'|'CONFLICTED'|'INSUFFICIENT_DATA'|'REJECTED';
export interface FinalCandidate {
  id:string; kind:FinalKind; set:1|2|3|4; value:string; count:number; total:number; share:number; recency:number; score:number; decision:FinalDecision; lastSeen:string|null; source:string;
  evidence?: MasterCandidateEvidence;
}
export interface FinalResultReport {
  dataset:{records:number;validRecords:number;fingerprint:string;oldest:string|null;newest:string|null};
  analysis:{total:number;applicable:number;support:number;neutral:number;conflict:number;insufficient:number;coverage:number;calculationVersion:string};
  validation:{dataIntegrity:boolean;duplicateCount:number;chronological:boolean;oosAvailable:boolean;fdrChecked:boolean;mathChecked:boolean};
  fusion:{version:string;layerSummary:MasterResultLayer[];coverage:{core107:number;signals28:number;mathProperties:number;investigatorFindings:number;advancedTests:number};candidates:Record<string,MasterCandidateEvidence>};
  findings:Record<FinalKind,FinalCandidate[]>;
  notes:string[];
}
export interface MasterResultLayer{layer:string;status:string;detail:string}
const clamp=(x:number,min=0,max=100)=>Math.max(min,Math.min(max,x));
const valid4=(x:unknown):x is string=>/^\d{4}$/.test(String(x??''));
function fingerprint(rows:CanonicalDraw[]):string{let h=0x811c9dc5;const text=JSON.stringify(rows.map(r=>[r.id,r.company,r.date,r.drawNo,r.first,r.second,r.third,r.special,r.consolation]));for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,0x01000193)}return `fr2-${(h>>>0).toString(16).padStart(8,'0')}`;}
function allNumbers(rows:CanonicalDraw[]):Array<{value:string;date:string;field:string;company:string}>{const out:Array<{value:string;date:string;field:string;company:string}>=[];for(const r of rows){for(const field of ['first','second','third'] as const)if(valid4(r[field]))out.push({value:r[field],date:r.date,field,company:r.company});for(const value of r.special??[])if(valid4(value))out.push({value,date:r.date,field:'special',company:r.company});for(const value of r.consolation??[])if(valid4(value))out.push({value,date:r.date,field:'consolation',company:r.company});}return out;}
function frequencyMap(values:string[]):Map<string,number>{const m=new Map<string,number>();for(const v of values)m.set(v,(m.get(v)??0)+1);return m;}
function lastSeenMap(items:Array<{value:string;date:string}>):Map<string,string>{const m=new Map<string,string>();for(const x of items){const p=m.get(x.value);if(!p||x.date>p)m.set(x.value,x.date)}return m;}
function recentScore(last:string|null,newest:string|null):number{if(!last||!newest)return 0;const a=Date.parse(last),b=Date.parse(newest);if(!Number.isFinite(a)||!Number.isFinite(b)||b<a)return 0;return Math.exp(-Math.max(0,(b-a)/86400000)/90)*100;}
function decision(e:MasterCandidateEvidence|undefined,count:number):FinalDecision{if(count<=0||!e)return 'INSUFFICIENT_DATA';if(e.disposition==='TAKE')return 'SUPPORTED';if(e.disposition==='DROP')return e.score<35?'REJECTED':'CONFLICTED';return e.disposition==='INSUFFICIENT_DATA'?'INSUFFICIENT_DATA':'WEAK';}
function candidate(id:string,kind:FinalKind,set:number,value:string,count:number,total:number,lastSeen:string|null,e?:MasterCandidateEvidence):FinalCandidate{return{id,kind,set:set as 1|2|3|4,value,count,total,share:total?count/total:0,recency:0,score:Number((e?.score??0).toFixed(1)),decision:decision(e,count),lastSeen,source:'Master Evidence Fusion: 107 + 28 + Mathematical + Investigator + Advanced + Scientific/Validation',evidence:e};}
function rank(kind:FinalKind,items:FinalCandidate[]):FinalCandidate[]{const high=kind.startsWith('HOT')||kind==='PAIR'||kind==='SINGLE';const sorted=[...items].sort((a,b)=>(high?b.score-a.score:a.score-b.score)||b.count-a.count||a.value.localeCompare(b.value)).slice(0,4);return sorted.map((x,i)=>({...x,id:`F-${kind}-${String(i+1).padStart(2,'0')}`,kind,set:(i+1) as 1|2|3|4}));}
function aggregateItems(kind:FinalKind, groups:Map<string, {digits:Set<string>; count:number; total:number; lastSeen:string|null; evidence:MasterCandidateEvidence|undefined}>):FinalCandidate[]{const vals=[...groups.entries()].map(([value,x])=>candidate(`tmp-${value}`,kind,1,value,x.count,x.total,x.lastSeen,x.evidence));return vals;}
export function buildFinalResultReport(input:CanonicalDraw[]):FinalResultReport{
  const rows=input.filter(isCanonicalDraw).sort((a,b)=>a.date.localeCompare(b.date)||a.company.localeCompare(b.company)||a.id-b.id);
  const analysisRaw=run107Analysis(rows);const applicable=analysisRaw.filter(x=>x.applicable);const support=applicable.filter(x=>x.evidence==='SUPPORT').length;const neutral=applicable.filter(x=>x.evidence==='NEUTRAL').length;const conflict=applicable.filter(x=>x.evidence==='CONFLICT').length;const insufficient=analysisRaw.filter(x=>x.evidence==='INSUFFICIENT_DATA').length;
  const analysis={total:analysisRaw.length,applicable:applicable.length,support,neutral,conflict,insufficient,coverage:analysisRaw.length?applicable.length/analysisRaw.length:0,calculationVersion:'MASTER-FUSION-SENSOR-v2'};
  const nums=allNumbers(rows), newest=rows.at(-1)?.date??null, oldest=rows[0]?.date??null, numberValues=nums.map(x=>x.value), freq=frequencyMap(numberValues), last=lastSeenMap(nums.map(x=>({value:x.value,date:x.date})));
  const uniqueObserved=[...freq.keys()];
  const fusion=buildMasterEvidenceFusion(rows,uniqueObserved,analysisRaw);
  const four=uniqueObserved.map(value=>candidate(`tmp-${value}`,'HOT_4D',1,value,freq.get(value)??0,numberValues.length,last.get(value)??null,fusion.candidates[value]));
  const pairGroups=new Map<string,{digits:Set<string>;count:number;total:number;lastSeen:string|null;evidence:MasterCandidateEvidence|undefined}>();
  const tripGroups=new Map<string,{digits:Set<string>;count:number;total:number;lastSeen:string|null;evidence:MasterCandidateEvidence|undefined}>();
  const singleGroups=new Map<string,{digits:Set<string>;count:number;total:number;lastSeen:string|null;evidence:MasterCandidateEvidence|undefined}>();
  for(const x of four){const d=x.value;for(let i=0;i<3;i++){const k=d.slice(i,i+2),g=pairGroups.get(k)||{digits:new Set(),count:0,total:0,lastSeen:null,evidence:undefined};g.count+=x.count;g.total+=numberValues.length;g.lastSeen=!g.lastSeen||String(x.lastSeen??'')>g.lastSeen?x.lastSeen:g.lastSeen;g.evidence=fusion.candidates[[...uniqueObserved].find(v=>v.includes(k))??'']??g.evidence;pairGroups.set(k,g)}for(let i=0;i<2;i++){const k=d.slice(i,i+3),g=tripGroups.get(k)||{digits:new Set(),count:0,total:0,lastSeen:null,evidence:undefined};g.count+=x.count;g.total+=numberValues.length;g.lastSeen=!g.lastSeen||String(x.lastSeen??'')>g.lastSeen?x.lastSeen:g.lastSeen;g.evidence=x.evidence??g.evidence;tripGroups.set(k,g)}for(const ch of d){const g=singleGroups.get(ch)||{digits:new Set(),count:0,total:0,lastSeen:null,evidence:undefined};g.count+=x.count;g.total+=numberValues.length;g.lastSeen=!g.lastSeen||String(x.lastSeen??'')>g.lastSeen?x.lastSeen:g.lastSeen;g.evidence=x.evidence??g.evidence;singleGroups.set(ch,g)}}
  const pair=aggregateItems('PAIR',pairGroups), hotPair=aggregateItems('HOT_PAIR',pairGroups), coolPair=aggregateItems('COOL_PAIR',pairGroups), single=aggregateItems('SINGLE',singleGroups), hotSingle=aggregateItems('HOT_SINGLE',singleGroups), coolSingle=aggregateItems('COOL_SINGLE',singleGroups), hot3=aggregateItems('HOT_3D',tripGroups), cool3=aggregateItems('COOL_3D',tripGroups);
  const findings={HOT_4D:rank('HOT_4D',four),COOL_4D:rank('COOL_4D',four),PAIR:rank('PAIR',pair),HOT_PAIR:rank('HOT_PAIR',hotPair),COOL_PAIR:rank('COOL_PAIR',coolPair),SINGLE:rank('SINGLE',single),HOT_SINGLE:rank('HOT_SINGLE',hotSingle),COOL_SINGLE:rank('COOL_SINGLE',coolSingle),HOT_3D:rank('HOT_3D',hot3),COOL_3D:rank('COOL_3D',cool3)};
  const duplicateKeys=new Set<string>();for(const r of rows)duplicateKeys.add(`${r.company}|${r.date}|${r.drawNo??''}`);const duplicates=rows.length-duplicateKeys.size;const chronological=rows.every((r,i)=>i===0||rows[i-1].date<=r.date);const oosAvailable=analysisRaw.some(x=>x.id>=104&&x.applicable&&x.evidence!=='INSUFFICIENT_DATA');const fdrChecked=fusion.engineCoverage.advancedTests>0;
  return{dataset:{records:input.length,validRecords:rows.length,fingerprint:fingerprint(rows),oldest,newest},analysis,validation:{dataIntegrity:input.length===rows.length,duplicateCount:duplicates,chronological,oosAvailable,fdrChecked,mathChecked:!!fusion.layerSummary.find(x=>x.layer==='Mathematical'&&x.status==='READY')},fusion:{version:fusion.version,layerSummary:fusion.layerSummary,coverage:fusion.engineCoverage,candidates:fusion.candidates},findings,notes:['Final Result is produced by the Master Evidence Fusion sensor, not by the 107 layer alone.','Evidence families are not counted as independent votes when they are mathematically/redundantly related.','TAKE/WATCH/DROP are research dispositions, not future-outcome guarantees.','If a layer is insufficient, the engine preserves that uncertainty rather than fabricating a result.','Final candidates are restricted to observed historical 4-digit values; no arbitrary number is injected.']};
}
