# 4D HOSPITAL — Data Permanence & Security Final Hardening

তারিখ: 2026-10-09

## উদ্দেশ্য

Historical 4-digit data একবার সংরক্ষণ করার পর পরবর্তী import-এর সঙ্গে additive ভাবে যোগ হবে; পুরনো record পুনরায় input দিতে হবে না। Canonical dataset কোনোভাবেই localStorage-এর উপর নির্ভরশীল নয়।

## Canonical storage

- Android/native: encrypted SQLite (`4d_hospital_data`)
- Web/PWA: IndexedDB (`4d-hospital-web`)
- localStorage: legacy migration/সেটিংসের জন্য; canonical result database নয়

## Integrity hardening

- Web IndexedDB write atomic transaction + strict durability request
- Native SQLite write transaction + rollback on failure
- Native dataset metadata: row count + deterministic fingerprint + save time
- Startup integrity verification: mismatch হলে dataset গ্রহণ করা হয় না
- Legacy localStorage result copies durable store seal হওয়ার পরে retire করা হয়, যাতে একই dataset-এর একাধিক পূর্ণ কপি ফোনে অযথা জায়গা না নেয়

## Historical merge rule

- নতুন import পুরনো dataset মুছে দেয় না
- logical duplicate আলাদা করে শনাক্ত হয়
- default merge-এ existing record silently overwrite হয় না
- conflict আলাদা করে log করা যায়
- একই date-এ ভিন্ন draw number/result additive থাকতে পারে

## Backup / Restore

- Full backup-এ historical results, research observations, settings এবং local metadata থাকে
- Backup AES-256-GCM encrypted
- PBKDF2-SHA256 key derivation ব্যবহার হয়
- Backup-এর নিজস্ব dataset count + fingerprint থাকে
- Restore-এর আগে checksum ও dataset fingerprint যাচাই হয়
- Restore additive merge করে; পুরনো record অকারণে replace/delete করে না

## Visual integrity

Analysis visual layer একই live analysis result/evidence থেকে WHAT/WHY/NEXT/FINAL তৈরি করে। Decorative placeholder-কে analytical evidence হিসেবে উপস্থাপন করার নিয়ম রাখা হয়নি।

## Device resource policy

Storage layer হাজার হাজার historical record-এর জন্য local database ব্যবহার করে। তবে database storage এবং analysis RAM একই জিনিস নয়: খুব বড় dataset একসঙ্গে analysis করলে RAM/CPU usage বাড়তে পারে। V2.2-এ 1,000/5,000/10,000-row Master Result Node benchmark যথাক্রমে প্রায় 11.0s / 17.5s / 33.0s ছিল; 10k run-এ প্রায় 334 MB RSS দেখা গিয়েছিল। এটি Node/CI benchmark, Android handset certification নয়।

অতএব “হাজার হাজার data রাখা যাবে” এবং “যেকোনো ফোনে unlimited data একই গতিতে চলবে”—এই দুই দাবিকে এক করা যাবে না।

## Release truth

Source-level permanence hardening: PASS.

Actual clean GitHub Actions web build, actual Android APK build এবং real-device/emulator smoke: এখনও external GitHub runner-এ চালানো হয়নি। Sandbox-এ clean `npm ci` network timeout হয়েছে এবং local dependency tree অসম্পূর্ণ ছিল; তাই এই অংশে PASS দাবি করা হয়নি।

## Release gate

`npm run ci:release-gate`-এ data permanence audit বাধ্যতামূলক করা হয়েছে।
