# 4D HOSPITAL — মূল ZIP সংরক্ষণ ও V3.3 মার্জ অডিট

তারিখ: ৯ অক্টোবর ২০২৬

## তুলনা করা সোর্স
- মূল আর্কাইভ: `4D-HOSPITAL-OFFLINE-BACKUP-2026-10-06.zip`
- সংশোধিত সোর্স: `4D-HOSPITAL-V3.3-FINAL-SOURCE-REPAIR-2026-10-09.zip`
- অতিরিক্ত মাস্টার রেফারেন্স: `4D-HOSPITAL-CONSOLIDATED-MASTER-2026-10-08.zip` এবং `4D-HOSPITAL-FINAL-RELEASE-GATE-2026-10-09.zip`

## কী সংরক্ষণ/সংশোধন হয়েছে
1. মূল ZIP-এর active root source paths তুলনা করা হয়েছে। V3.3-তে মূল অ্যাপ সোর্সের কোনো অনুপস্থিত path পাওয়া যায়নি; অনুপস্থিত compatibility/config/legacy artefacts উদ্ধার করে রাখা হয়েছে।
2. `tsconfig.audit-run.json` এবং Windows lockfile-generation helper `scripts/GENERATE-CANONICAL-LOCKFILE-WINDOWS.ps1` সক্রিয় সোর্সে রাখা হয়েছে। পুরোনো `build-apk.yml` `archive/original-workflows/`-এ সংরক্ষিত; সেটি সক্রিয় করলে প্রকল্পের নিজস্ব Android workflow audit ব্যর্থ হয়। সক্রিয় canonical workflow হলো `.github/workflows/build-and-validate.yml`।
3. পুরোনো `.tsc-output.txt` এবং `tsc-final.legacy.txt`-কে `archive/legacy-build-logs/`-এ রাখা হয়েছে; এগুলোকে বর্তমান বিল্ডের ফল হিসেবে দেখানো হয়নি।
4. মূল ZIP-এর nested `hosp/` কপি `archive/original-hosp-snapshot/hosp/`-এ সংরক্ষিত। এটি সক্রিয় অ্যাপ রুট নয়; পুরোনো কোড নতুন V3.3 কোডের উপর চাপিয়ে দেওয়া হয়নি।
5. মূল ZIP-এর `node_modules/` (৩০ হাজারের বেশি ইনস্টল করা dependency file) চূড়ান্ত সোর্স ZIP-এ কপি করা হয়নি। এগুলো সোর্স ফিচার নয় এবং পরিবেশভেদে পরিবর্তিত হয়; `package-lock.json` থেকে `npm ci` দিয়ে পুনরায় তৈরি করার কথা। পুরোনো offline bootstrap lockfile archive-এ সংরক্ষিত।
6. Consolidated master থেকে অনুপস্থিত ১৪টি visual-set reference image এবং প্রাসঙ্গিক master documentation/helper files V3.3-এর কোনো বর্তমান source file overwrite না করে যোগ করা হয়েছে।
7. বাস্তব TypeScript typecheck-এ ধরা পড়া দুইটি কোড সমস্যা সংশোধন করা হয়েছে: (ক) WHY chart-এ distribution tuple-কে numeric series হিসেবে ব্যবহার করার টাইপ সমস্যা; (খ) `MasterResearchBundle`-এ ব্যবহৃত optional `sensorProfile` টাইপ অনুপস্থিত থাকা। সংশোধনের পরে `npm run typecheck` সফল হয়েছে।

## পরীক্ষার ফল
- ZIP integrity: PASS
- TypeScript typecheck: PASS
- 107 analysis / 64 known mathematical cases / 59 FDR cases: PASS
- Static audit, investigator audit, advanced research audit, runtime contract audit: PASS
- Research-cycle E2E, inventory, research layers, stability, scientific-gap regression: PASS
- GitHub Android workflow audit, release readiness, A-to-Z regression, master result count, production integrity, benchmark manifest, storage/data permanence checks: PASS
- TS/TSX syntax audit: PASS (219 files)

## এখনও সম্পন্ন নয়
- Vite production build এখানে সম্পূর্ণ করা যায়নি। মূল ZIP-এর সঙ্গে থাকা dependency folder Windows platform-এর জন্য; এতে Linux-এর `@rollup/rollup-linux-x64-gnu` optional binary নেই। তাই offline copied dependencies দিয়ে build ব্যর্থ হয়েছে। এই পরিবেশে npm registry-তেও সংযোগ পাওয়া যায়নি; GitHub Ubuntu runner-এ lockfile-ভিত্তিক `npm ci` চালিয়ে তারপর build করতে হবে।
- সম্পূর্ণ `npm run validate` একটানা চালালে পরিবেশের সময়সীমায় শেষ হয়নি; সংশ্লিষ্ট মূল অডিটগুলো আলাদাভাবে চালিয়ে PASS ফল পাওয়া গেছে।
- Android APK তৈরি, APK integrity, emulator/device install/launch এখনো বাস্তব GitHub runner/device-এ প্রমাণিত নয়।
- ১০৭টি বিশ্লেষণের উপস্থিতি ও regression tests পাস হওয়া বৈজ্ঞানিকভাবে ভবিষ্যৎ ফল নিশ্চিত হওয়ার প্রমাণ নয়।
