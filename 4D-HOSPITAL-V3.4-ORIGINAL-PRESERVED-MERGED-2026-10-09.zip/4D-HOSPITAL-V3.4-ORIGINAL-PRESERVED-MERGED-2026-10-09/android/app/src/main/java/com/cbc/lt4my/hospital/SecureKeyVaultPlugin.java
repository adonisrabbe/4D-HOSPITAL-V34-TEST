package com.cbc.lt4my.hospital;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name="SecureKeyVault")
public class SecureKeyVaultPlugin extends Plugin {
 private static final String KS="AndroidKeyStore";
 private SecretKey key(String alias) throws Exception { KeyStore ks=KeyStore.getInstance(KS); ks.load(null); if(!ks.containsAlias(alias)){ KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,KS); kg.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build()); kg.generateKey(); } return ((KeyStore.SecretKeyEntry)ks.getEntry(alias,null)).getSecretKey(); }
 @PluginMethod public void getOrCreateKey(PluginCall call){try{String alias=call.getString("alias","4d-hospital-research");key(alias);JSObject o=new JSObject();o.put("alias",alias);call.resolve(o);}catch(Exception e){call.reject("Keystore unavailable",e);}}
 @PluginMethod public void encrypt(PluginCall call){try{String alias=call.getString("alias","4d-hospital-research");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key(alias));byte[] ct=c.doFinal(call.getString("plaintext","").getBytes(StandardCharsets.UTF_8));JSObject o=new JSObject();o.put("ciphertext",Base64.encodeToString(ct,Base64.NO_WRAP));o.put("iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP));call.resolve(o);}catch(Exception e){call.reject("Keystore encryption failed",e);}}
 @PluginMethod public void decrypt(PluginCall call){try{String alias=call.getString("alias","4d-hospital-research");byte[] iv=Base64.decode(call.getString("iv",""),Base64.NO_WRAP);byte[] ct=Base64.decode(call.getString("ciphertext",""),Base64.NO_WRAP);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(alias),new GCMParameterSpec(128,iv));JSObject o=new JSObject();o.put("plaintext",new String(c.doFinal(ct),StandardCharsets.UTF_8));call.resolve(o);}catch(Exception e){call.reject("Keystore decryption failed",e);}}
}
