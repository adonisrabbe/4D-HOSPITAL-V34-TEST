# 4D HOSPITAL — Visual Analysis Final Hardening

তারিখ: 2026-10-05

## Final visual architecture

- দ্বিতীয় reference image-এর 12-card / 4×3 main analysis composition রাখা হয়েছে।
- প্রথম reference image-এর detail-rich presentation প্রতিটি analysis-এর detail layer-এ রাখা হয়েছে।
- Dashboard → Result Details → Deep Research → Full Functional Analysis flow সক্রিয়।
- 12টি visual card একই decorative score ব্যবহার করে না; প্রতিটি card আলাদা visualization language ব্যবহার করে।

## Data authenticity

Visual workspace এখন live historical dataset থেকে calculation নেয় এবং canonical `107-core-v1` analysis engine-এর output ব্যবহার করে।

- LSTM: recurrent OOS result + time-series research context
- Markov: transition matrix / transition stability
- Genetic: real deterministic genetic optimizer (`advanced-models.ts`)
- Cluster / Outlier: robust-Z + structural clustering
- Backtesting: chronological rolling position-frequency OOS test
- Sliding Window: 30/60/90 historical windows
- Consensus: validation-agreement view; future winning probability নয়
- Alerts: change-point / randomness / CUSUM diagnostics
- Performance: OOS hit diagnostics, not accuracy theatre
- Neighbor Digits: actual digit-frequency topology
- Deep Analysis: dependency, information, spectrum, entropy, complexity and state layers
- Predictions: local candidate ranking engine; evidence/model index only

## Scientific boundary

কোনো hard-coded `96.8%`, `94.7%`, `99.9%` future-winning probability visual layer-এ ব্যবহার করা হয়নি। Historical/OOS hit rate-কে future outcome probability হিসেবে দেখানো হয় না। Sample insufficient হলে result state সেই সীমাবদ্ধতা দেখায়।

## Verification

- Visual Analysis Layer Audit: PASS
- A→Z Final Regression Audit: PASS
- Production Integrity Audit: PASS
- 64 known mathematical cases: PASS
- 107 analysis executions: PASS
- 59 FDR tests: PASS
- Scientific-gap regression: PASS
- GitHub/Android workflow audit: PASS
- Focused TypeScript audit (`tsconfig.audit.json`): PASS

## Release environment limitation

এই source-only sandbox-এ canonical `package-lock.json` resolve করা হয়নি এবং বাস্তব Android SDK/emulator build locally certified নয়। GitHub release workflow committed lockfile + `npm ci` + Android build + APK integrity + emulator smoke test দিয়ে এগুলো gate করে।
