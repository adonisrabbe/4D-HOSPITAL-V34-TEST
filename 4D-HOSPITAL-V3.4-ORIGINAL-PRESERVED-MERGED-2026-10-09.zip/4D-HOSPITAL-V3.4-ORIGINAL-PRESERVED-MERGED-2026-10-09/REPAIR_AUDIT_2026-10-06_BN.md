# 4D HOSPITAL — Source Repair Audit — 2026-10-06

এই ZIP-এ source-level root সমস্যা মেরামত করা হয়েছে।

## করা হয়েছে
1. Vite 8.3.0 → 7.3.0 করা হয়েছে, কারণ Tailwind Vite plugin 4.1.14-এর সাথে Vite 8 peer mismatch ছিল।
2. @vitejs/plugin-react 6.1.1 → 5.2.0 করা হয়েছে, কারণ Vite 7-এর সাথে plugin-react 6-এর `./internal` export incompatibility ছিল।
3. @capacitor/filesystem 7.0.2 → 7.1.9 করা হয়েছে।
4. `MasterPredictionView`-এর missing `datasetMetadata` scope ঠিক করা হয়েছে।
5. `ResearchCycleView`-এর বাইরে থাকা `datasetMetadata`, `analysis107`, `engineResult` references-কে AppCore-এর actual analysis result থেকে explicit props হিসেবে দেওয়া হয়েছে।
6. `AnalysisKey` already exported ছিল—সেটি পরিবর্তন করা হয়নি।

## গুরুত্বপূর্ণ
এই audit environment-এ network dependency installation সম্পূর্ণ করা যায়নি; তাই এই ZIP-কে `build verified` বা `17,000 errors = zero` বলে দাবি করা হচ্ছে না। Dependency install শেষ হওয়ার পরে TypeScript/build চালিয়ে remaining source errors যাচাই করতে হবে।
