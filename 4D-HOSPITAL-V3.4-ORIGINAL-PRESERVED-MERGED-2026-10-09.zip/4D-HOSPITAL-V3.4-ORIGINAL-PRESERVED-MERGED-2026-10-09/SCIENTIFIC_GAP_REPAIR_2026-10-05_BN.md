# 4D HOSPITAL — Scientific Gap Repair & Hardening — 2026-10-05

## উদ্দেশ্য
আগের audit-এ পাওয়া statistical validation, leakage, multiple-testing, time-series inference, symbolic discovery, spectral significance, source stratification এবং recurrence-prevention gap-গুলো code-level guardrail সহ সংশোধন করা হয়েছে।

## প্রধান সংশোধন

1. **Global multiple-testing registry / FDR**
   - advanced research-এর inferential hypotheses এক global family-তে নিবন্ধিত।
   - mathematical boolean recent-vs-baseline tests, exact binomial, mutual information, corrected change-point এবং spectral peak significance একই FDR registry-তে যায়।
   - current synthetic verification: 59 global hypotheses.

2. **Change-point false-positive control**
   - সব candidate breakpoint search করে maximum-statistic permutation null ব্যবহার করা হয়েছে।
   - reported p-value এখন search-adjusted/global p-value।

3. **Spectral significance**
   - dominant spectral peak-কে raw peak হিসেবে নয়, all-frequency maximum surrogate/permutation test দিয়ে যাচাই করা হয়।

4. **Sparse digit-independence test**
   - 10×10 contingency table-এ expected cell count sparse হলে ordinary chi-square p-value ব্যবহার না করে fixed-margin Monte-Carlo permutation test ব্যবহৃত হয়।

5. **Formal time-series diagnostics**
   - ACF-এর সঙ্গে approximate 95% reference band।
   - Ljung–Box test যোগ করা হয়েছে।
   - runs test এখন formal p-value দেয়; শুধু run count নয়।

6. **Bootstrap**
   - mean ± bootstrap-SD heuristic বাদ দিয়ে percentile bootstrap interval ব্যবহার করা হয়েছে।

7. **Symbolic discovery leakage fix**
   - 60% train / 20% validation / 20% final-test split।
   - model selection validation-এ; final test selection-এর পরে একবারের জন্য।
   - final test পুনরায় tuning-এ ব্যবহার করা যাবে না।

8. **Conformal calibration**
   - calibration এবং final test আলাদা করা হয়েছে।
   - discrete 4D scalar interval semantics ও empirical coverage রিপোর্ট করা হয়।
   - UI/engine-এ coverage-কে guarantee হিসেবে দেখানো যাবে না।

9. **Investigator source/company stratification**
   - company-wise sample, duplicate rate, even rate, digit entropy যোগ হয়েছে।
   - small-stratum warning যোগ হয়েছে।
   - FIRST-এর পাশাপাশি FIRST/SECOND/THIRD position summaries যোগ হয়েছে।

10. **Signal freeze / blind OOS governance**
    - `lib/research-governance.ts` যোগ করা হয়েছে।
    - discovery fingerprint, OOS boundary, signal manifest hash এবং blind-OOS assertions রয়েছে।
    - regression test নিশ্চিত করে যে discovery data বদলালে frozen manifest invalid হয়।

11. **Mathematical semantic hardening**
    - Pythagorean-side property-র সংজ্ঞা explicit identity দিয়ে documented করা হয়েছে: every integer n >= 3 can occur as a side of an integer Pythagorean triple।
    - আগের ভুল ধারণা/ব্রুট-ফোর্স interpretation আর রাখা হয়নি।

12. **Permanent regression guard**
    - `scripts/scientific-gap-regression-audit.mjs` যোগ করা হয়েছে।
    - `npm run validate` এবং `npm run production:verify`-এর সঙ্গে যুক্ত।

## Verification

PASS:
- 64 known-value mathematical regression cases
- 107/107 public analysis execution contract
- Research Cycle E2E
- Advanced Research Audit
- Investigator Audit
- Scientific Core v3 Audit
- Static Audit
- Mathematical Research Audit
- Research Layers Audit
- Stability Hardening Audit
- Model Layer Audit
- Scientific Gap Regression Audit

Scientific Gap Regression result:
- catalog: 107
- contracts: 107
- global FDR hypotheses: 59
- corrected change-point candidates reported: 10 (synthetic regression dataset)

## একটি পরিবেশগত সীমাবদ্ধতা

`package-lock.json` এখনো তৈরি করা যায়নি, কারণ এই execution environment-এ npm registry metadata/cache unavailable। একটি fake/incomplete lockfile ইচ্ছাকৃতভাবে বানানো হয়নি। তাই dependency-lock audit এখনও release blocker হিসেবে দেখাবে। প্রকৃত npm registry access থাকলে `npm install --package-lock-only --ignore-scripts` চালিয়ে genuine lockfile তৈরি করতে হবে।

একই কারণে full dependency-backed Vite/Capacitor build এখানে certify করা হয়নি; targeted TypeScript compilation এবং dependency-free research modules compile/regression tests করা হয়েছে।

## গবেষণা-সীমা

এই hardening-এর পরেও system historical evidence/diagnostic research engine—random future draw predictability-এর mathematical guarantee নয়। OOS ফল, p-value, FDR, Bayesian evidence, conformal coverage এবং model scores সবই declared assumptions ও sample size-এর অধীন।
