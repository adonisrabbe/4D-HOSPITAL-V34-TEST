# 4D HOSPITAL V3.4 — Validation Results (Bengali)

- `npm run typecheck`: PASS after fixing the two TypeScript errors documented in `SOURCE_PRESERVATION_AUDIT_BN.md`.
- `node scripts/math-107-verification.mjs`: PASS — 64 known math cases, 107 analysis catalog, 59 FDR tests, zero failures.
- `node scripts/mathematical-research-audit.mjs`: PASS.
- `node scripts/investigator-audit.mjs`: PASS.
- `node scripts/static-audit.mjs`: PASS — 107 public analysis entries unique.
- `node scripts/dependency-lock-audit.mjs`: PASS.
- `node scripts/data-permanence-audit.mjs`: PASS.
- `node scripts/github-android-workflow-audit.mjs`: PASS — canonical dependency handoff and Android build gates present; obsolete compatibility workflow not active.
- `node scripts/release-readiness-audit.mjs`: PASS.
- `node scripts/a-to-z-final-regression-audit.mjs`: PASS.
- `node scripts/master-result-count-audit.mjs`: PASS — expected 5D/4D/3D/2D/1D sets, 107 coverage, 11 parts, 28 modules.
- `node scripts/production-integrity-audit.mjs`: PASS.
- `node scripts/runtime-contract-audit.mjs`: PASS.
- `node scripts/research-cycle-e2e.mjs`: PASS.
- `node scripts/master-inventory-audit.mjs`: PASS.
- `node scripts/research-layers-audit.mjs`: PASS.
- `node scripts/stability-hardening-audit.mjs`: PASS.
- `node scripts/advanced-research-audit.mjs`: PASS.
- `node scripts/scientific-gap-regression-audit.mjs`: PASS — catalog/contracts 107, global FDR 59, change points 10.
- `node scripts/benchmark-manifest-audit.mjs`: PASS — 5 benchmark datasets and hashes.
- `node scripts/final-integrity-review-audit.mjs`: PASS.
- `node scripts/test-android-keystore-plugin-installer.mjs`: PASS.
- `node scripts/test-ci-registry-preflight.mjs`: PASS.
- `node scripts/master-visual-architecture-audit.mjs`: PASS — 107 visuals, 11 parts, 28 modules.
- `node scripts/ts-syntax-audit.mjs`: PASS — 219 TS/TSX files.

Build limitation: Vite build could not complete with the old dependency folder copied from the original archive because it lacks the Linux Rollup optional native package. `npm ci` on the GitHub Ubuntu runner is still required; APK/device verification remains pending.
