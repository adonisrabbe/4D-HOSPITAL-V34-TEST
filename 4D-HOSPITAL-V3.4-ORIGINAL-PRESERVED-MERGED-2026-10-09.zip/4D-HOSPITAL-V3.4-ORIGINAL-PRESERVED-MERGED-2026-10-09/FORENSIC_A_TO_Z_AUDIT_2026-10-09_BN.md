# 4D HOSPITAL — Forensic A→Z Audit / V2.1

তারিখ: 2026-10-09
Scope: V2.0 source package থেকে source-level, architecture, research, master-result, visual, storage, dependency এবং build-gate forensic review.

## 1. Scope
- 305 files in package
- 20,224 TypeScript/TSX source lines
- 53,266 total non-generated/source-package lines counted by local inspection
- 107 public analyses
- 11 Parts
- 428 analysis-page instances
- 107 analysis visual pages
- 45 additional visual surfaces
- 28 signal modules
- Master Result: 5D×5, 4D×4, 3D×4, 2D×4, 1D×4 = 21 candidates
- 10-set research board

## 2. Forensic defects found and repaired

### A. Visual explanation was partly decorative
আগের V2.0 visual explanation chart-এ fixed values `[42,58,73,64,82,...]` ছিল। ফলে chart বাস্তব sensor evidence-এর সম্পূর্ণ data-driven representation ছিল না।

Repair: visual bars এখন candidate sensor profile, consensus, conflict এবং final evidence score থেকে তৈরি হয়।

### B. 10-set edits could become stale after new data upload
আগের storage key dataset-independent ছিল। ফলে নতুন dataset আসার পর পুরোনো 10-set edits ভুল dataset-এর সঙ্গে দেখা যাওয়ার সম্ভাবনা ছিল।

Repair: storage key এখন dataset fingerprint + calculation version-এর সঙ্গে বাঁধা।

### C. Lock state reload-এর পর হারিয়ে যেতে পারত
Repair: lock state dataset-scoped local storage-এ persist করা হয়েছে।

### D. Manual edit validation দুর্বল ছিল
Repair: 5D/4D/3D/2D/1D manual fields এখন digit-only এবং level-specific maximum length enforce করে।

### E. Master fusion candidate scoring পুরোপুরি candidate-specific ছিল না
আগের design-এ 107/Mathematical/Investigator/Advanced/Scientific layers-এর অনেক score dataset-global ছিল; ফলে সব candidate একই global score পেত। এতে “সব sensor ব্যবহার” কথাটি misleading হতে পারত।

Repair: 107-core-এর candidate structural relevance sensor যোগ করা হয়েছে এবং global 107 evidence gate আলাদা রাখা হয়েছে। 28-signal score candidate-specific থাকে। Global research layers candidate ranking-এ independent votes হিসেবে double-count করা হয় না।

### F. Master Result একই fusion lineage বারবার চালাচ্ছিল
আগের Master Result Sheet-এ 10-set research bundle তৈরির সময় একই evidence fusion আবার চালানোর পথ ছিল।

Repair: final report-এর একই fusion lineage reuse করা হয়েছে। এতে duplicate heavy computation কমেছে।

### G. Master sensor path unnecessarily heavy ছিল
আগের 28-signal engine-এর full adaptive/OOS-heavy validation loops Master Result rendering-এর মধ্যেই ঢুকে যাচ্ছিল।

Repair: Master Result-এর জন্য lightweight sensor mode চালু করা হয়েছে। Full adaptive/OOS-heavy validation dedicated validation/research pipeline-এ থাকে। Candidate universe-ও historical candidate pool-এ সীমাবদ্ধ করা হয়েছে।

## 3. Re-verification
PASS:
- 107 engine static audit
- Master inventory
- Research layers architecture
- Master Result count
- Master visual architecture
- GitHub/Android workflow audit
- Dependency-lock audit
- Static audit
- Runtime contract audit
- Mathematical research audit
- Advanced research audit
- Investigator audit
- Benchmark manifest
- Production integrity
- Release readiness
- World-class gap
- Final deep audit
- Reconciliation audit
- Performance harness audit
- Visual analysis layer audit
- Forensic release audit

## 4. Important environment limitation
এই sandbox-এ `npm ci` সম্পূর্ণ dependency installation transport timeout-এর কারণে শেষ করা যায়নি। তাই clean production Vite build এবং Android APK/emulator-কে এখানে VERIFIED PASS বলা হয়নি।

Global TypeScript compiler দিয়ে isolated core stack compile করা হয়েছে এবং modified master/research stack compile PASS করেছে। Full application typecheck-এর জন্য npm dependencies উপস্থিত থাকা প্রয়োজন।

দুইটি existing regression scripts local dependency environment-এ `babel__core` type-definition resolution-এ আটকে গেছে; একই source manually isolated `typeRoots` দিয়ে compile PASS করেছে। এটাকে source-code PASS বা GitHub PASS হিসেবে mislabel করা হয়নি।

## 5. Master performance finding
Lightweight Master Result benchmark:
- 100 rows: ~6.7 seconds in this sandbox
- 500 rows: ~33.7 seconds in this sandbox

এটি target-device certification নয়। 1,000/10,000 full Master Result latency এখনও certified নয়। তাই large-data performance-কে PASS বলা হয়নি।

## 6. Scientific boundary
107 analyses, 28 modules, Mathematical, Investigator, Advanced, Scientific এবং validation layers software/research evidence plumbing পরীক্ষা করে। এগুলো future 4D outcome-এর guaranteed predictability বা winning probability প্রমাণ করে না।

## 7. Final forensic status
Source/architecture/research/master-result/visual/storage-governance repairs: PASS under available offline audits.

Clean dependency install + production build + Android APK + emulator: NOT VERIFIED in sandbox; must pass GitHub Actions.

Large-data Master Result performance: NOT CERTIFIED.

এই report ইচ্ছাকৃতভাবে environment-dependent অংশকে PASS বলে না।
