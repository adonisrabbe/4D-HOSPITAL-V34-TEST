# 4D Hospital — Mathematical Research Upgrade

এই upgrade-এ 100+ mathematical idea-কে সরাসরি 100+ prediction vote বানানো হয়নি। বরং `Number Theory & Mathematical Laboratory`-তে এগুলোকে deterministic feature হিসেবে পরীক্ষা করা হয়।

## Research policy

1. **Classification first** — প্রতিটি 4-digit-এর mathematical fingerprint তৈরি হয়।
2. **Historical prevalence** — property পুরো dataset-এ কতবার দেখা গেছে তা মাপা হয়।
3. **Recent-vs-baseline drift** — recent window ও পুরোনো baseline-এর পার্থক্য দেখানো হয়।
4. **Chronological stability** — 3টি chronological block-এ property rate স্থিতিশীল কি না দেখা হয়।
5. **Promotion gate** — stable + sufficiently observed + leakage-safe OOS validation ছাড়া property-কে active ranking signal করা হয় না।
6. **Redundancy rule** — একই তথ্য বহনকারী mathematical properties-কে আলাদা independent vote হিসেবে গণনা করা যাবে না।
7. **No guarantee** — কোনো mathematical property ভবিষ্যৎ 4-digit ফল নিশ্চিত করে না।

## Implemented mathematical families

- Prime: prime/composite, twin/cousin/sexy relations, Mersenne/Fermat form, Sophie Germain, safe prime, Wilson prime, Emirp, palindromic/repunit prime, prime-gap relations, primorial relation.
- Digit: digital root, digit sum, palindrome, repdigit, Kaprekar number, Kaprekar 6174 routine, Armstrong/Narcissistic, Happy, Harshad, Smith, Automorphic, Factorion, Strobogrammatic.
- Polygonal/power: square, cube, triangular, pentagonal, hexagonal.
- Sequence: Fibonacci, Lucas.
- Divisor: perfect, abundant, deficient, sphenic, powerful, square-free, semiperfect, weird, tau, sigma, Euler phi, Möbius.

## Concepts intentionally kept as reference rather than direct signals

Riemann Hypothesis, Goldbach Conjecture, Twin Prime Conjecture, Fermat's Last Theorem, Elliott–Halberstam and similar theorem/conjecture material are mathematical references, not direct 4D outcome predictors. Benford/Zipf-style diagnostics also require their assumptions to be checked before interpretation.

## Result-board interpretation

- `STABLE` = property is relatively stable across chronological blocks; **not** proof of predictive value.
- `DRIFT` = recent rate differs materially from baseline; this is a regime-change warning, **not** a cause.
- `RARE` = too few occurrences for reliable inference.
- `NOT_INFORMATIVE` = currently no stable evidence strong enough for promotion.

The Research Result Center keeps this layer separate from the 107 Core and 28 Active Signals so the app does not create a false total or double-count correlated evidence.
