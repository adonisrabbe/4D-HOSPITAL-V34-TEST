# 4D HOSPITAL — CURRENT RELEASE TRUTH

তারিখ: 2026-10-09 — source repair candidate V3.2

## User path
1. ZIP-এর ভেতরের project files GitHub repository root-এ upload/commit করুন।
2. GitHub Actions → **4D HOSPITAL - Validate and Build Android APK** → Run workflow চালান।
3. বর্তমান source bundle-এ `package-lock.json` আছে; আলাদা করে lockfile তৈরি করতে হবে না।
4. Canonical workflow প্রথমে committed lockfile-এর version/integrity যাচাই করবে, তারপর একই lockfile artifact হিসেবে validation, performance ও Android jobs-এ hand-off করবে।
5. Pipeline: registry preflight → `npm ci` → typecheck/research validation → Vite build → Capacitor/Android → Gradle APK → APK package ID/ZIP/SHA-256 checks → API 35 emulator install/launch/PID check.
6. যদি ZIP/repository copy-তে lockfile না থাকে, আগে **Bootstrap package-lock.json** recovery workflow চালিয়ে lockfile commit করুন; তারপর canonical workflow চালান।

## Verified locally in this repair environment
- 31 source/audit scripts PASS; 107-analysis and math/FDR verification PASS.
- 64 known mathematical cases, 107 analysis catalog entries, 59 FDR tests; zero reported failures.
- 66 exact direct dependencies and all 421 lock entries pass the dependency preflight.
- Native Android Keystore plugin registration regression test PASS.
- Registry preflight regression test PASS; four remaining workflow YAML files parse; all 46 `.mjs` scripts pass Node syntax checks.

## Still blocked / not certified
- This sandbox cannot resolve `registry.npmjs.org` (`EAI_AGAIN`); direct HTTPS and npm ping both fail here.
- Therefore clean `npm ci`, TypeScript compiler run, Vite production build, Android Gradle APK build, APK integrity check on a newly built APK, and emulator install/launch were not completed here.
- The GitHub Actions runner must complete these gates. No APK is certified by this source-level report alone.
- OCR is online-only; internet না থাকলে OCR চলবে না। Manual/Paste data entry ব্যবহার করা যাবে।
- Scientific analysis future 4D outcome-এর guaranteed winning probability দাবি করে না।

## Acceptance
শুধু canonical GitHub Actions-এর সব required jobs PASS হলে APK-কে release-certified ধরা হবে।
