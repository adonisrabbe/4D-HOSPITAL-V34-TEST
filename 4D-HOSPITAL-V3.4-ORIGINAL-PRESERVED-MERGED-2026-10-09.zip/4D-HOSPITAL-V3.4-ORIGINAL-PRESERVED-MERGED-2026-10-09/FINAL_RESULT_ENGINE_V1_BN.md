# 4D HOSPITAL — FINAL RESULT ENGINE V1

## Purpose

এই release-এ Final Result-কে আলাদা **evidence-driven decision layer** হিসেবে করা হয়েছে। এটি 107 Core Analysis-এর বিকল্প নয় এবং 108তম analysis নয়। এটি current dataset-এর উপর 107-core output, mathematical/validation state এবং observed historical structure একত্র করে একটি deterministic final-result surface তৈরি করে।

## Final Result surfaces

প্রতিটি surface-এ সর্বোচ্চ ৪টি Set থাকে:

1. HOT 4-DIGIT — ৪টি
2. COOL 4-DIGIT — ৪টি
3. PAIR — ৪টি central-frequency set
4. HOT PAIR — ৪টি
5. COOL PAIR — ৪টি
6. SINGLE DIGIT — ৪টি central-frequency set
7. HOT SINGLE — ৪টি
8. COOL SINGLE — ৪টি
9. HOT 3-DIGIT — ৪টি
10. COOL 3-DIGIT — ৪টি

## Definitions

- **4-Digit:** dataset-এ সত্যিই observed 4-digit values; নতুন/random 4-digit তৈরি করা হয় না।
- **Pair:** observed 4-digit-এর adjacent 2-digit pairs: positions 1–2, 2–3, 3–4।
- **3-Digit:** observed 4-digit-এর contiguous 3-digit windows: positions 1–3 এবং 2–4।
- **Single Digit:** observed digits 0–9-এর frequency distribution।
- **Hot:** historical frequency + recency weighted high ranking।
- **Cool:** historical frequency + recency weighted low ranking।
- **PAIR / SINGLE:** frequency distribution-এর central/representative four candidates; এগুলো Hot-এর duplicate label নয়।

## Evidence and safety

Final Result candidate ranking is not a winning probability. Candidate score is an evidence/index score only. The engine exposes:

- dataset fingerprint
- record count and date range
- 107 analysis support/neutral/conflict/insufficient counts
- data integrity and duplicate state
- mathematical connection state
- FDR state when the advanced research layer can compute it
- OOS availability state
- per-candidate count, share, last-seen date, decision label and source trace

If there is insufficient data, the UI shows **INSUFFICIENT DATA** rather than inventing a result.

## No silent duplication

Final Result does not create one finding repeatedly just because multiple analyses mention the same historical value. The visual layer represents each selected candidate once and keeps the supporting research layer as trace/context.

## Release boundary

Software implementation is a release artifact; it is not proof that any future 4D outcome is predictable and it does not guarantee a future result.
