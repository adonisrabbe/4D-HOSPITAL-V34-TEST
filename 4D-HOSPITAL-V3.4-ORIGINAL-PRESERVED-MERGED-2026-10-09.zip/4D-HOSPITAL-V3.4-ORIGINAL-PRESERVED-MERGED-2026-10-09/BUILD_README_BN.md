# 4D HOSPITAL — Build Project

এটি Replit-মুক্ত canonical source project। বর্তমান application source root-এ রয়েছে; কোনো `src/` runtime tree নেই।

## Canonical source

- `App.tsx` — main application shell
- `main.tsx` — Vite entry point
- `lib/` — analysis, research, validation, storage
- `components/` — UI
- `hooks/`, `pages/`, `types/` — supporting source
- `public/` — static assets

## Web build

Network access এবং Node.js থাকা অবস্থায়:

```bash
npm ci
npm run validate
npm run build
```

## Android

```bash
npm ci
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

`android/` generated platform directory; source ZIP-এ এটি intentionally required নয়।

## Important release limits

- এই current source bundle-এ `package-lock.json` committed আছে; canonical workflow exact version/integrity যাচাই করে একই lockfile artifact validation/performance/Android jobs-এ hand-off করে। Lockfile অনুপস্থিত হলে আলাদা `Bootstrap package-lock.json` recovery workflow চালিয়ে generated lockfile commit করতে হবে.
- OCR online-only; internet না থাকলে OCR চলবে না। Offline Manual/Paste entry available; এটি bundled offline OCR নয়।
- Android APK/device E2E canonical GitHub workflow-এ verify করতে হবে; source-only sandbox-এ native build certified নয়।
- Local admin authentication is device-local; server-grade multi-device authentication requires a backend.
