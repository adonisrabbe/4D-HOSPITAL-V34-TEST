# 4D Hospital — Free Investigator Research AI

এই layer কোনো paid API, subscription, cloud backend বা external AI service-এর উপর নির্ভর করে না।

## উদ্দেশ্য
107 Core, 28 Active Signals, Mathematical Laboratory এবং validation diagnostics-এর verified outputs-কে একটি local Investigator view-তে ব্যাখ্যা করা।

## Guardrails
- কোনো future result guarantee নেই।
- Formula/property-কে automatic independent vote ধরা হয় না।
- Digit Sum/Digital Root/mod-9-এর মতো dependent evidence-এ redundancy warning থাকে।
- Recent-vs-baseline drift আলাদা diagnostic হিসেবে দেখানো হয়।
- Numeric mathematical properties (যেমন tau/sigma/phi/mobius/digit sum/root) rate নয়; mean/drift হিসেবে report হয়।
- Insufficient data-কে forced conclusion-এ রূপান্তর করা হয় না।
- Local question-answer panel শুধু app-এর calculated evidence ব্যবহার করে; paid AI/API নেই।

## UI
- Investigator Research Panel
- Evidence Detective
- Redundancy & Null-model Guard
- Mathematical Evidence
- Ask Research Investigator

## বাস্তবতা
এই panel deterministic/local research diagnostics দেয়। এটিকে general-purpose LLM বলা হচ্ছে না। ভবিষ্যতে কোনো local model যোগ করা হলেও core calculations তার উপর নির্ভরশীল হবে না।
