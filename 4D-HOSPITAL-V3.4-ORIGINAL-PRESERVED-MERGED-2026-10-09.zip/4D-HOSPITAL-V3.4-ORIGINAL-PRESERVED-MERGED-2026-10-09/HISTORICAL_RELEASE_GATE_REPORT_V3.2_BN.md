> **Historical snapshot only:** this report documents the V3.2 source state. For the current V3.3 review, use `RELEASE_GATE_REPORT_V3.3_BN.md`. Do not use this file as the current release verdict.

# 4D HOSPITAL — Release Gate Report V3.2 (2026-10-09)

## Additional release-gate defects found and repaired (V3.2)
- Removed `.github/workflows/build-apk.yml`, a deprecated manual workflow that was named like an APK build but intentionally produced no APK. There is now one canonical end-to-end APK build workflow, reducing the chance of selecting the wrong GitHub Actions entry.
- Strengthened `scripts/ci-npm-preflight.mjs` to verify exact manifest/lockfile versions, all 66 direct dependencies, and version/resolution/integrity metadata across all 421 lock entries before install.
A second release-gate issue was found in `scripts/ci-registry-preflight.mjs`: if Node's direct `fetch()` failed, the script threw immediately and never ran `npm ping`. That could incorrectly block a runner where npm can connect through npm-specific proxy settings even when Node's fetch path cannot.

Repair:
- DNS and direct HTTPS probes are now diagnostic and independent.
- The configured npm client probe always runs, even if DNS/Node fetch fails.
- `npm ping` remains the decisive gate because `npm ci` uses the npm client; if npm ping fails, Step 2 still fails closed.
- Added `scripts/test-ci-registry-preflight.mjs` covering proxy-compatible success, hard failure when npm ping fails, and normal direct success; wired it into `npm run validate` and the workflow audit.

## Why the previous repair exists
A deeper inspection of the Android CI path found a genuine runtime-registration defect in `scripts/install-android-keystore-plugin.mjs`: the generated Capacitor `MainActivity.java` is normally an empty `BridgeActivity` subclass, so the old replacement looking only for `super.onCreate(savedInstanceState);` did not register `SecureKeyVaultPlugin`. The build could succeed while the native plugin was unavailable at runtime.

## Repair
- The installer now handles the standard generated empty `MainActivity` and adds explicit `registerPlugin(SecureKeyVaultPlugin.class)` registration.
- The installer fails closed if `MainActivity.java` is missing or has an unsupported structure instead of silently continuing.
- The installer is idempotent: running it again does not duplicate registration.
- Added `scripts/test-android-keystore-plugin-installer.mjs` and wired it into `npm run validate`.
- Expanded the Android workflow audit to require this regression test and native registration guard.

## Tests run in this environment
PASS:
- V3.2 ZIP integrity is checked after packaging; the verified SHA-256 is provided with the delivery message.
- `package.json` JSON parse
- package-lock v3 and direct dependency lock audit
- CI dependency preflight (66 exact direct dependencies and all 421 lock entries checked for version, HTTPS resolution, and integrity metadata)
- GitHub Android workflow audit
- YAML parsing for all four remaining workflows
- Android Keystore installer regression test (default activity, generated plugin source, idempotent rerun)
- Registry preflight regression test (npm-client probe still runs after Node HTTPS/DNS failure; npm ping failure remains blocking)
- A-to-Z regression audit
- 107-analysis static audit
- mathematical research audit
- 107-analysis/FDR verification script (64 known-math cases, 107 catalog, 59 FDR tests, no reported failures)
- data permanence and storage security audits
- Master Result count and visual architecture audits
- performance stress static/script audit
- source import resolution scan (318 imports across 112 TS/TSX files; no missing local aliases or undeclared external packages found)
- Node syntax check for all 46 `.mjs` scripts
- Removed stale compiler-output text artifacts from the current bundle; old dated audit files are marked as historical snapshots

BLOCKED / NOT VERIFIED:
- Step 2 registry connectivity: `registry.npmjs.org` DNS lookup returns `EAI_AGAIN` in this execution environment; both direct HTTPS and npm-client probes fail here. The repaired preflight now runs both independently and correctly fails closed when npm itself cannot connect.
- Step 3 clean `npm ci`: cannot complete because the registry is unreachable from this environment.
- Step 4 Vite production build: not verified; installed Vite dependency is absent because clean install could not complete.
- Step 5 Gradle APK build: not run here; Android SDK/Gradle project toolchain is unavailable in this environment.
- Step 6 APK integrity: not run because no new APK was built.
- Step 7 emulator install/launch: not run because no new APK was built and no Android emulator is available here.
- TypeScript compiler-based syntax audit: blocked by missing installed `typescript` package in this environment; it must run after `npm ci` on the CI runner.

## Truthful release status
This source tree includes the release-gate repair and static/regression tests above. It is **not a verified release** until the GitHub Actions runner completes Steps 2–7. No network-dependent or Android-device test is marked PASS based on static inspection alone.
