# 4D HOSPITAL — Final A-to-Z Source Review V3.3 (2026-10-09)

## Scope of this pass

This review re-opened the V3.2 source archive and checked the app shell, 107-analysis workspace, local sign-in/invite flow, role-gated mutations, IndexedDB/SQLite persistence flow, encrypted recovery path, PWA metadata/offline shell, image format integrity, visual themes, dependency lockfile, and GitHub release workflow. This is a **source-level repair candidate report**, not a claim that an APK was built or device-tested.

## Defects found and repaired in V3.3

1. **Persistence failure was too quiet.** Native SQLite initialization could fail while the UI continued with in-memory/legacy data, and subsequent writes were logged without a visible fail-safe. The app now verifies store initialization and write return values, serializes persistence snapshots, and stops normal editing when durable storage fails. A recovery screen offers an encrypted snapshot of the current in-memory/legacy data before retrying.
2. **The login entry was admin-only even though managed local accounts existed.** The active sign-in modal now uses the existing `/auth/login` local adapter and supports admin and managed-user accounts. Logout is available for a signed-in managed user too.
3. **Invite links had no active route.** `#invite/<token>` now opens the invite-acceptance screen. The UI clearly warns that invitations are device-local and do not validate on another phone/computer without a backend; no remote auth service is claimed.
4. **Guest lock could trap the owner.** The lock screen now offers an Admin Sign In route as an alternative to the guest access code.
5. **View-only role could reach mutation controls.** Result add/edit/import handlers now check the local admin session; Data Vault mutation/restore controls, data-clear/import settings, guest-lock controls, and Agent/KYC management are hidden or blocked for non-admin users.
6. **Password instruction mismatch.** User creation copy now matches the 10-character minimum enforced by the handler.
7. **Legacy visual shell remained red/black while the analysis studio used the new navy/cyan design.** The initial route now opens the 12-tile 107-analysis overview. The shell, login, lock screen and PWA metadata use the new dark navy/cyan research-lab theme. Overview, Part, and Analysis detail surfaces have distinct atmospheric backgrounds without a repeated dotted/dashed page texture.
8. **Web/PWA app shell was not cached for offline reopening.** Added a web-only service worker that precaches the shell/manifest/logo and caches same-origin build assets after they are first loaded. Capacitor native builds skip registration because their shell is bundled. OCR remains online-only by design.
9. **Image extension/MIME mismatch.** The file named `cbc-logo.png` and two reference `.png` files were actually JPEG bytes, while the `.webp` reference was also JPEG bytes. These were re-encoded to match their declared formats; dedicated 192×192 and 512×512 PNG PWA icons were added and referenced from the manifest.
10. **Regression coverage added.** `scripts/final-integrity-review-audit.mjs` checks the new storage, sign-in/invite, role-guard, PWA and theme boundaries and is included in `npm run validate`.

## Checks actually passed in this environment

- 39 targeted source/regression audit scripts in the full sweep: PASS.
- Final integrity review audit: PASS.
- Android Keystore installer regression test: PASS (generated-style activity, registration, idempotent rerun).
- Registry-preflight regression test: PASS (the npm-client probe remains independent and failure stays a hard block).
- Dependency lock gate: PASS.
- CI dependency preflight: PASS — 66 exact direct dependencies and 421 lock entries checked for version, HTTPS resolution and integrity metadata.
- Local-auth, storage-security and data-permanence source audits: PASS.
- 107 analysis engine static audit: PASS.
- Math/FDR verification script: PASS — 64 known math cases, 107 analyses, 59 FDR tests, no reported failures.
- A-to-Z final regression audit: PASS.
- Master Result count audit: PASS — 21 expected result slots and 10 research bundles.
- Visual architecture audit: PASS — 107 analyses, 11 parts, 44 workflow pages, 428 page instances, 28 modules.
- GitHub Android workflow audit: PASS.
- TypeScript/TSX syntax-only parser: 112 files scanned, zero parse errors. This is not a replacement for `tsc --noEmit`.
- Relative/alias import and asset-resolution scan: 202 references checked, zero missing.
- YAML parsing: all four remaining GitHub Actions workflows parsed successfully.
- Node syntax checks: service worker and new audit script passed.
- Final ZIP archive integrity is checked after packaging; the SHA-256 is supplied in the handoff message.

## Still blocked / not verified (do not mark PASS)

- **Step 2 registry connectivity:** `registry.npmjs.org` is not resolvable from this execution environment (`EAI_AGAIN`); direct HTTPS and npm-client connectivity cannot complete here.
- **Step 3 clean `npm ci`:** not completed because the registry is unreachable.
- **Step 4 Vite production build and full TypeScript typecheck:** not run successfully here because the installed dependency tree is unavailable. Syntax-only parsing does not prove type correctness.
- **Step 5 Gradle APK build:** not run here; the Android SDK/Gradle project toolchain is unavailable in this environment.
- **Step 6 APK SHA-256/package ID/integrity:** not run because no fresh APK was built.
- **Step 7 Android emulator install/launch:** not run because there is no fresh APK/emulator in this environment.
- **Service-worker browser test:** source syntax/static checks passed, but actual offline reload must be verified in a real HTTPS browser after the first online visit.

## Important operating boundaries

- The web app must be opened once while online before its shell can be reused offline; GitHub Pages first load requires connectivity.
- Web data uses IndexedDB; native Android data uses SQLite. Data stays on that device/browser unless the user exports and restores an encrypted backup.
- OCR requires network access because the OCR engine/model are loaded from a CDN. Manual/Paste data entry and local analysis remain available without OCR.
- Login/account storage is device-local and is not equivalent to server-side authentication. Invite links do not sync across devices.
- “107 analyses implemented” is an engineering/catalog statement. It is not scientific proof that random future 4-digit results can be predicted.

## Release decision

V3.3 is the latest **repaired source package candidate**. It is not a verified APK release until the canonical GitHub Actions workflow completes Steps 2–7 successfully. Do not treat the source-level PASS checks above as proof of a successful production build or device launch.
