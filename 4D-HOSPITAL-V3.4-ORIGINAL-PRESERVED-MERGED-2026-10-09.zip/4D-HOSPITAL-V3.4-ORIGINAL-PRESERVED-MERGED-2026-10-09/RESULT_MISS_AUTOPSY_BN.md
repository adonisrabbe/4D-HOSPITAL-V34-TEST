# 4D HOSPITAL — Result Miss Autopsy

Final Result এবং Result Miss Autopsy সম্পূর্ণ আলাদা research surfaces।

## Workflow
1. Final Result তৈরি করুন।
2. `SAVE THIS FINAL RESULT AS BASELINE` চাপুন।
3. নতুন data batch (যেমন 23 records) যোগ করুন।
4. নতুন actual result dataset-এ যুক্ত করুন।
5. `④ Result Miss Autopsy` খুলুন।
6. Baseline candidate বনাম current actual এবং baseline→current ranking change দেখুন।

## Autopsy উদ্দেশ্য
- exact 4D match ছিল কি না
- pair/position/digit overlap কোথায় ছিল
- নতুন data-র কারণে ranking কীভাবে বদলেছে
- OOS/FDR/Scientific status কী ছিল
- কোন evidence layer শক্ত/দুর্বল ছিল

Autopsy পুরোনো result-কে retrospectiveভাবে পরিবর্তন করে না। এটি failure intelligence ও research-cycle feedback-এর জন্য।
