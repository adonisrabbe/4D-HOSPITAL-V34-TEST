> **Historical snapshot — superseded for current release instructions.** This file records an earlier project state. For the current lockfile, workflow, and release-gate status, use `CURRENT_RELEASE_TRUTH_BN.md` and `RELEASE_GATE_REPORT_V3.2_BN.md`.

# 4D HOSPITAL — FINAL A→Z REPAIR / HANDOFF REPORT

Date: 2026-10-05

## What was repaired in this final pass

1. Local auth/release hardening audit was synchronized with the current **online-only OCR** contract. The audit now explicitly verifies that OCR requires internet and that offline OCR is unavailable.
2. Canonical GitHub Android workflow now bootstraps a genuine `package-lock.json` automatically when the ZIP/repository does not contain one.
3. The generated lockfile is audited and handed to the web and Android jobs as the same artifact; both use `npm ci`.
4. The canonical workflow attempts to persist the generated lockfile back to the branch on `push` and `workflow_dispatch`. If branch protection rejects that push, the current run still continues with the generated lockfile artifact instead of failing only because persistence was denied.
5. User-facing GitHub/build documentation was synchronized so the user does not need to run Windows `npm install` merely to create the lockfile.
6. A current release-truth handoff file was added: `CURRENT_RELEASE_TRUTH_BN.md`.
7. OCR documentation was synchronized to the requested behavior: **online when internet exists; unavailable without internet**.

## Fresh verification in the repaired source

- Visual analysis layer audit: PASS
- A→Z final regression audit: PASS
- Production integrity audit: PASS
- GitHub/Android workflow audit: PASS
- Mathematical known-value verification: **64/64 PASS**
- Public analysis execution: **107/107 PASS**
- Global FDR hypotheses: **59**
- Scientific-gap regression: PASS (107 catalog / 107 contracts / 59 global FDR / 10 change-point checks)
- Research Cycle E2E: PASS
- Storage/security audit: PASS
- Local auth/release hardening audit: PASS
- Runtime contract audit: PASS
- Stability/worker audit: PASS
- Benchmark manifest audit: PASS (5 deterministic fixtures)
- TypeScript audit config: PASS (`tsc -p tsconfig.audit.json --noEmit`)

## Intentionally not fabricated

`package-lock.json` is not fake-generated inside this offline sandbox. The npm registry could not be resolved here. The canonical GitHub workflow creates the real lockfile on a networked GitHub runner.

A local Vite production build and real Android/Gradle/emulator certification were not falsely claimed because the sandbox does not contain the required installed dependency graph and Android SDK/emulator environment.

## Performance boundary

The 1M-record performance result remains a synthetic chunk/data-loop stress harness. It is **not** a certification that all 107 analyses run at 1M records on an Android device.

## Scientific boundary

The application is a historical numerical research and validation system. Its evidence/confidence labels are not guaranteed future winning probabilities.

## Recommended user path

1. Upload/commit the ZIP source to a GitHub repository root.
2. Run **4D HOSPITAL - Validate and Build Android APK** from GitHub Actions.
3. Let the workflow bootstrap the genuine lockfile and run all validation/build gates.
4. Download `4D-HOSPITAL-debug-APK` only after all required jobs PASS.
