# 4D HOSPITAL — Final Gate Repair Report

তারিখ: 2026-10-09
বেস: V2.3 Data Permanence Hardened

## এই রাউন্ডে বাস্তবে পাওয়া ও সংশোধিত সমস্যা

### 1. Master Evidence Fusion type error
`lib/master-evidence-fusion.ts`-এ `structuralPattern()` একটি `string` চাইলেও একটি `string[]` পাঠানো হচ্ছিল। এটি compile/typecheck-এ প্রকৃত TypeScript error তৈরি করত।

**Repair:** canonical 4-digit string (`r.first`) পাঠানো হয়েছে।

### 2. Analysis 03 duplicate detection-এর O(n²) bottleneck
Duplicate detection-এ `keys.indexOf()`-সহ প্রতি row-তে পূর্ণ array scan হচ্ছিল। 10,000+ row-এ এটি অত্যন্ত ধীর হতে পারত।

**Repair:** single-pass `Set` ভিত্তিক duplicate detection।

### 3. Master Result performance harness-এর compilation path
Performance harness generated JS-এর path ভুল ধরে `out/lib/master-result-sheet.js` খুঁজছিল, কিন্তু TypeScript output flat ছিল।

**Repair:** generated entry path corrected এবং dependency imports-এর `.js` rewrite রাখা হয়েছে।

### 4. Performance gate isolation
একই parent process-এর মধ্যে 1k/5k/10k sequential benchmark চালালে এই sandbox-এ 10k run resource contention-এ timeout করেছে, যদিও fresh isolated 10k process PASS করেছে।

**Repair:** CI gate এখন matrix-based: 1,000 / 5,000 / 10,000 rows আলাদা GitHub runner job হিসেবে চলে। এতে প্রতিটি benchmark fresh environment পায়।

### 5. npm CI network resilience
`npm ci`-তে transient registry timeout হলে একবারেই failure না দেখিয়ে retry configuration যোগ করা হয়েছে:
- 5 fetch retries
- 120s fetch timeout
- 3 complete `npm ci` attempts
- npm cache verification between attempts

### 6. Lockfile reproducibility
Workflow আর runtime-এ missing lockfile তৈরি করে source branch পরিবর্তন করবে না। Committed `package-lock.json` v3 বাধ্যতামূলক। এতে reproducibility বেশি নির্ভরযোগ্য হয়।

### 7. Workflow security / stability
- `contents: read`
- concurrency guard
- duplicate concurrent workflow cancellation
- canonical lockfile artifact handoff

## বাস্তব source-level verification

PASS:
- 107 engine static audit
- Data permanence audit
- Storage security audit
- Master Result count audit
- Master visual architecture audit
- Visual analysis layer audit
- GitHub/Android workflow audit
- Dependency lock audit
- Forensic release audit
- Workflow YAML parse

## Master Result performance — fresh isolated runs

| Dataset | Time | Budget | Result |
|---:|---:|---:|---|
| 1,000 | 11.72 sec | 60 sec | PASS |
| 5,000 | 17.08 sec | 120 sec | PASS |
| 10,000 | 32.01 sec | 180 sec | PASS |

প্রতিটি run-এ:
- 5D = 5
- 4D = 4
- 3D = 4
- 2D = 4
- 1D = 4
- research sets = 10
- analysis coverage = 107
- parts = 11
- modules = 28

## এখনও যেটা এই environment-এ সত্যিকারভাবে করা সম্ভব হয়নি

এই sandbox-এর npm registry access `TransportTimeoutError` দিচ্ছে। ফলে clean `npm ci` সম্পূর্ণ dependency tree download করে শেষ করা যায়নি। এর কারণে এখান থেকে একটি clean production Vite build এবং actual Android APK build চালিয়ে PASS বলা সম্ভব নয়।

এটি source repair-এর failure হিসেবে গণ্য করা হচ্ছে না; এটি environment dependency-install limitation।

### Final truth

- Source repair: PASS
- Source-level audits: PASS
- 1k/5k/10k Master Result benchmark: PASS
- Clean GitHub Actions run: **must be confirmed by the user's GitHub runner**
- Actual Android APK build: **must be confirmed by GitHub Actions**
- Actual emulator launch: **must be confirmed by GitHub Actions**

কোনো unverified external run-কে এই report PASS হিসেবে ঘোষণা করে না।


## Step 2 registry preflight hardening (V2.6)
- Replaced duplicated inline preflight blocks with `scripts/ci-registry-preflight.mjs`.
- The gate checks DNS resolution, HTTPS response from the canonical npm registry, and `npm ping`; it retries three times and fails closed.
- This sandbox still cannot resolve `registry.npmjs.org` (`EAI_AGAIN` / `Could not resolve host`). Therefore local Step 2 status is BLOCKED by sandbox DNS, not PASS. The clean GitHub runner must execute the same gate for a real PASS.

## V2.7 — Step 2 Registry Gate Precision Repair (2026-10-09)

Scope intentionally limited to Step 2 (`scripts/ci-registry-preflight.mjs`). No later build/test step was started.

- DNS lookup is now diagnostic evidence rather than an independent hard failure. This avoids a false negative in environments where HTTPS/npm access works through a proxy or custom resolver path.
- The actual gate still requires both HTTPS GET to the canonical npm registry ping endpoint and a successful `npm ping` using the npm client.
- Three attempts remain; if HTTPS/npm cannot reach the registry, the script fails closed and explicitly blocks `npm ci`.
- Local validation: JavaScript syntax check passed. Runtime check in this sandbox did **not** pass: DNS returned `EAI_AGAIN`, HTTPS fetch also failed with `EAI_AGAIN`; the script correctly exited non-zero and printed `STEP 2 BLOCKED`.
- Therefore Step 2 implementation is hardened, but real registry connectivity is **BLOCKED / NOT PASS** in this sandbox. A successful GitHub Actions runner execution is still required to mark Step 2 PASS. No claim of full connectivity success is made.

## V2.9 Step 2 isolated GitHub runner verification
- Added `.github/workflows/step2-registry-connectivity.yml` to run only Step 2 on a clean GitHub-hosted `ubuntu-latest` runner.
- The isolated workflow is manually runnable (`workflow_dispatch`) and also triggers when the registry gate files change on main/master.
- It runs Node 22 and `npm run ci:registry-preflight`; it does not install project dependencies or advance to Step 3.
- Local sandbox execution still cannot pass because DNS/HTTPS to `registry.npmjs.org` returns EAI_AGAIN. This is reported as BLOCKED, not PASS.
- Final Step 2 status remains NOT VERIFIED until the isolated GitHub Actions run completes successfully.
