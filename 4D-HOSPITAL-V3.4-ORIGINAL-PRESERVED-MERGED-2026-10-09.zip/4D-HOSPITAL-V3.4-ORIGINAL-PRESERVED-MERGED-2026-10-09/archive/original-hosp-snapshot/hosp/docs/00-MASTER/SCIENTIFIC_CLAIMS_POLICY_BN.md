# 4D HOSPITAL — Scientific Claims Policy

## Canonical wording

**100% implemented = software roadmap/engineering implementation complete.**

**100% scientifically proven = not claimed.**

**Future 4-digit prediction guarantee = not claimed.**

## Allowed interpretation

- Historical descriptive findings may be reported as observations.
- Inferential findings may be reported with their null model, p-value, effect size, uncertainty, multiple-testing status and assumptions.
- Predictive/model screens may report historical backtest/OOS performance.
- Evidence grades describe evidence under the declared protocol; they are not future-outcome probabilities.

## Prohibited interpretation

The UI, README, documentation and APIs must not convert a research score into “certain”, “guaranteed”, “100% accurate”, “winning probability”, or equivalent future-result claims.

## Required distinction

A passing software test answers: **“Did the implementation behave as specified?”**

A scientific study answers a different question: **“What does the evidence support under the declared assumptions and validation design?”**

Neither question by itself establishes that a random future 4-digit outcome is predictable.
