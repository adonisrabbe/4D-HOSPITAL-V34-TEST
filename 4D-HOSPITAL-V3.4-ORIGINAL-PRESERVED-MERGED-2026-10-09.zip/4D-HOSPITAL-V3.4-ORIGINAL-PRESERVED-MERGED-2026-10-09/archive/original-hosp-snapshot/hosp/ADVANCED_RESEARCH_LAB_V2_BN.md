# 4D Hospital — Advanced Research Laboratory v2

এই আপডেটে Investigator-এর সঙ্গে একটি আলাদা offline research layer যোগ হয়েছে।

## যুক্ত হয়েছে
1. Evidence Quality Engine — support / weak support / neutral / conflict / insufficient data
2. Bayesian posterior + 95% credible interval
3. Sequential Probability Ratio Test (SPRT)
4. Information theory: entropy, conditional entropy, mutual information, information gain, permutation entropy
5. Order-1/2/3 transition analysis
6. Variable-memory context tree diagnostics
7. Change-point / regime diagnostics
8. Permutation null-model laboratory + empirical p-value/effect size
9. Benjamini-Hochberg FDR correction
10. Redundancy graph + known mathematical dependency groups
11. Stability surface across multiple windows
12. Exact/approximate motif discovery
13. Lightweight interpretable symbolic candidate discovery with chronological train/test split
14. Conformal-style calibration diagnostics
15. Meta-evidence weighting with uncertainty/redundancy penalties
16. Research Constitution gates

## Research Constitution
কোনো analysis-কে final evidence হিসেবে promotion করার আগে sample size, chronological OOS, multiple-testing correction, redundancy, null model এবং stability gate পরীক্ষা করা হয়।

## গুরুত্বপূর্ণ সীমা
এই layer historical research diagnostics। কোনো score, posterior, consensus, formula বা model output-কে future 4-digit outcome-এর winning probability বা guarantee হিসেবে ব্যবহার করা হয় না।

## Validation performed
- Advanced Research Lab standalone TypeScript compile: PASS
- Advanced Research Lab runtime smoke test on 250 deterministic records: PASS
- Existing 107 engine audit: PASS
- Research Cycle E2E: PASS
- Core Research Layers audit: PASS
- Mathematical Research audit: PASS
- Investigator audit: PASS
- Full TS/TSX transpile syntax audit: PASS (93 files)
- package-lock generation: environment-blocked because npm registry/cache was unavailable; no fake lockfile was generated.
- Full application `tsc`: still environment-dependent on installed React/Vite type packages.
