# 4D HOSPITAL — Historical 4-Digit Numerical Research Laboratory

> **Research software, not a guaranteed prediction system.**

4D HOSPITAL is an offline/local-first historical 4-digit data analysis and validation platform. It is designed to make calculations, evidence, validation, failure modes, and reproducibility explicit.

## What “100% implemented” means

In this project, **100% implemented means the declared software roadmap and its engineering controls are implemented in the codebase and covered by the project's available audits/regression checks.**

It does **not** mean:

- 100% scientific proof that any future 4-digit outcome is predictable;
- a guaranteed future result;
- a guaranteed winning probability;
- that a high evidence/validation score is a probability of a future outcome;
- that all 107 catalogued analyses are independently proven predictive models.

## Scientific position

The platform follows:

**Data → Analysis → Evidence → Validation → Reproducibility**

Historical patterns, statistical significance, model scores, backtests, OOS results, FDR-adjusted findings, Bayesian diagnostics, conformal coverage, or evidence grades are interpreted only within their declared assumptions and sample sizes. Passing a research gate means the **research process** satisfied its declared controls; it does not prove that a random future draw can be predicted.

## Prediction/model screens

Some screens retain prediction/model terminology because they evaluate candidate signals and historical model performance. These outputs must be treated as **research candidates and validation diagnostics**, not guaranteed future numbers.

## Evidence hierarchy

A finding should move through progressively stronger controls:

Observation → Hypothesis → Statistical Test → Null Model → Effect Size → Multiple-Testing Control → Stability → Chronological OOS → Blind OOS → Reproducibility

No single pattern or model is automatically treated as independent proof.

## Reproducibility

Research runs can record dataset fingerprints, analysis/protocol versions, parameters, environment information, result hashes, and a tamper-evident run ledger. Blind OOS controls are intended to prevent discovery information from silently changing the confirmatory test.

## Scope and limitations

This repository is a historical mathematical/statistical research platform. It is not a lottery guarantee service, financial advice service, or medical decision system. Real-world conclusions remain subject to data quality, sampling assumptions, model assumptions, statistical uncertainty, and independent validation.

## Release honesty

The repository distinguishes **software verification** from **scientific truth**. A passing software audit demonstrates that the tested implementation behaved according to its specified checks. It does not manufacture evidence that future 4-digit outcomes are predictable.

## Final release certification boundary

This source bundle has passed the source-level research/static regression suite. The ZIP intentionally does not fabricate a lockfile: the canonical GitHub workflow generates a genuine `package-lock.json` on its networked runner when missing, audits it, passes the exact artifact to the validation/Android jobs, and then runs `npm ci`, the production build, Android/Gradle APK build, and emulator smoke test. The APK is considered certified only when those GitHub gates all PASS.

The included 1M performance check is a **synthetic stress-harness check**, not a certification that all 107 analyses complete within a fixed budget on every Android device.
