import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const manifestPath = path.join(root, 'benchmarks', 'manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const failures = [];
for (const d of manifest.datasets ?? []) {
  const p = path.join(root, 'benchmarks', d.file);
  if (!fs.existsSync(p)) { failures.push(`${d.id}: missing file`); continue; }
  const lines = fs.readFileSync(p, 'utf8').trim().split(/\r?\n/);
  const rows = lines.slice(1).map(x => x.split(','));
  if (rows.length !== d.rows) failures.push(`${d.id}: expected ${d.rows} rows, found ${rows.length}`);
  let previous = '';
  for (const [date, type, first, second, third, source] of rows) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) failures.push(`${d.id}: invalid date ${date}`);
    if (type !== 'BENCH') failures.push(`${d.id}: invalid draw_type`);
    for (const n of [first, second, third]) if (!/^\d{4}$/.test(n)) failures.push(`${d.id}: non-4-digit value ${n}`);
    if (date < previous) failures.push(`${d.id}: chronology violation`);
    previous = date;
  }
}
const hashes = {};
for (const d of manifest.datasets ?? []) {
  const p = path.join(root, 'benchmarks', d.file);
  if (fs.existsSync(p)) hashes[d.id] = crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
}
const out = { protocolVersion: manifest.protocolVersion, datasetCount: manifest.datasets.length, hashes };
if (failures.length) {
  console.error(JSON.stringify({ pass:false, failures, ...out }, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({ pass:true, ...out }, null, 2));
