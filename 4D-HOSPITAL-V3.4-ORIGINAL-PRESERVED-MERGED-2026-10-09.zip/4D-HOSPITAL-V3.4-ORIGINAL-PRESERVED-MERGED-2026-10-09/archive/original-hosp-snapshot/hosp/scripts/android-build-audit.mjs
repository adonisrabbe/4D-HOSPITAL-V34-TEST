import fs from 'node:fs';
import path from 'node:path';

const fail = (msg) => { console.error(`ANDROID BUILD AUDIT FAIL: ${msg}`); process.exit(1); };
const ok = (msg) => console.log(`ANDROID BUILD AUDIT PASS: ${msg}`);

const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const cap = fs.readFileSync(path.join(root, 'capacitor.config.ts'), 'utf8');

if (!pkg.dependencies?.['@capacitor/android']) fail('@capacitor/android dependency is missing');
if (!pkg.dependencies?.['@capacitor/core']) fail('@capacitor/core dependency is missing');
if (!pkg.devDependencies?.['@capacitor/cli']) fail('@capacitor/cli dependency is missing');

const versions = [
  pkg.dependencies['@capacitor/android'],
  pkg.dependencies['@capacitor/core'],
  pkg.devDependencies['@capacitor/cli'],
];
if (new Set(versions).size !== 1) fail(`Capacitor package versions are not aligned: ${versions.join(', ')}`);

if (!/^\d+\.\d+\.\d+$/.test(versions[0])) fail('Capacitor versions must be exact, not ranges');
if (!/webDir:\s*['"]dist['"]/.test(cap)) fail('capacitor.config.ts must use dist as webDir');
if (!/appId:\s*['"][^'"]+['"]/.test(cap)) fail('capacitor.config.ts is missing appId');

if (!fs.existsSync(path.join(root, 'dist', 'index.html'))) fail('dist/index.html is missing; run npm run build first');
if (!fs.existsSync(path.join(root, 'android'))) fail('android directory is missing after cap add android');
if (!fs.existsSync(path.join(root, 'android', 'gradlew'))) fail('android/gradlew is missing');

const gradle = fs.readFileSync(path.join(root, 'android', 'gradle', 'wrapper', 'gradle-wrapper.properties'), 'utf8');
if (!/distributionUrl=.*gradle-[0-9.]+-bin\.zip/.test(gradle)) fail('Gradle wrapper distribution is not configured');

const varsPath = path.join(root, 'android', 'variables.gradle');
if (fs.existsSync(varsPath)) {
  const vars = fs.readFileSync(varsPath, 'utf8');
  if (/compileSdkVersion\s*=\s*3[0-4]\b/.test(vars)) fail('compileSdkVersion is below Android API 35');
  if (/targetSdkVersion\s*=\s*3[0-4]\b/.test(vars)) fail('targetSdkVersion is below Android API 35');
}

ok(`Capacitor ${versions[0]} packages aligned`);
ok('dist and generated Android project present');
ok('Gradle wrapper present');
ok('Android build configuration gate passed');
