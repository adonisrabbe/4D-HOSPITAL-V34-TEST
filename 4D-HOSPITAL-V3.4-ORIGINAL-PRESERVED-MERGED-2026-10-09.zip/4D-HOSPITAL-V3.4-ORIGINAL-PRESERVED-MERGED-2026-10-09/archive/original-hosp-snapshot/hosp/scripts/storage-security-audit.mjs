import fs from 'node:fs';
const app=fs.readFileSync('App.tsx','utf8');
const sqlite=fs.readFileSync('lib/sqlite-results.ts','utf8');
const web=fs.readFileSync('lib/web-results-store.ts','utf8');
const cap=fs.readFileSync('capacitor.config.ts','utf8');
const checks=[
  ['SQLite encryption config',/androidIsEncryption:\s*true/.test(cap)],
  ['SQLite encryption migration mode',/'encryption'/.test(sqlite)],
  ['Legacy SQLite migration',/migrateLegacySQLiteDatabases/.test(app) && /LEGACY_DB_NAMES/.test(sqlite)],
  ['Encrypted backup',/encryptBackup/.test(app) && fs.existsSync('lib/backup-crypto.ts')],
  ['IndexedDB transaction',/readwrite/.test(web) && /durability/.test(web)],
  ['Online-only OCR guard',app.includes('https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js') && app.includes('navigator.onLine')],
  ['No duplicate src tree',!fs.existsSync('src')],
];
let bad=false; for(const [name,ok] of checks){ console.log(`${ok?'PASS':'FAIL'} ${name}`); if(!ok) bad=true; }
process.exit(bad?1:0);
