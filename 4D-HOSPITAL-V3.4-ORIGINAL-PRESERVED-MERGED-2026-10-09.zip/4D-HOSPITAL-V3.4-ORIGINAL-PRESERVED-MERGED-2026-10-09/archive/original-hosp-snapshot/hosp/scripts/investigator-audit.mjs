import fs from 'node:fs';
const must=[
  ['lib/investigator.ts','Investigator engine'],
  ['components/InvestigatorPanel.tsx','Investigator UI'],
  ['App.tsx','App integration']
];
for(const [f,label] of must){if(!fs.existsSync(f)) throw new Error(`${label} missing: ${f}`);}
const inv=fs.readFileSync('lib/investigator.ts','utf8');
const ui=fs.readFileSync('components/InvestigatorPanel.tsx','utf8');
const app=fs.readFileSync('App.tsx','utf8');
for(const x of ['buildInvestigatorReport','answerInvestigatorQuestion','analyzeMathEvidence','redundancyWarnings','nullModel']) if(!inv.includes(x)) throw new Error(`Investigator engine contract missing: ${x}`);
for(const x of ['Evidence Detective','Redundancy & Null-model Guard','Mathematical Evidence','Ask Research Investigator','paid AI/API']) if(!ui.includes(x)) throw new Error(`Investigator UI contract missing: ${x}`);
if(!app.includes('"investigator"') || !app.includes('InvestigatorPanel')) throw new Error('Investigator route not integrated');
console.log('INVESTIGATOR AUDIT: PASS');
