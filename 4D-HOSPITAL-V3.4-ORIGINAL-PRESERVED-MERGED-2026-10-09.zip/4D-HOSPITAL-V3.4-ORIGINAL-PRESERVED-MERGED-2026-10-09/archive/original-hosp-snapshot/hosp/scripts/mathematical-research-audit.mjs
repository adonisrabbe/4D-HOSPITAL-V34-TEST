import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const required=[
  'lib/number-theory-lab.ts',
  'components/NumberTheoryLabView.tsx',
  'MATHEMATICAL_RESEARCH_UPGRADE_BN.md'
];
const missing=required.filter(x=>!fs.existsSync(path.join(root,x)));
const src=fs.readFileSync(path.join(root,'lib/number-theory-lab.ts'),'utf8');
const checks={
  modulePresent:missing.length===0,
  propertyCatalogPresent:/MATH_PROPERTY_CATALOG/.test(src),
  kaprekar:/kaprekar6174|Kaprekar/.test(src),
  primeFamilies:/sophieGermainPrime|safePrime|wilsonPrime|emirp/.test(src),
  digitFamilies:/narcissistic|happy|harshad|smith|automorphic|factorion/.test(src),
  divisorFamilies:/powerful|squareFree|semiperfect|weird|tau|sigma|mobius/.test(src),
  sequenceFamilies:/fibonacci|lucas|triangular|pentagonal|hexagonal/.test(src),
  evidenceGate:/analyzeMathEvidence|STABLE|DRIFT|RARE/.test(src),
  noKalyanSignal:!(/Kalyan|কল্যাণ/i.test(src)),
  noGuaranteeLanguage:/guarantees|guaranteed result|not.*predictive/i.test(src)
};
console.log(JSON.stringify({checks,missing},null,2));
if(missing.length||Object.values(checks).some(v=>v===false))process.exit(2);
