import fs from 'node:fs';

const app = fs.readFileSync('App.tsx', 'utf8');
const failures = [];

if (!app.includes('let localSessionUser: AuthUser | null = null')) failures.push('In-memory local session state is missing');
if (!app.includes('function requireLocalAdmin(action:string)')) failures.push('Local admin authorization guard is missing');
if (/function lsIsAdmin\(\): boolean \{\s*return sessionStorage\.getItem\(LS_ADMIN\)/.test(app)) failures.push('sessionStorage is still trusted as admin authorization');
if (!app.includes('const adminOnly =')) failures.push('adminOnly endpoint classification is missing');
if (!app.includes('if (adminOnly &&')) failures.push('adminOnly endpoints are not gated');
if (!app.includes('requireLocalAdmin(`${method} ${pathname}`)')) failures.push('API layer does not enforce local admin authorization');
if (!app.includes('const account=users.find')) failures.push('Managed-user login path is missing');
if (!app.includes('setLocalSessionUser(user)')) failures.push('Managed-user session establishment is missing');
if (app.includes('Math.random()')) failures.push('Non-cryptographic randomness remains in application code');
if (!app.includes('TTL=0 is documented as never-expire')) failures.push('Invite TTL=0 regression guard missing');
if (!app.includes('const expiresAt: string | null = ttlHours === 0 ? null')) failures.push('Invite TTL=0 is not represented as non-expiring');
if (!app.includes('if(!inv || (inv.expiresAt &&')) failures.push('Invite validation does not handle non-expiring invites');
if (!app.includes('online-only') || !app.includes('ইন্টারনেট থাকলে Tesseract OCR CDN থেকে engine load হবে') || !app.includes('ইন্টারনেট না থাকলে OCR চলবে না')) failures.push('OCR online-only/unavailable-offline state is not explicit in UI');

if (failures.length) {
  console.error('LOCAL AUTH / RELEASE HARDENING AUDIT FAILED');
  for (const f of failures) console.error(`- ${f}`);
  process.exit(1);
}
console.log('LOCAL AUTH / RELEASE HARDENING AUDIT PASS');
