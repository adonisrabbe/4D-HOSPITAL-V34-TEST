import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';

const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'4d-hospital-audit-'));
fs.writeFileSync(path.join(tmp,'package.json'),JSON.stringify({type:'commonjs'}));
const root=path.resolve(new URL('..',import.meta.url).pathname);
const files=['lib/number-theory-lab.ts','lib/analysis-engine-107.ts','lib/analysis-catalog.ts','lib/analysis-contract.ts','lib/sequence-math.ts','lib/advanced-validation.ts','lib/advanced-models.ts','lib/canonical-data.ts','lib/advanced-research-lab.ts'];
execFileSync('tsc',['--module','commonjs','--target','es2022','--moduleResolution','node','--esModuleInterop','--skipLibCheck','--outDir',tmp,...files.map(f=>path.join(root,f))],{cwd:root,stdio:'pipe'});
const require=createRequire(import.meta.url);
const { classify4D, MATH_PROPERTY_CATALOG, analyzeMathEvidence }=require(path.join(tmp,'number-theory-lab.js'));
const { run107Analysis }=require(path.join(tmp,'analysis-engine-107.js'));
const { benjaminiHochberg, exactBinomialTwoSided, permutationGroupDifference, buildAdvancedResearchReport }=require(path.join(tmp,'advanced-research-lab.js'));

const failures=[];
function check(name, fn){try{fn();}catch(e){failures.push({name,error:String(e?.message??e)});}}

// Independent known-value regression set. Values are interpreted as the app's
// four-character 4D representation, so leading zeroes are intentional.
const known=[
 ['prime',1009,true],['twinPrime',1019,true],['cousinPrime',1009,true],['sexyPrime',1013,true],
 ['mersennePrime',8191,true],['fermatPrime',257,true],['sophieGermainPrime',1013,true],['safePrime',1019,true],
 ['wilsonPrime',563,true],['emirp',1009,true],['palindromicPrime',1221,false],['repunitPrime',1111,false],
 ['primeGap2',1019,true],['primeGap4',1009,true],['primeGap6',1013,true],
 ['digitalRoot',9999,9],['digitSum',1234,10],['palindrome',1221,true],['repdigit',1111,true],
 ['kaprekar',9999,true],['kaprekar6174',3524,true],['narcissistic',1634,true],['happy',19,true],['harshad',18,true],
 ['smith',666,true],['automorphic',76,true],['factorion',1,true],['factorion',145,true],['strobogrammatic',1001,true],
 ['perfectSquare',2025,true],['perfectCube',1728,true],['triangular',5050,true],['pentagonal',145,true],['hexagonal',45,true],
 ['fibonacci',1597,true],['lucas',123,true],['perfect',6,true],['abundant',12,true],['deficient',11,true],
 ['sphenic',30,true],['powerful',360,false],['squareFree',30,true],['semiperfect',20,true],['weird',70,true],
 ['tau',360,24],['sigma',360,1170],['phi',360,96],['mobius',30,-1],['mobius',12,0],['mobius',0,0],
 ['amicable',220,true],['practical',12,true],['untouchable',2,true],['collatz',13,true],['pythagorean',11,true],
 ['goldbach',10,true],['catalan',429,true],['octahedral',146,true],['pyramidal',30,true],['centeredPolygonal',37,true],
 ['factorial',720,true],['superfactorial',288,true],['aliquotCycle',6,true],['primorialRelated',30,true]
];
for(const [id,n,expected] of known){
  check(`math:${id}:${n}`,()=>assert.equal(classify4D(n).properties[id],expected));
}
check('math catalog count is 61',()=>assert.equal(MATH_PROPERTY_CATALOG.length,61));
check('math evidence has every catalog property',()=>assert.equal(analyzeMathEvidence(Array.from({length:80},(_,i)=>String((1000+i*37)%10000).padStart(4,'0'))).length,MATH_PROPERTY_CATALOG.length));

// The public 107 analysis executor must produce exactly one executable result
// for every public ID, with deterministic shape and no REQUIRES_FIX status.
const draws=Array.from({length:120},(_,i)=>({
 id:i+1, company:'TEST', date:`2026-01-${String((i%28)+1).padStart(2,'0')}`,
 drawNo:String(i+1), first:String((1000+i*37)%10000).padStart(4,'0'), second:'1234', third:'5678', special:[], consolation:[]
}));
const r=run107Analysis(draws);
check('107 result count',()=>assert.equal(r.length,107));
check('107 IDs contiguous',()=>assert.deepEqual(r.map(x=>x.id),Array.from({length:107},(_,i)=>i+1)));
for(const x of r){
  check(`analysis-${x.id}-has-name`,()=>assert.ok(x.name));
  check(`analysis-${x.id}-has-sample`,()=>assert.equal(x.sampleSize,120));
  check(`analysis-${x.id}-has-raw`,()=>assert.notEqual(x.raw,undefined));
  check(`analysis-${x.id}-has-evidence`,()=>assert.ok(['SUPPORT','WEAK_SUPPORT','NEUTRAL','CONFLICT','INSUFFICIENT_DATA'].includes(x.evidence)));
  check(`analysis-${x.id}-no-requires-fix`,()=>assert.notEqual(x.status,7));
  check(`analysis-${x.id}-version`,()=>assert.equal(x.calculationVersion,'107-core-v1'));
}

// Research null model: mean-shift must be tested by group-label permutation,
// not by shuffling values (which leaves the mean unchanged).
const shifted=[...Array(20)].map((_,i)=>9000+i).concat([...Array(80)].map((_,i)=>1000+i));
const nullResult=permutationGroupDifference(shifted,20,1000,12345);
check('null model detects strong group shift',()=>assert.ok(nullResult.empiricalP<0.01));
check('null model is centered near zero',()=>assert.ok(Math.abs(nullResult.mean)<100));
check('null model has positive observed effect',()=>assert.ok(nullResult.effectSize>5));

check('exact binomial fair coin center',()=>assert.ok(Math.abs(exactBinomialTwoSided(50,100,.5)-1)<1e-12));
check('exact binomial extreme',()=>assert.ok(exactBinomialTwoSided(100,100,.5)<1e-20));

const bh=benjaminiHochberg([{id:'a',pValue:.001},{id:'b',pValue:.02},{id:'c',pValue:.9},{id:'d',pValue:.03}]);
check('BH output count',()=>assert.equal(bh.length,4));
check('BH q monotonic by p order',()=>{const q=bh.slice().sort((a,b)=>a.pValue-b.pValue).map(x=>x.qValue);for(let i=1;i<q.length;i++)assert.ok(q[i]>=q[i-1]-1e-12)});
check('BH rejects strong result',()=>assert.equal(bh.find(x=>x.id==='a').rejected,true));
check('BH does not reject null result',()=>assert.equal(bh.find(x=>x.id==='c').rejected,false));

const researchRows=shifted.map(String).map(x=>x.padStart(4,'0'));
const report=buildAdvancedResearchReport(researchRows);
check('research report v3',()=>assert.equal(report.version,'research-lab-v3'));
check('real recent-baseline null test present',()=>assert.ok(report.nullTests.recentBaseline));
check('research null p is finite',()=>assert.ok(report.nullTests.recentBaseline.empiricalP>0&&report.nullTests.recentBaseline.empiricalP<=1));
check('FDR uses multiple real hypotheses',()=>assert.ok(report.fdr.length>=10));
check('FDR p-values valid',()=>report.fdr.forEach(x=>assert.ok(x.pValue>=0&&x.pValue<=1)));
check('FDR q-values valid',()=>report.fdr.forEach(x=>assert.ok(x.qValue>=0&&x.qValue<=1)));

console.log(JSON.stringify({pass:failures.length===0,checks: {knownMathCases:known.length,analysis107:r.length,fdrTests:report.fdr.length},failures},null,2));
if(failures.length) process.exit(1);
