import fs from 'node:fs';
const p='lib/advanced-research-lab.ts';
const s=fs.readFileSync(p,'utf8');
const required=[
 ['Evidence Quality','EvidenceItem'],['Bayesian','bayesianBernoulli'],['SPRT','sprt'],
 ['Information Theory','mutualInformation'],['Higher-order transitions','transitionLayer'],
 ['Context Tree','contextTree'],['Change-point','detectChangePoints'],['Null model','permutationGroupDifference'],['Exact binomial p-value','exactBinomialTwoSided'],
 ['FDR','benjaminiHochberg'],['Redundancy graph','redundancyGraph'],['Stability surface','stabilitySurface'],
 ['Motif','motifSearch'],['Symbolic discovery','symbolicDiscovery'],['Conformal','conformalCalibration'],
 ['Research Constitution','buildResearchConstitution'],['Meta evidence','metaWeights']
];
const checks=required.map(([name,token])=>({name,ok:s.includes(token)}));
checks.push({name:'No predictive certainty API',ok:!/(winning probability|guaranteed outcome|predictable future)/i.test(s)});
checks.push({name:'Research report version',ok:s.includes("version:'research-lab-v3'")});
checks.push({name:'No invariant-mean permutation misuse',ok:!s.includes('permutationNull(mean(clean.map(Number)),clean.map(Number),mean')});
const bad=checks.filter(x=>!x.ok);
console.log(JSON.stringify({pass:!bad.length,checks,bad},null,2));
if(bad.length)process.exit(1);

checks.push({name:'No invariant-mean permutation misuse',ok:!s.includes('permutationNull(mean(clean.map(Number)),clean.map(Number),mean')});
