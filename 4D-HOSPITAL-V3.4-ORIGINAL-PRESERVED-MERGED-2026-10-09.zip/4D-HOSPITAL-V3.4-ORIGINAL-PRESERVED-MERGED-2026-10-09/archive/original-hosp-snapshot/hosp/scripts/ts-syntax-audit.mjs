import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
const skip=new Set(['node_modules','.git','dist','android']);
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(skip.has(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(/\.(ts|tsx)$/.test(e.name))files.push(p)}}
walk('.');
let bad=0;
for(const f of files){const src=fs.readFileSync(f,'utf8');const out=ts.transpileModule(src,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext},reportDiagnostics:true,fileName:f});const errors=(out.diagnostics||[]).filter(d=>d.category===ts.DiagnosticCategory.Error);if(errors.length){bad++;console.error('SYNTAX FAIL',f);for(const d of errors)console.error(ts.flattenDiagnosticMessageText(d.messageText,' '));}}
console.log(`TS/TSX syntax audit: ${bad===0?'PASS':'FAIL'} (${files.length} files)`);
if(bad)process.exit(1);
