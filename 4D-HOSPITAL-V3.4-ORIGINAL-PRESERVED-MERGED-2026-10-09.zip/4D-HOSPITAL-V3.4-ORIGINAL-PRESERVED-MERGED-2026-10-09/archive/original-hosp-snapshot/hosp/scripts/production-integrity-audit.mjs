import fs from 'node:fs';
import path from 'node:path';

const required = [
  'package.json','index.html','index.css','main.tsx','App.tsx','capacitor.config.ts',
  'lib/analysis-contract.ts','lib/analysis-registry.ts','lib/research-governance.ts',
  'lib/scientific-core-v3.ts','lib/advanced-research-lab.ts','lib/investigator.ts',
  'benchmarks/manifest.json','benchmarks/README_BN.md','SECURITY.md','.github/dependabot.yml',
  '.github/workflows/security.yml'
];
const missing = required.filter(x => !fs.existsSync(path.join(process.cwd(),x)));
const index = fs.readFileSync('index.html','utf8');
const css = fs.readFileSync('index.css','utf8');
const findings = [];
if (/fonts\.googleapis\.com|fonts\.gstatic\.com/.test(index)) findings.push('External Google Fonts dependency remains in index.html');
if (!/Content-Security-Policy/.test(index)) findings.push('CSP meta policy is missing');
if (!/Noto Sans Bengali Local/.test(css)) findings.push('Local Bengali font is not configured');
if (missing.length) findings.push(`Missing required files: ${missing.join(', ')}`);
const result = {pass: findings.length===0, offlineFont: !/fonts\.googleapis\.com|fonts\.gstatic\.com/.test(index), csp: /Content-Security-Policy/.test(index), benchmark: fs.existsSync('benchmarks/manifest.json'), findings};
console.log(JSON.stringify(result,null,2));
if(findings.length) process.exit(1);
