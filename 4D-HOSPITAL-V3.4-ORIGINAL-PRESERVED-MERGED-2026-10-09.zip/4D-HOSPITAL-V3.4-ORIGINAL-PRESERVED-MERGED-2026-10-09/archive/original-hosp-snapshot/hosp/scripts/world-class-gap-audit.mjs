import fs from 'node:fs';
const required=['lib/analysis-registry.ts','lib/evidence-engine.ts','lib/evidence-interpreter.ts','lib/stratified-meta-analysis.ts','lib/research-run-ledger.ts','lib/blind-oos-v2.ts','lib/performance-stress.ts','lib/native-secure-key.ts','scripts/install-android-keystore-plugin.mjs','scripts/performance-stress-audit.mjs'];
const errors=[];for(const f of required){if(!fs.existsSync(f))errors.push(`missing ${f}`);else if(fs.statSync(f).size<500)errors.push(`too small ${f}`);}
const reg=fs.readFileSync('lib/analysis-registry.ts','utf8');for(const s of ['ANALYSIS_REGISTRY','validateFullAnalysisRegistry','nullHypothesis','multipleTestingFamily','oosStatus'])if(!reg.includes(s))errors.push(`registry missing ${s}`);
const ev=fs.readFileSync('lib/evidence-engine.ts','utf8');for(const s of ['observation','H0','adjustedPValue','evidenceGrade','bh('])if(!ev.includes(s))errors.push(`evidence missing ${s}`);
const perf=fs.readFileSync('lib/performance-stress.ts','utf8');for(const n of ['1000','10000','100000','500000','1000000'])if(!perf.includes(n))errors.push(`performance target missing ${n}`);
console.log(errors.length?'WORLD_CLASS_GAP_AUDIT: FAIL\n'+errors.join('\n'):'WORLD_CLASS_GAP_AUDIT: PASS');process.exitCode=errors.length?1:0;
