import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const root=process.cwd();
const fail=(m)=>{console.error(`A-Z FINAL REGRESSION FAIL: ${m}`);process.exit(1)};
const read=(f)=>fs.readFileSync(path.join(root,f),'utf8');

// Source-tree invariants.
if(fs.existsSync(path.join(root,'src'))) fail('duplicate src/ runtime tree exists');
if(!fs.existsSync(path.join(root,'main.tsx'))) fail('canonical main.tsx missing');
if(!fs.existsSync(path.join(root,'index.html'))) fail('index.html missing');

// Every local TS/TSX relative import must resolve to a real source module.
const missing=[];
for(const dir of ['.','lib','components','hooks','pages','types']){
  const base=path.join(root,dir);
  if(!fs.existsSync(base)) continue;
  for(const name of fs.readdirSync(base)){
    const p=path.join(base,name); if(!/\.(ts|tsx)$/.test(p) || name.endsWith('.d.ts')) continue;
    const s=read(path.relative(root,p));
    for(const m of s.matchAll(/(?:from\s*["']|import\s*\(["'])(\.[^"']+)["']/g)){
      const b=path.resolve(path.dirname(p),m[1]);
      const candidates=[b,`${b}.ts`,`${b}.tsx`,`${b}.js`,`${b}.jsx`,path.join(b,'index.ts'),path.join(b,'index.tsx')];
      if(!candidates.some(fs.existsSync)) missing.push(`${path.relative(root,p)} -> ${m[1]}`);
    }
  }
}
if(missing.length) fail(`missing local imports: ${missing.join(', ')}`);

// Capacitor/Vite relative-base public assets must not be root-absolute.
for(const f of ['App.tsx','index.html','public/manifest.json']){
  if(/(?:src|href|"src"\s*:\s*)=["']\/(?:cbc-logo|favicon|manifest)/.test(read(f)) || /"src"\s*:\s*"\/(?:cbc-logo|favicon|manifest)/.test(read(f))) fail(`root-absolute public asset in ${f}`);
}
const app=read('App.tsx');
const sqlite=read('lib/sqlite-results.ts');
const obs=read('lib/research-observations.ts');
if(!app.includes('import.meta.env.BASE_URL')) fail('App public asset base handling missing');
if(app.includes('Math.random()')) fail('Math.random remains in application security/token path');
if(/\^\\d\{4\}-\\d\{2\}-\\d\{2}\$/.test(app)) fail('Raw date regex remains in App.tsx; canonical isValidISODate must be used');
if(!app.includes('function nextManagedUserId')) fail('Managed user IDs still rely on timestamp collision risk');
if(!app.includes('শেষ active admin account')) fail('Last-active-admin safety guard missing');
if(!sqlite.includes('isValidISODate(date)')) fail('SQLite date validation does not use canonical calendar validator');
if(!obs.includes('isValidISODate(x?.date)')) fail('Research observation date validation does not use canonical calendar validator');
if(app.includes('lsSetGuestCode(')) fail('legacy raw guest-code setter remains');
if(app.includes('adminSessionAuthenticated')) fail('stale admin session symbol remains');
if(!app.includes('const account=users.find')) fail('managed-user login path missing');
if(!app.includes('setLocalSessionUser(user)')) fail('managed-user session is not established');
if(!app.includes('crypto.randomUUID().replace')) fail('invite token is not crypto-randomUUID based');
if(!app.includes('isValidISODate')) fail('UI does not use canonical date validator');
if(app.includes('src="/cbc-logo.png"')) fail('absolute logo path remains');

const canonical=read('lib/canonical-data.ts');
if(!canonical.includes('export function isValidISODate')) fail('canonical ISO date validator missing');

// Prove the calendar validator is not merely regex validation.
const tmp=path.join('/tmp',`4d-a2z-date-${process.pid}.cjs`);
const out=path.join('/tmp',`4d-a2z-date-${process.pid}`);
const {execFileSync}=await import('node:child_process');
execFileSync('tsc',['--module','commonjs','--target','es2022','--moduleResolution','node','--skipLibCheck','--outDir',out,path.join(root,'lib/canonical-data.ts')],{stdio:'pipe'});
const mod=await import(`file://${path.join(out,'canonical-data.js')}`);
assert.equal(mod.isValidISODate('2026-02-28'),true);
assert.equal(mod.isValidISODate('2026-02-29'),false);
assert.equal(mod.isValidISODate('2024-02-29'),true);
assert.equal(mod.isValidISODate('2026-13-01'),false);
fs.rmSync(out,{recursive:true,force:true}); fs.rmSync(tmp,{force:true});

// No stale canonical source references remain in documentation.
const stale=[];
for(const p of fs.readdirSync(root,{recursive:true})){ if(!String(p).endsWith('.md')) continue; const abs=path.join(root,p); const s=fs.readFileSync(abs,'utf8'); if(/src\/(?:lib|main\.tsx)/.test(s)) stale.push(String(p)); }
if(stale.length) fail(`stale src/ references in docs: ${stale.join(', ')}`);

// Release security invariants.
const html=read('index.html');
if(!html.includes("Content-Security-Policy")) fail('CSP missing');
if(/fonts\.googleapis|fonts\.gstatic/.test(html)) fail('remote font dependency remains');
if(!fs.existsSync(path.join(root,'SECURITY.md'))) fail('SECURITY.md missing');

console.log('A-Z FINAL REGRESSION AUDIT PASS');
