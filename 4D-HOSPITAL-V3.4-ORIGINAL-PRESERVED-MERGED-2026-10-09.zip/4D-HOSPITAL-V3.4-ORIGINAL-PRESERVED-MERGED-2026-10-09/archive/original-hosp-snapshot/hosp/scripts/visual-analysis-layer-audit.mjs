import fs from 'node:fs';
const app=fs.readFileSync('App.tsx','utf8');
const comp=fs.readFileSync('components/AnalysisVisualWorkspace.tsx','utf8');
const required=['lstm','markov','genetic','outlier2','backtest','sliding','consensus','alerts','performance','neighbor','deep','predictions'];
const failures=[];
if(!app.includes('AnalysisVisualDashboard')||!app.includes('AnalysisDetailView')||!app.includes('AnalysisDeepDiveView')) failures.push('3-layer components are not wired');
if(!app.includes('onOpen={openAnalysisDetail}')) failures.push('detail library tile callback missing');
if(!app.includes('onFull={openFullAnalysis}')) failures.push('full functional analysis callback missing');
for(const k of required){ if(!comp.includes(`key:"${k}"`)) failures.push(`missing analysis key: ${k}`); }
if(!comp.includes('av-detail-folder-grid')) failures.push('12-folder detail layer missing');
if(!comp.includes('OPEN FULL FUNCTIONAL ANALYSIS')) failures.push('deep-to-functional action missing');
if(comp.includes('0.87')||comp.includes('96.2%')||comp.includes('94.7%')) failures.push('hard-coded predictive-looking demo score found in visual workspace');
console.log(failures.length?'VISUAL ANALYSIS LAYER AUDIT FAIL':'VISUAL ANALYSIS LAYER AUDIT PASS');
if(failures.length) failures.forEach(x=>console.log(' - '+x));
process.exit(failures.length?1:0);
