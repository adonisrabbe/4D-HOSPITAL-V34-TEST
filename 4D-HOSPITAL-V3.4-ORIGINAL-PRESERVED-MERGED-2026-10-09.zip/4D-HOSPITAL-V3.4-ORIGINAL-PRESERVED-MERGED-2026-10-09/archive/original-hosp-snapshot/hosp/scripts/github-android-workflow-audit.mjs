import fs from 'node:fs';
import path from 'node:path';

const file = path.join(process.cwd(), '.github', 'workflows', 'build-and-validate.yml');
const s = fs.readFileSync(file, 'utf8');
const fail = (m) => { console.error(`GITHUB ANDROID WORKFLOW AUDIT FAIL: ${m}`); process.exit(1); };
const pass = (m) => console.log(`GITHUB ANDROID WORKFLOW AUDIT PASS: ${m}`);

const required = [
  "actions/setup-node@v4",
  "actions/setup-java@v5",
  "android-actions/setup-android@v4",
  "gradle/actions/setup-gradle@v6",
  "gradle/actions/wrapper-validation@v6",
  "actions/download-artifact@v4",
  "reactivecircus/android-emulator-runner@v2",
  "npm ci --ignore-scripts --no-audit --no-fund",
  "npx cap add android",
  "npx cap sync android",
  "./gradlew assembleDebug --no-daemon --stacktrace",
  "sha256sum",
  "unzip -t",
  "api-level: 35",
  "adb install -r artifact/app-debug.apk",
  "adb shell monkey -p com.cbc.lt4my.hospital 1",
  "adb shell pidof com.cbc.lt4my.hospital",
];
for (const x of required) if (!s.includes(x)) fail(`missing required workflow guard: ${x}`);
if (!s.includes("name: 4D HOSPITAL - Validate and Build Android APK")) fail('canonical workflow name missing');
if (!s.includes('name: 4D-HOSPITAL-package-lock')) fail('canonical lock artifact missing');
if (!s.includes('needs: validate-web')) fail('android build does not depend on web validation');
if (!s.includes('needs: android-debug')) fail('emulator smoke does not depend on the exact APK build job');
if (!s.includes("platforms;android-35")) fail('Android API 35 platform is not explicitly installed');
if (!s.includes("build-tools;35.0.0")) fail('Android build-tools 35.0.0 are not explicitly installed');
pass('canonical dependency handoff is present');
pass('Android SDK, Gradle, APK integrity and emulator gates are present');
pass('workflow hardening audit passed');
