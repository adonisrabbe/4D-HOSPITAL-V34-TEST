$ErrorActionPreference = "Stop"
Write-Host "Generating the canonical npm lockfile..."
& "C:\Program Files\nodejs\npm.cmd" install --package-lock-only --ignore-scripts --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw "npm lockfile generation failed with exit code $LASTEXITCODE" }
Write-Host "Verifying dependency lock..."
& "C:\Program Files\nodejs\node.exe" scripts/dependency-lock-audit.mjs
if ($LASTEXITCODE -ne 0) { throw "Dependency lock audit failed with exit code $LASTEXITCODE" }
Write-Host "Canonical package-lock.json generated and verified."
