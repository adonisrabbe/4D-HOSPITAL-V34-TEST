import { readFileSync } from 'node:fs';
const files=['lib/scientific-core-v3.ts','components/ScientificResearchDashboard.tsx','App.tsx'];
for(const f of files){const s=readFileSync(f,'utf8'); if(!s.includes('ScientificResearch') && !s.includes('scientific-core-v3')) throw new Error(`missing integration: ${f}`);}
const core=readFileSync('lib/scientific-core-v3.ts','utf8');
for(const token of ['adversarial','reproducibility','failureIntelligence','leakage','buildScientificCoreV3']) if(!core.includes(token)) throw new Error(`missing ${token}`);
console.log('Scientific Core v3 audit: PASS');
