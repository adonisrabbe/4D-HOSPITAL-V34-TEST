import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);

const root=process.cwd();
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'4d-hospital-scientific-guard-'));
const files=['lib/research-governance.ts','lib/scientific-guards.ts','lib/number-theory-lab.ts','lib/advanced-validation.ts','lib/advanced-research-lab.ts','lib/analysis-engine-107.ts','lib/analysis-catalog.ts','lib/analysis-contract.ts','lib/canonical-data.ts'];
execFileSync('tsc',['--module','commonjs','--target','es2022','--moduleResolution','node','--esModuleInterop','--skipLibCheck','--outDir',tmp,...files.map(f=>path.join(root,f))],{cwd:root,stdio:'pipe'});
const req=(name)=>require(path.join(tmp,name+'.js'));
const {classify4D}=req('number-theory-lab');
const guards=req('scientific-guards');
const governance=req('research-governance');
const validation=req('advanced-validation');
const research=req('advanced-research-lab');
const {run107Analysis}=req('analysis-engine-107');
const {ANALYSIS_CATALOG}=req('analysis-catalog');
const {ANALYSIS_CONTRACTS}=req('analysis-contract');
const failures=[];
function check(name,fn){try{fn();}catch(e){failures.push({name,error:String(e?.message??e)});}}

check('pythagorean rejects 1',()=>assert.equal(classify4D(1).properties.pythagorean,false));
check('pythagorean recognizes 3-4-5 leg',()=>assert.equal(classify4D(3).properties.pythagorean,true));
check('pythagorean recognizes 11-60-61 leg',()=>assert.equal(classify4D(11).properties.pythagorean,true));
check('pythagorean identity covers 9999',()=>assert.equal(classify4D(9999).properties.pythagorean,true));

const sparse=guards.sparseContingencyTest(Array.from({length:10},(_,i)=>Array.from({length:10},(_,j)=>i===j?1:0)),1500,123);
check('sparse contingency uses Monte Carlo',()=>assert.equal(sparse.method,'MONTE_CARLO_PERMUTATION'));
check('sparse contingency p is valid',()=>assert.ok(sparse.pValue>=0&&sparse.pValue<=1));

const cp=guards.correctedChangePoints([...Array(50).fill(0),...Array(50).fill(10)],10,1000,123);
check('change point detects candidate',()=>assert.ok(cp.length>0));
check('change point global p is corrected',()=>assert.ok(cp[0].globalPValue>=0&&cp[0].globalPValue<=1));

const spectral=guards.spectralPeakSignificance(Array.from({length:80},(_,i)=>Math.sin(2*Math.PI*i/8)),800,123);
check('spectral guard exists',()=>assert.ok(spectral));
check('spectral global p valid',()=>assert.ok(spectral.globalPValue>=0&&spectral.globalPValue<=1));

const sym=guards.leakageSafeSymbolicDiscovery(Array.from({length:90},(_,i)=>1000+i*3));
check('symbolic split frozen',()=>assert.equal(sym.frozen,true));
check('symbolic has final test',()=>assert.ok(sym.finalTestSize>0&&sym.finalTestMse!==null));
check('symbolic selects on validation not final test',()=>assert.equal(sym.candidates.filter(x=>x.selected).length,1));

const conf=guards.discreteConformal4D(Array.from({length:100},(_,i)=>String((1000+i*7)%10000).padStart(4,'0')),.1);
check('conformal has calibration and test sets',()=>assert.ok(conf.calibrationSize>0&&conf.testSize>0));
check('conformal set size is discrete',()=>assert.ok(conf.avgSetSize>=1));

const draws=Array.from({length:120},(_,i)=>({id:i+1,company:i%2?'A':'B',date:`2026-01-${String((i%28)+1).padStart(2,'0')}`,drawNo:String(i+1),first:String((1000+i*37)%10000).padStart(4,'0'),second:'1234',third:'5678',special:[],consolation:[]}));
const out=run107Analysis(draws);
check('107 remains complete',()=>assert.equal(out.length,107));
check('107 ids remain contiguous',()=>assert.deepEqual(out.map(x=>x.id),Array.from({length:107},(_,i)=>i+1)));
check('bootstrap uses percentile interval',()=>assert.equal(out.find(x=>x.id===57).raw.method,'PERCENTILE_BOOTSTRAP'));
check('change point has global correction field',()=>assert.ok(out.find(x=>x.id===68).raw===null || Object.hasOwn(out.find(x=>x.id===68).raw,'pValue')));
check('spectral peak includes global significance',()=>assert.ok(out.find(x=>x.id===72).raw===null || Object.hasOwn(out.find(x=>x.id===72).raw,'globalSignificance')));
check('runs test has formal p value',()=>assert.ok(out.find(x=>x.id===84).raw===null || Object.hasOwn(out.find(x=>x.id===84).raw,'pValue')));

const vr=validation.digitIndependence(draws);
check('digit independence exposes method',()=>assert.ok(vr.every(x=>x.method==='MONTE_CARLO_PERMUTATION'||x.method==='CHI_SQUARE')));
const ar=research.buildAdvancedResearchReport(draws.map(x=>x.first));
check('advanced report global FDR exists',()=>assert.ok(Array.isArray(ar.globalFdr)));
check('global FDR covers local inferential family',()=>assert.equal(ar.globalFdr.length,ar.fdr.length));
check('advanced change point uses global p',()=>assert.ok(ar.changePoints.every(x=>x.globalPValue!==undefined)));
check('advanced symbolic candidates are frozen',()=>assert.ok(ar.symbolic.every(x=>x.selected!==undefined)));

const freezeRows=draws.slice(0,80);
const freeze=governance.createSignalFreeze({rows:freezeRows,discoveryEndIndex:60,oosStartIndex:60,signalIds:['math:parity','math:digitalRoot'],frozenAt:'2026-10-05T00:00:00.000Z'});
check('signal freeze stores discovery fingerprint',()=>assert.ok(freeze.discoveryFingerprint));
const freezeValidation=governance.validateSignalFreeze(freeze,freezeRows,['math:parity','math:digitalRoot']);
check('unchanged freeze validates',()=>assert.equal(freezeValidation.valid,true));
const changed=freezeRows.map((x,i)=>i===10?{...x,first:'9999'}:x);
check('changed discovery invalidates freeze',()=>assert.equal(governance.validateSignalFreeze(freeze,changed,freeze.signalIds).valid,false));
check('blind OOS rejects identical partitions',()=>assert.throws(()=>governance.assertBlindOOS(freezeRows,freezeRows)));

check('catalog remains 107',()=>assert.equal(ANALYSIS_CATALOG.length,107));
check('contract remains 107',()=>assert.equal(ANALYSIS_CONTRACTS.length,107));
check('every contract has validation text',()=>assert.ok(ANALYSIS_CONTRACTS.every(x=>x.validation&&x.validation.length>10)));
check('every contract has dependency metadata',()=>assert.ok(ANALYSIS_CONTRACTS.every(x=>Array.isArray(x.dependencyIds)&&x.redundancyGroup)));

const source=fs.readFileSync(path.join(root,'lib/advanced-research-lab.ts'),'utf8');
check('legacy symbolic test-selection code removed',()=>assert.equal(source.includes('return candidates.sort((a,b)=>a.testMse-b.testMse'),false));
check('legacy approximate change-point p removed',()=>assert.equal(source.includes('normalApproxP(z)'),false));
check('pythagorean definition documents the identity',()=>assert.ok(fs.readFileSync(path.join(root,'lib/number-theory-lab.ts'),'utf8').includes('Every integer n >= 3 occurs as a side')));

if(failures.length){console.error(JSON.stringify({ok:false,failures},null,2));process.exit(1);}
console.log(JSON.stringify({ok:true,checks:'scientific-gap-regression',catalog:ANALYSIS_CATALOG.length,contracts:ANALYSIS_CONTRACTS.length,globalFdr:ar.globalFdr.length,changePoints:ar.changePoints.length},null,2));
