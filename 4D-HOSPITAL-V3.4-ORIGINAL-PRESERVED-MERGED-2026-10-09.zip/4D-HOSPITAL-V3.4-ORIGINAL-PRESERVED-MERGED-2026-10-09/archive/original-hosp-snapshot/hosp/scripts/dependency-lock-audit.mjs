import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const all={...(pkg.dependencies||{}),...(pkg.devDependencies||{})};
const bad=Object.entries(all).filter(([,v])=>typeof v==='string' && /^(latest|\*|[~^]|>=|>|<=|<)/.test(v));
if(bad.length){ console.error('Unpinned dependencies:',bad.map(([k,v])=>`${k}=${v}`).join(', ')); process.exit(1); }
if(!fs.existsSync('package-lock.json')){
  if(process.env.REQUIRE_LOCK !== '0'){
    console.error('Dependency lock gate FAIL: package-lock.json is required for a reproducible release build.');
    process.exit(2);
  }
  console.error('Dependency lock gate BLOCKED: package-lock.json is absent. Generate and commit a genuine lockfile before release.');
  process.exit(2);
}
const lock=JSON.parse(fs.readFileSync('package-lock.json','utf8'));
if(lock.lockfileVersion!==3){ console.error('package-lock.json must use lockfileVersion 3'); process.exit(3); }
const lockPkgs=lock.packages||{};
const mismatches=Object.entries(all).filter(([k,v])=>lockPkgs[`node_modules/${k}`]?.version!==v);
if(mismatches.length){ console.error('package-lock direct dependency mismatch:',mismatches.map(([k,v])=>`${k}=${v}`).join(', ')); process.exit(4); }
console.log('Dependency lock gate PASS');
