import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const lock=fs.existsSync(path.join(root,'package-lock.json'));
const requireLock = process.env.REQUIRE_LOCK !== '0';
const app=fs.readFileSync(path.join(root,'App.tsx'),'utf8');
const worker=fs.readFileSync(path.join(root,'lib','analysis-worker.ts'),'utf8');
const checks=[
 ['exact dependency versions', Object.values(pkg.dependencies??{}).every(v=>/^[0-9]+\.[0-9]+\.[0-9]+/.test(v)) && Object.values(pkg.devDependencies??{}).every(v=>/^[0-9]+\.[0-9]+\.[0-9]+/.test(v))],
 ['lockfile present', lock || !requireLock],
 ['analysis worker', app.includes("new Worker(new URL('./lib/analysis-worker.ts'") && worker.includes('runHistoricalAnalysisCore')],
 ['analysis timeout', /timeoutMs/.test(app) && /worker\.terminate\(\)/.test(app)],
 ['crash boundary', /class AppErrorBoundary extends Component/.test(app)],
 ['online-only OCR boundary', app.includes('https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js') && app.includes('navigator.onLine')],
];
for(const [name,ok] of checks) console.log(`${ok?'PASS':'BLOCKED'} ${name}`);
process.exitCode=checks.some(([_,ok])=>!ok)?2:0;
if(!lock) console.log('BLOCKER package-lock.json is not committed; generate it on a networked runner and commit the genuine lockfile before release.');
