# 4D HOSPITAL — Start Here

## First release step

এই source bundle-এ `package-lock.json` ইচ্ছাকৃতভাবে নেই, কারণ বর্তমান sandbox-এ npm registry/cache থেকে genuine lockfile তৈরি করা সম্ভব হয়নি। চিন্তার কিছু নেই: canonical GitHub workflow-তেই genuine lockfile bootstrap করা আছে। GitHub-এ ZIP-এর source upload/commit করার পর **4D HOSPITAL - Validate and Build Android APK** workflow সরাসরি Run করুন; workflow নিজেই lockfile তৈরি, audit, artifact handoff এবং commit করবে।

## Canonical validation/build flow

```bash
npm ci
npm run validate
npm run build
```

Android release-এর authoritative workflow:

`.github/workflows/build-and-validate.yml`

এটি `cap add/sync → Android audit → Gradle assembleDebug → APK integrity/hash → API 35 emulator smoke test` পর্যন্ত যায়।

## Research Cycle

Sidebar → 📐 বিশ্লেষণ → 🔒 Research Cycle

1. Current company ও historical data প্রস্তুত করুন।
2. Batch size ও candidate pool দিন।
3. `LOCK NEW PREDICTION` চাপুন।
4. Actual batch আসার আগে snapshot সংরক্ষিত থাকবে।
5. Actual batch একসঙ্গে paste করুন।
6. `VALIDATE & TRACE` চাপুন।
7. Exact/digit/position match ও mismatch diagnostics দেখুন।
8. যাচাইয়ের পরে `APPLY TO DATASET` চাপুন।

## Important

এই app historical mathematical/statistical analysis ও validation করে। কোনো model ভবিষ্যৎ 4D ফল নিশ্চিত করে না।

OCR **online-only**: internet থাকলে Tesseract.js CDN থেকে engine load হবে; internet না থাকলে OCR চলবে না। Offline অবস্থায় Manual/Paste Data Entry ব্যবহার করুন।
