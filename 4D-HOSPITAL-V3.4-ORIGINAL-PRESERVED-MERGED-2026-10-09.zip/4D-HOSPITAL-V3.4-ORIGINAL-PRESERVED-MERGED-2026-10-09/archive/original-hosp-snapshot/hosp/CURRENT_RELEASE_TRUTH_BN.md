# 4D HOSPITAL — CURRENT RELEASE TRUTH

তারিখ: 2026-10-05

## User path
1. ZIP-এর source GitHub repository root-এ upload/commit করুন।
2. GitHub Actions → **4D HOSPITAL - Validate and Build Android APK** → Run workflow।
3. আলাদা করে Windows-এ Node.js/npm বা package-lock বানানো এই release path-এর জন্য প্রয়োজন নেই।
4. Workflow missing `package-lock.json` হলে GitHub runner-এ genuine lockfile তৈরি করে audit করবে, artifact হিসেবে web/Android jobs-এ দেবে, এবং `push`/`workflow_dispatch` run-এ branch-এ commit করার চেষ্টা করবে।
5. তারপর একই run-এ `npm ci` → typecheck → research validation → Vite build → Capacitor → Android/Gradle → APK hash/integrity → API 35 emulator smoke test হবে।

## Honest limits
- এই sandbox-এ npm registry unavailable ছিল; তাই fake lockfile যোগ করা হয়নি।
- এই sandbox-এ actual Vite/Gradle/emulator build certified হয়নি।
- 1M performance harness full 107-analysis Android certification নয়।
- OCR online-only; internet না থাকলে OCR চলবে না।
- Scientific analysis future 4D outcome-এর guaranteed winning probability দাবি করে না।

## Acceptance
শুধু GitHub Actions-এ সব required jobs PASS হলে APK-কে release-certified ধরা হবে।
