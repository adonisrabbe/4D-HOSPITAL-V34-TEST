# Offline dependency reconstruction — 2026-10-06

## What was reconstructed

The project manifest was audited from `package.json` and all direct dependencies/devDependencies were pinned to exact versions.
An **offline bootstrap lockfile** was generated at `package-lock.offline-bootstrap.json`.

It contains:
- lockfileVersion 3
- the project root package
- every direct dependency with its exact requested version

## Important limitation

This is **NOT a canonical npm lockfile** and must NOT be treated as a release lockfile.

A genuine `package-lock.json` also needs the complete transitive dependency graph, resolved tarball URLs, integrity hashes, peer-dependency resolution, and (where applicable) optional/platform-specific dependency metadata. Those values cannot be truthfully reconstructed from this ZIP because:
- `node_modules` is absent
- no existing `package-lock.json` is present
- the local npm cache contains no usable package metadata/tarballs
- the environment cannot reach the npm registry

Inventing those values would make the lockfile unsafe and could cause a different dependency tree on Windows.

## Canonical generation step

When npm registry access is available on the Windows project:

`npm install --package-lock-only --ignore-scripts --no-audit --no-fund`

Then verify:

`npm run audit:dependencies`

Only the resulting real `package-lock.json` should be committed/released.

## Current dependency versions

The exact versions are taken from the audited `package.json`; no new versions were invented.
