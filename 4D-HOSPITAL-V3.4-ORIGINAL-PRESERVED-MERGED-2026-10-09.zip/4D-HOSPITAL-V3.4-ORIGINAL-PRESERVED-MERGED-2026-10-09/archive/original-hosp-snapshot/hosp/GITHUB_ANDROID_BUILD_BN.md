# 4D HOSPITAL — GitHub Android Build Hardening

## এই release-এ কী ঠিক করা হয়েছে

1. Canonical release workflow-এ genuine `package-lock.json` বাধ্যতামূলক; না থাকলে একই workflow প্রথম job-এ এটি তৈরি করে এবং পরের jobs-এ hand-off করে।
2. `bootstrap-lockfile.yml` emergency/manual recovery workflow হিসেবে আছে; canonical release workflow নিজেই missing lockfile bootstrap করে এবং `push`/`workflow_dispatch` run-এ commit করে।
3. Committed lockfile-ই validation ও Android job-এ artifact হিসেবে hand-off হয়; Android job `npm ci` ব্যবহার করে।
4. Android build-এর আগে Node 22, JDK 21 এবং Android SDK/API 35 explicitly setup করা হয়।
5. `platform-tools`, Android 35 platform, build-tools 35.0.0 এবং emulator explicitly installed হয়।
6. Gradle Actions setup এবং Gradle Wrapper validation যোগ করা হয়েছে।
7. `npx cap add android` এবং `npx cap sync android`-এর পর generated Android project audit হয়।
8. Debug APK build, non-empty check, ZIP integrity check এবং SHA-256 hash check হয়।
9. APK artifact পরের job-এ একই APK হিসেবে ব্যবহৃত হয়; দ্বিতীয়বার rebuild করে আলাদা binary হওয়ার ঝুঁকি নেই।
10. Android API 35 emulator-এ APK install, launch এবং process-alive smoke test হয়।
11. Smoke test ব্যর্থ হলে পুরো workflow FAIL হবে।

## গুরুত্বপূর্ণ

এই sandbox-এ Android SDK/Gradle/npm registry সম্পূর্ণভাবে available না থাকায় এখানে native APK compilation নিজে সম্পন্ন করা সম্ভব নয়। এটি source defect নয়। GitHub Actions runner-এ required SDK, Gradle এবং npm registry explicitly provision করা হয়েছে, তাই প্রকৃত build/installation verification GitHub-এই বাধ্যতামূলকভাবে সম্পন্ন হবে।

## Deterministic dependency rule

- Repository-তে `package-lock.json` থাকলে: `npm ci`
- না থাকলে: প্রথম validation job-এ registry থেকে lockfile তৈরি → audit → artifact → Android job-এ একই lockfile → `npm ci`

Production-grade reproducibility-এর জন্য generated genuine lockfile branch-এ persist করা হয়; lockfile তৈরি হওয়ার পর validation ও Android jobs একই artifact দিয়ে `npm ci` চালায়।

## Android verification chain

`npm ci` → `npm run validate` → `npm run build` → `cap add android` → `cap sync android` → Android audit → wrapper validation → `assembleDebug` → APK integrity/hash → API 35 emulator install → app launch → PID check.
