# 4D HOSPITAL — Final Repair Pass — 2026-10-05

## Completed source repairs

1. Fixed Vite entry path in `index.html`: `/main.tsx` → `./main.tsx`.
2. Fixed stale `tsconfig.audit.json` paths from `lib/...` to the canonical `lib/...` tree.
3. Replaced client `sessionStorage` admin authorization with an in-memory authenticated local-admin session.
4. Added API-layer authorization enforcement for `/admin/*`, user-management, invite creation, password/profile, and destructive company actions.
5. Added a regression audit: `scripts/local-auth-audit.mjs`.
6. Added `audit:local-auth` to the validation pipeline.
7. Fixed invite TTL behavior: `0` now means never-expire, represented as `expiresAt: null`.
8. Updated invite UI to correctly display non-expiring links.
9. OCR is now explicitly presented as unavailable in this source build instead of exposing a button that is guaranteed to fail.
10. Added `CURRENT_SOURCE_LAYOUT_BN.md` describing the canonical root source tree.
11. Regenerated `docs/00-MASTER/SOURCE_CHECKSUMS.sha256` using the current canonical files.
12. Removed any nested ZIP artifacts from the release tree.
13. Normalized CI dependency installation steps to `npm install` because this source bundle cannot generate a complete lockfile without registry access in the repair environment.
14. Updated the dependency audit so it validates exact dependency versions and, when a lockfile is present, validates direct dependency/version consistency.

## Verification completed in this environment

PASS:
- Static audit
- Runtime contract audit
- Research Cycle E2E
- Master inventory audit
- Research layers audit
- Stability hardening audit
- Mathematical research audit
- Advanced research audit
- Investigator audit
- Scientific Core v3 audit
- Storage/security audit
- Local auth/release hardening audit
- Dependency exact-version audit

## Release-environment verification still required

The repair environment has no DNS/network access to `registry.npmjs.org`, so it could not install the 66 npm dependencies. Therefore these cannot honestly be marked PASS here:

- Full TypeScript typecheck with installed dependencies
- Vite production build
- Capacitor Android Gradle build
- Android emulator E2E
- Generation/commit of a complete npm lockfile with the full transitive dependency tree

On a networked CI runner, run:

```bash
npm install --ignore-scripts --no-audit --no-fund
npm run validate
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug --no-daemon
```

## Security boundary

This is still an offline/local application. The new in-memory admin session prevents a simple `sessionStorage` edit from activating the Admin API compatibility layer. It is **not** a replacement for server-side authentication against a trusted backend. A multi-device or remotely shared deployment must add a real backend authorization boundary.

## OCR boundary

The source currently does not bundle a Tesseract/native OCR engine. The UI now clearly reports OCR as unavailable rather than implying that screenshot recognition is ready. Manual/Paste data entry remains available.
