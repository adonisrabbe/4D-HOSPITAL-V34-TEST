import { analyzeMathEvidence, type MathPropertyEvidence } from './number-theory-lab';
import type { CanonicalDraw } from './canonical-data';
import { buildAdvancedResearchReport, type AdvancedResearchReport } from './advanced-research-lab';

export type InvestigatorSeverity = 'GOOD'|'WATCH'|'ALERT'|'INSUFFICIENT_DATA';
export interface InvestigatorFinding { id:string; title:string; severity:InvestigatorSeverity; detail:string; evidence:string; }
export interface InvestigatorStratum { company:string; sampleSize:number; uniqueNumbers:number; duplicateRate:number; evenRate:number; digitEntropy:number; eligible:boolean; }
export interface PositionSummary { position:'FIRST'|'SECOND'|'THIRD'; sampleSize:number; uniqueNumbers:number; duplicateRate:number; evenRate:number; digitEntropy:number; }
export interface InvestigatorReport {
  sampleSize:number;
  uniqueNumbers:number;
  duplicateRate:number;
  recentWindow:number;
  recentUniqueRate:number;
  digitEntropy:number;
  recentDigitEntropy:number;
  findings:InvestigatorFinding[];
  mathEvidence:MathPropertyEvidence[];
  stableMath:MathPropertyEvidence[];
  driftMath:MathPropertyEvidence[];
  rareMath:MathPropertyEvidence[];
  redundancyWarnings:string[];
  nullModel:{uniformExactRate:number; observedUniqueRate:number; concentration:number};
  advancedResearch: AdvancedResearchReport;
  strata: InvestigatorStratum[];
  stratificationWarning: string|null;
  positionSummaries: PositionSummary[];
}

function entropy(values:string[]):number{
  if(!values.length) return 0;
  const c=new Map<string,number>(); for(const v of values)c.set(v,(c.get(v)||0)+1);
  let h=0; for(const n of c.values()){const p=n/values.length;h-=p*Math.log2(p);} return h;
}
function clamp(v:number,a=0,b=1){return Math.max(a,Math.min(b,v));}

export function buildInvestigatorReport(draws:CanonicalDraw[]):InvestigatorReport{
  const valid=draws.filter(d=>/^\d{4}$/.test(String(d.first))).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
  const nums=valid.map(d=>d.first);
  const recentWindow=Math.max(10,Math.min(nums.length,Math.floor(nums.length*.2)||10));
  const recent=nums.slice(0,recentWindow);
  const unique=new Set(nums).size;
  const duplicateRate=nums.length?1-unique/nums.length:0;
  const recentUniqueRate=recent.length?new Set(recent).size/recent.length:0;
  const digits=nums.flatMap(x=>x.split(''));
  const recentDigits=recent.flatMap(x=>x.split(''));
  const h=entropy(digits), rh=entropy(recentDigits);
  const mathEvidence=analyzeMathEvidence(nums,recentWindow);
  const stableMath=mathEvidence.filter(x=>x.status==='STABLE').sort((a,b)=>b.stability-a.stability);
  const driftMath=mathEvidence.filter(x=>x.status==='DRIFT').sort((a,b)=>Math.abs(b.drift)-Math.abs(a.drift));
  const rareMath=mathEvidence.filter(x=>x.status==='RARE');
  const findings:InvestigatorFinding[]=[];
  if(!nums.length) findings.push({id:'no-data',title:'ডেটা নেই',severity:'INSUFFICIENT_DATA',detail:'গবেষণা চালানোর মতো বৈধ ৪-ডিজিট রেকর্ড নেই।',evidence:'valid records = 0'});
  else if(nums.length<100) findings.push({id:'sample',title:'নমুনা ছোট',severity:'INSUFFICIENT_DATA',detail:'বর্ণনামূলক বিশ্লেষণ করা যাবে, কিন্তু স্থিতিশীল OOS সিদ্ধান্তের জন্য আরও historical data প্রয়োজন।',evidence:`valid records = ${nums.length}`});
  else findings.push({id:'sample',title:'নমুনা আকার ব্যবহারযোগ্য',severity:'GOOD',detail:'বর্তমান dataset-এ পর্যাপ্ত historical observations আছে; তবুও প্রতিটি নির্দিষ্ট analysis-এর নিজস্ব sample requirement মানতে হবে।',evidence:`valid records = ${nums.length}`});
  if(duplicateRate>.2) findings.push({id:'duplicates',title:'Duplicate concentration বেশি',severity:'ALERT',detail:'একই ৪-ডিজিট value বারবার এসেছে। frequency-based analysis-এ এর প্রভাব আলাদাভাবে বিবেচনা করা দরকার।',evidence:`duplicate rate ≈ ${(duplicateRate*100).toFixed(1)}%`});
  else findings.push({id:'duplicates',title:'Duplicate concentration পর্যবেক্ষণে',severity:duplicateRate>.05?'WATCH':'GOOD',detail:'Duplicate rate historical frequency analysis-এর একটি গুরুত্বপূর্ণ context হিসেবে রাখা হয়েছে।',evidence:`duplicate rate ≈ ${(duplicateRate*100).toFixed(1)}%`});
  const driftRatio=recent.length&&nums.length>recent.length?Math.abs(h-rh)/Math.max(h,.0001):0;
  if(driftMath.length) findings.push({id:'math-drift',title:'Mathematical property drift পাওয়া গেছে',severity:'WATCH',detail:`${driftMath.length}টি mathematical property recent বনাম baseline-এ উল্লেখযোগ্য পরিবর্তন দেখিয়েছে।`,evidence:driftMath.slice(0,5).map(x=>`${x.name}: drift ${x.drift.toFixed(3)}`).join(' · ')});
  else findings.push({id:'math-drift',title:'Mathematical drift বড় নয়',severity:'GOOD',detail:'বর্তমান mathematical evidence layer-এ বড় recent-vs-baseline drift শনাক্ত হয়নি।',evidence:'no property crossed the configured drift threshold'});
  if(driftRatio>.15) findings.push({id:'digit-drift',title:'Digit distribution পরিবর্তনের ইঙ্গিত',severity:'WATCH',detail:'Recent digit entropy পুরো dataset-এর তুলনায় noticeably বদলেছে।',evidence:`entropy ${h.toFixed(3)} → recent ${rh.toFixed(3)}`});
  else findings.push({id:'digit-drift',title:'Digit entropy মোটামুটি স্থিতিশীল',severity:'GOOD',detail:'Recent digit distribution-এর entropy baseline-এর কাছাকাছি।',evidence:`entropy ${h.toFixed(3)} → recent ${rh.toFixed(3)}`});
  const concentration=nums.length?Math.max(...Array.from(new Map(nums.map(x=>[x,(nums.filter(y=>y===x).length)] )).values()))/nums.length:0;
  const nullModel={uniformExactRate:1/10000,observedUniqueRate:recentUniqueRate,concentration};
  const advancedResearch=buildAdvancedResearchReport(nums);
  if(concentration>.1) findings.push({id:'concentration',title:'একটি value অতিরিক্ত concentrated',severity:'WATCH',detail:'Observed concentration random-uniform exact-number baseline-এর সঙ্গে সরাসরি তুলনাযোগ্য নয়; এটি শুধু diagnostic warning।',evidence:`max exact-number share ≈ ${(concentration*100).toFixed(2)}%`});
  const positionSummaries:PositionSummary[]=(['FIRST','SECOND','THIRD'] as const).map(position=>{
    const rows=valid.map(d=>d[position.toLowerCase() as 'first'|'second'|'third']); const uniq=new Set(rows).size;
    return{position,sampleSize:rows.length,uniqueNumbers:uniq,duplicateRate:rows.length?1-uniq/rows.length:0,evenRate:rows.length?rows.filter(x=>Number(x)%2===0).length/rows.length:0,digitEntropy:entropy(rows.flatMap(x=>x.split('')))};
  });
  const strata:InvestigatorStratum[]=[...new Set(valid.map(d=>d.company))].sort().map(company=>{
    const rows=valid.filter(d=>d.company===company).map(d=>d.first); const uniq=new Set(rows).size;
    return{company,sampleSize:rows.length,uniqueNumbers:uniq,duplicateRate:rows.length?1-uniq/rows.length:0,evenRate:rows.length?rows.filter(x=>Number(x)%2===0).length/rows.length:0,digitEntropy:entropy(rows.flatMap(x=>x.split(''))),eligible:rows.length>=30};
  });
  const smallStrata=strata.filter(x=>!x.eligible);
  const stratificationWarning=strata.length>1 && smallStrata.length ? `${smallStrata.length}টি company/source-এ sample <30; pooled result-এর আগে stratified comparison/meta-analysis প্রয়োজন।` : strata.length>1 ? 'Company/source stratification available; pooled evidence should be compared against within-stratum effects.' : null;
  const redundancyWarnings:string[]=[];
  if(nums.length){redundancyWarnings.push('Digit Sum, Digital Root এবং mod-9 সম্পর্কিত evidence-কে independent vote হিসেবে গণনা করা যাবে না।'); redundancyWarnings.push('Prime/Composite এবং prime-family properties-এর মধ্যে mathematical dependency আছে; evidence aggregation-এ redundancy correction প্রয়োজন।');}
  return {sampleSize:nums.length,uniqueNumbers:unique,duplicateRate,recentWindow,recentUniqueRate,digitEntropy:h,recentDigitEntropy:rh,findings,mathEvidence,stableMath,driftMath,rareMath,redundancyWarnings,nullModel,advancedResearch,strata,stratificationWarning,positionSummaries};
}

export function answerInvestigatorQuestion(question:string, report:InvestigatorReport):string{
  const q=question.toLowerCase();
  if(!report.sampleSize) return 'প্রথমে বৈধ ৪-ডিজিট historical data যোগ করুন।';
  if(q.includes('দুর্বল')||q.includes('weak')||q.includes('সমস্যা')||q.includes('problem')){
    const alerts=report.findings.filter(f=>f.severity==='ALERT'||f.severity==='WATCH');
    return alerts.length?alerts.slice(0,4).map(f=>`• ${f.title}: ${f.detail} (${f.evidence})`).join('\n'):'বর্তমান investigator checks-এ বড় সতর্কতা পাওয়া যায়নি; তবুও OOS/device validation সম্পন্ন না হলে final claim করা যাবে না।';
  }
  if(q.includes('stable')||q.includes('স্থিতিশীল')||q.includes('ভালো')){
    return report.stableMath.slice(0,8).map(x=>`• ${x.name} — stability ${(x.stability*100).toFixed(0)}%, status ${x.status}`).join('\n') || 'এখনও যথেষ্ট stable mathematical evidence নেই।';
  }
  if(q.includes('drift')||q.includes('পরিবর্তন')){
    return report.driftMath.slice(0,8).map(x=>`• ${x.name}: recent-baseline drift ${x.drift.toFixed(3)}`).join('\n') || 'বর্তমান mathematical layer-এ বড় drift পাওয়া যায়নি।';
  }
  if(q.includes('duplicate')||q.includes('ডুপ্লিকেট')) return `মোট valid records ${report.sampleSize}; unique 4-digit values ${report.uniqueNumbers}; estimated duplicate concentration ${(report.duplicateRate*100).toFixed(1)}%।`;
  if(q.includes('formula')||q.includes('সূত্র')||q.includes('math')||q.includes('গণিত')) return `Mathematical Lab-এ ${report.mathEvidence.length}টি property পরীক্ষা করা হয়েছে। এর মধ্যে ${report.stableMath.length}টি stable, ${report.driftMath.length}টি drift এবং ${report.rareMath.length}টি rare/low-occurrence হিসেবে চিহ্নিত।`;
  return `বর্তমান dataset: ${report.sampleSize} valid records, ${report.uniqueNumbers} unique values। Recent window: ${report.recentWindow}। Investigator ${report.findings.filter(f=>f.severity==='ALERT').length}টি alert এবং ${report.findings.filter(f=>f.severity==='WATCH').length}টি watch finding পেয়েছে। এটি historical research diagnostic; কোনো ভবিষ্যৎ ফলের নিশ্চয়তা নয়।`;
}
