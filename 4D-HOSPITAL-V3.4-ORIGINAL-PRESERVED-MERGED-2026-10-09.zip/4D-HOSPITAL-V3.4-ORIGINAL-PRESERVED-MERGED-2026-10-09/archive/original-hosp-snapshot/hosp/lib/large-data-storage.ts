/**
 * 4D HOSPITAL — large-data browser persistence compatibility layer.
 *
 * This module deliberately does NOT use localStorage for the dataset.  The
 * canonical web store is IndexedDB, which supports substantially larger data
 * and transactional writes.  Native Android continues to use SQLite through
 * lib/sqlite-results.ts.
 */
export type StoredResult = {
  id?: string; date: string; company: string; first: string; second: string; third: string;
  special?: string[]; consolation?: string[]; [key: string]: unknown;
};

const DB_NAME='4d-hospital-large-data';
const DB_VERSION=1;
const STORE='results';

function openDb():Promise<IDBDatabase>{
  return new Promise((resolve,reject)=>{
    if(typeof indexedDB==='undefined') return reject(new Error('IndexedDB unavailable'));
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'id'});};
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error??new Error('Large-data IndexedDB open failed'));
  });
}

export async function saveResultsLarge(results:StoredResult[]){
  const db=await openDb();
  try{
    await new Promise<void>((resolve,reject)=>{
      let tx:IDBTransaction;
      try{tx=db.transaction(STORE,'readwrite',{durability:'strict'} as IDBTransactionOptions);}catch{tx=db.transaction(STORE,'readwrite');}
      const store=tx.objectStore(STORE); store.clear();
      results.forEach((r,i)=>store.put({...r,id:r.id??String(i+1)}));
      tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error??new Error('Large-data IndexedDB write failed')); tx.onabort=()=>reject(tx.error??new Error('Large-data IndexedDB write aborted'));
    });
    return {count:results.length,backend:'indexeddb' as const};
  }finally{db.close();}
}

export async function loadResultsLarge():Promise<StoredResult[]>{
  const db=await openDb();
  try{return await new Promise<StoredResult[]>((resolve,reject)=>{const tx=db.transaction(STORE,'readonly');const req=tx.objectStore(STORE).getAll();tx.oncomplete=()=>resolve((req.result??[]) as StoredResult[]);tx.onerror=()=>reject(tx.error??new Error('Large-data IndexedDB read failed'));tx.onabort=()=>reject(tx.error??new Error('Large-data IndexedDB read aborted'));});}
  finally{db.close();}
}

export async function exportLargeBackup(results:StoredResult[]){
  return JSON.stringify({app:'4D HOSPITAL',version:2,storage:'indexeddb',exportedAt:new Date().toISOString(),count:results.length,results},null,2);
}
