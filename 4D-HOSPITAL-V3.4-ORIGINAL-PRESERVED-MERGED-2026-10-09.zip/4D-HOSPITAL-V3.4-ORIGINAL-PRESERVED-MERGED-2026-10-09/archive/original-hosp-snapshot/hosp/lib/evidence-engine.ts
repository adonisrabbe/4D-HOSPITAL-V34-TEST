import { ANALYSIS_REGISTRY, type AnalysisRegistryEntry } from './analysis-registry';
export interface EvidenceInput { id:number|string; pValue?:number|null; effectSize?:number|null; stability?:number|null; oos?:number|null; sampleSize?:number; observed?:number|null; nullExpected?:number|null; status?:string; }
export interface EvidenceRecord { analysisId:string; registryId:number|null; level:string; observation:string; hypothesis:string; nullModel:string; test:string; pValue:number|null; rawEffect:number|null; adjustedPValue:number|null; effectSize:number|null; stability:number|null; oos:number|null; evidenceGrade:'A'|'B'|'C'|'D'|'N/A'; eligible:boolean; reasons:string[]; version:string; }
export interface EvidenceReport { version:'evidence-engine-v2'; records:EvidenceRecord[]; fdrFamilyCount:number; qValueCutoff:number; eligibleCount:number; gradeCounts:Record<string,number>; }
function clamp(x:number){return Math.max(0,Math.min(1,x));}
function bh(items:{index:number;p:number}[],q=.05){const s=items.slice().sort((a,b)=>a.p-b.p);const out=new Map<number,number>();let prev=q;for(let i=s.length-1;i>=0;i--){const rank=i+1;const v=Math.min(prev,s[i].p*s.length/rank);out.set(s[i].index,v);prev=v;}return out;}
function grade(e:Omit<EvidenceRecord,'evidenceGrade'>):EvidenceRecord['evidenceGrade']{if(!e.eligible)return'N/A';const p=e.adjustedPValue??1,s=e.stability??0,o=e.oos??0,eff=e.effectSize==null?0:Math.abs(e.effectSize);if(p<=.01&&s>=.8&&o>=.8&&eff>=.2)return'A';if(p<=.05&&s>=.6&&o>=.6)return'B';if(p<=.10||s>=.5||o>=.5)return'C';return'D';}
function entry(id:number|string):AnalysisRegistryEntry|undefined{return ANALYSIS_REGISTRY.find(x=>x.id===Number(id));}
export function buildEvidenceReport(inputs:EvidenceInput[],q=.05):EvidenceReport{
 const raw=inputs.map((x,i)=>{const r=entry(x.id);const p=Number.isFinite(x.pValue as number)?Number(x.pValue):null;const effect=x.effectSize==null&&x.observed!=null&&x.nullExpected!=null?Number(x.observed)-Number(x.nullExpected):x.effectSize==null?null:Number(x.effectSize);const reasons:string[]=[];if(!r)reasons.push('Analysis is not in the canonical registry.');if(x.sampleSize!=null&&x.sampleSize<30)reasons.push('Sample size below the default inferential safety threshold.');if(p==null&&r?.level==='INFERENTIAL')reasons.push('No valid p-value supplied; inferential evidence cannot be graded.');if(x.oos!=null&&x.oos<.5)reasons.push('Weak chronological OOS performance.');return{analysisId:String(x.id),registryId:r?.id??null,level:r?.level??'UNREGISTERED',observation:`Observed result from analysis ${x.id}.`,hypothesis:r?.definition??'Declared analysis hypothesis unavailable.',nullModel:r?.nullHypothesis??'H0 unavailable.',test:r?.validation??'Validation method unavailable.',pValue:p,rawEffect:effect,adjustedPValue:null,effectSize:effect,stability:x.stability==null?null:clamp(Number(x.stability)),oos:x.oos==null?null:clamp(Number(x.oos)),evidenceGrade:'N/A',eligible:!!r&&!reasons.some(z=>/inferential evidence|canonical registry/.test(z)),reasons,version:'evidence-v2'} as EvidenceRecord;});
 const ps=raw.map((x,i)=>({index:i,p:x.pValue})).filter((x):x is {index:number;p:number}=>Number.isFinite(x.p));const qv=bh(ps,q);for(let i=0;i<raw.length;i++)raw[i].adjustedPValue=qv.get(i)??null,raw[i].evidenceGrade=grade(raw[i]);
 const gradeCounts:Record<string,number>={};for(const r of raw)gradeCounts[r.evidenceGrade]=(gradeCounts[r.evidenceGrade]??0)+1;
 return{version:'evidence-engine-v2',records:raw,fdrFamilyCount:ps.length,qValueCutoff:q,eligibleCount:raw.filter(x=>x.eligible).length,gradeCounts};
}

export function evidenceInputFromAnalysisResult(result:{id:number;sampleSize:number;raw:unknown;evidence:string}):EvidenceInput{
  const raw=result.raw as any;
  const p=raw&&typeof raw==='object' ? [raw.globalPValue,raw.pValue,raw.p].find(v=>typeof v==='number'&&v>=0&&v<=1) : undefined;
  const oos=raw&&typeof raw==='object' ? [raw.exact4DRate,raw.digitAccuracy,raw.coverage].find(v=>typeof v==='number'&&v>=0&&v<=1) : undefined;
  const stability=raw&&typeof raw==='object' ? [raw.stability,raw.stableRate,raw.rate].find(v=>typeof v==='number'&&v>=0&&v<=1) : undefined;
  return {id:result.id,pValue:p??null,oos:oos??null,stability:stability??null,sampleSize:result.sampleSize,status:result.evidence};
}
