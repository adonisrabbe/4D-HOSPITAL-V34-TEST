/** 4D HOSPITAL — Research Governance / Signal Freeze v1
 * Immutable, deterministic controls for discovery → freeze → blind OOS evaluation.
 */
export interface SignalFreezeManifest {
  version:'signal-freeze-v1';
  datasetFingerprint:string;
  discoveryFingerprint:string;
  discoveryEndIndex:number;
  oosStartIndex:number;
  discoveryCount:number;
  oosReservedCount:number;
  signalIds:string[];
  signalManifestHash:string;
  frozenAt:string;
}
export interface FreezeValidation { valid:boolean; reasons:string[]; discoveryUnchanged:boolean; chronological:boolean; manifestUnchanged:boolean; }

function fnv1a(text:string){let h=0x811c9dc5;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,0x01000193);}return(h>>>0).toString(16).padStart(8,'0');}
export function stableRowsFingerprint(rows:unknown[]):string{return `gov1-${fnv1a(JSON.stringify(rows))}`;}
export function signalManifestHash(signalIds:string[]):string{return `sig1-${fnv1a([...new Set(signalIds)].sort().join('|'))}`;}
export function createSignalFreeze(args:{rows:unknown[];discoveryEndIndex:number;oosStartIndex:number;signalIds:string[];frozenAt?:string}):SignalFreezeManifest{
  const n=args.rows.length,end=Math.max(0,Math.min(n,args.discoveryEndIndex)),start=Math.max(end,Math.min(n,args.oosStartIndex));
  return{version:'signal-freeze-v1',datasetFingerprint:stableRowsFingerprint(args.rows),discoveryFingerprint:stableRowsFingerprint(args.rows.slice(0,end)),discoveryEndIndex:end,oosStartIndex:start,discoveryCount:end,oosReservedCount:n-start,signalIds:[...new Set(args.signalIds)].sort(),signalManifestHash:signalManifestHash(args.signalIds),frozenAt:args.frozenAt??new Date(0).toISOString()};
}
export function validateSignalFreeze(manifest:SignalFreezeManifest,currentRows:unknown[],currentSignalIds:string[]):FreezeValidation{
  const reasons:string[]=[];const discovery=currentRows.slice(0,manifest.discoveryEndIndex);const discoveryUnchanged=stableRowsFingerprint(discovery)===manifest.discoveryFingerprint;
  // Snapshot-less manifests still get a hard structural check; callers should persist the discovery snapshot beside the manifest.
  const chronological=manifest.oosStartIndex>=manifest.discoveryEndIndex&&manifest.oosStartIndex<=currentRows.length;
  const manifestUnchanged=signalManifestHash(currentSignalIds)===manifest.signalManifestHash;
  if(!discoveryUnchanged)reasons.push('Discovery dataset snapshot changed after signal freeze.');
  if(!chronological)reasons.push('OOS boundary is not chronological or is outside the dataset.');
  if(!manifestUnchanged)reasons.push('Signal manifest changed after freeze; final OOS must not be re-tuned.');
  return{valid:reasons.length===0,reasons,discoveryUnchanged,chronological,manifestUnchanged};
}
export function assertBlindOOS(trainRows:unknown[],testRows:unknown[]):void{
  if(!trainRows.length||!testRows.length)throw new Error('Blind OOS requires non-empty training and test partitions.');
  const trainFp=stableRowsFingerprint(trainRows),testFp=stableRowsFingerprint(testRows);if(trainFp===testFp)throw new Error('Training and OOS partitions are identical; blind evaluation is invalid.');
}
