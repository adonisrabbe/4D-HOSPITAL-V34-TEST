import type { EvidenceReport, EvidenceRecord } from './evidence-engine';
export interface EvidenceInterpretation { headline:string; findings:string[]; blockers:string[]; nextActions:string[]; confidence:'HIGH'|'MEDIUM'|'LOW'; }
export function interpretEvidence(report:EvidenceReport):EvidenceInterpretation{
 const findings:string[]=[];const blockers:string[]=[];const nextActions:string[]=[];
 const strong=report.records.filter(x=>x.evidenceGrade==='A'||x.evidenceGrade==='B');const weak=report.records.filter(x=>x.evidenceGrade==='C'||x.evidenceGrade==='D');
 if(strong.length)findings.push(`${strong.length} analysis records meet the current evidence-grade thresholds.`);else findings.push('No analysis currently meets the A/B evidence-grade thresholds.');
 if(report.fdrFamilyCount) findings.push(`FDR adjustment was applied to ${report.fdrFamilyCount} supplied p-values; raw p-values are not treated as final evidence.`); else blockers.push('No valid p-values were supplied for FDR-controlled inference.');
 for(const r of report.records.filter(x=>x.reasons.length)) blockers.push(`${r.analysisId}: ${r.reasons.join(' ')}`);
 if(weak.length)nextActions.push('Replicate weak findings across independent chronological windows and source/company strata.');
 nextActions.push('Keep descriptive findings separate from predictive/confirmatory claims.');
 nextActions.push('For predictive analyses, require locked blind OOS and an explicit baseline comparison before promotion.');
 return{headline:strong.length?`${strong.length} evidence item(s) currently pass the configured process threshold.`:'No finding is currently strong enough for promotion.',findings,blockers:[...new Set(blockers)].slice(0,12),nextActions,confidence:strong.length&&blockers.length===0?'HIGH':strong.length?'MEDIUM':'LOW'};
}
