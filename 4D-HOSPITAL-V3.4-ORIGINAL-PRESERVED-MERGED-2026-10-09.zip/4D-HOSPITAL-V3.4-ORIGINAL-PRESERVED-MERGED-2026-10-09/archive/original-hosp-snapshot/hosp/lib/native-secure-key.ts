import { registerPlugin } from '@capacitor/core';
interface NativeSecureKey { getOrCreateKey():Promise<{alias:string}>; encrypt(options:{alias:string;plaintext:string}):Promise<{ciphertext:string;iv:string}>; decrypt(options:{alias:string;ciphertext:string;iv:string}):Promise<{plaintext:string}>; }
const SecureKey=registerPlugin<NativeSecureKey>('SecureKeyVault');
export async function nativeKeyAvailable(){try{await SecureKey.getOrCreateKey();return true;}catch{return false;}}
export async function secureEncrypt(alias:string,plaintext:string){return SecureKey.encrypt({alias,plaintext});}
export async function secureDecrypt(alias:string,ciphertext:string,iv:string){return SecureKey.decrypt({alias,ciphertext,iv});}
