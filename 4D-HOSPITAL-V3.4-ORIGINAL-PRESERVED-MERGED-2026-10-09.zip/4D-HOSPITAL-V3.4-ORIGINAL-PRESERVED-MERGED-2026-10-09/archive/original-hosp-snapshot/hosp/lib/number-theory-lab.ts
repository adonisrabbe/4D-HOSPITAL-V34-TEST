/**
 * 4D HOSPITAL — Number Theory & Mathematical Laboratory
 *
 * This layer is deliberately evidence-first. Mathematical properties are
 * computed as deterministic features of the historical dataset; they are not
 * treated as guarantees or independent votes. The research UI reports
 * prevalence, recent-vs-baseline drift and chronological stability so a
 * property can be promoted to a signal only after leakage-safe validation.
 */

export type MathPropertyId =
  | 'prime' | 'composite' | 'twinPrime' | 'cousinPrime' | 'sexyPrime'
  | 'mersennePrime' | 'fermatPrime' | 'sophieGermainPrime' | 'safePrime'
  | 'wilsonPrime' | 'emirp' | 'palindromicPrime' | 'repunitPrime'
  | 'primeGap2' | 'primeGap4' | 'primeGap6'
  | 'digitalRoot' | 'digitSum' | 'palindrome' | 'repdigit'
  | 'kaprekar' | 'kaprekar6174' | 'narcissistic' | 'happy' | 'harshad'
  | 'smith' | 'automorphic' | 'factorion' | 'strobogrammatic'
  | 'perfectSquare' | 'perfectCube' | 'triangular' | 'pentagonal' | 'hexagonal'
  | 'fibonacci' | 'lucas' | 'perfect' | 'abundant' | 'deficient'
  | 'sphenic' | 'powerful' | 'squareFree' | 'semiperfect' | 'weird'
  | 'tau' | 'sigma' | 'phi' | 'mobius' | 'primorialRelated'
  | 'amicable' | 'practical' | 'untouchable' | 'collatz' | 'pythagorean' | 'goldbach'
  | 'catalan' | 'octahedral' | 'pyramidal' | 'centeredPolygonal' | 'factorial' | 'superfactorial' | 'aliquotCycle';

export interface MathPropertyDefinition { id: MathPropertyId; name: string; family: string; description: string; use: 'feature'|'reference'; }

export const MATH_PROPERTY_CATALOG: MathPropertyDefinition[] = [
  {id:'prime',name:'Prime / Composite classification',family:'Prime',description:'Classifies n as prime, composite or neither (0/1).',use:'feature'},
  {id:'twinPrime',name:'Twin-prime relation',family:'Prime',description:'n and n+2 are both prime.',use:'feature'},
  {id:'cousinPrime',name:'Cousin-prime relation',family:'Prime',description:'n and n+4 are both prime.',use:'feature'},
  {id:'sexyPrime',name:'Sexy-prime relation',family:'Prime',description:'n and n+6 are both prime.',use:'feature'},
  {id:'mersennePrime',name:'Mersenne-prime form',family:'Prime',description:'n is prime and n+1 is a power of two.',use:'feature'},
  {id:'fermatPrime',name:'Fermat-prime form',family:'Prime',description:'n is prime and n=2^(2^k)+1 for integer k>=0.',use:'feature'},
  {id:'sophieGermainPrime',name:'Sophie Germain prime',family:'Prime',description:'n and 2n+1 are both prime.',use:'feature'},
  {id:'safePrime',name:'Safe-prime form',family:'Prime',description:'n is prime and (n-1)/2 is prime.',use:'feature'},
  {id:'wilsonPrime',name:'Wilson-prime condition',family:'Prime',description:'(n-1)! ≡ -1 (mod n), evaluated exactly for the small 4-digit domain.',use:'feature'},
  {id:'emirp',name:'Emirp',family:'Prime',description:'n and its digit reversal are distinct primes.',use:'feature'},
  {id:'palindromicPrime',name:'Palindromic prime',family:'Prime',description:'n is prime and reads the same backwards.',use:'feature'},
  {id:'repunitPrime',name:'Repunit-prime form',family:'Prime',description:'n consists only of digit 1 and is prime.',use:'feature'},
  {id:'primeGap2',name:'Prime gap +2',family:'Prime',description:'n is prime and the next prime is n+2.',use:'feature'},
  {id:'primeGap4',name:'Prime gap +4',family:'Prime',description:'n is prime and the next prime is n+4.',use:'feature'},
  {id:'primeGap6',name:'Prime gap +6',family:'Prime',description:'n is prime and the next prime is n+6.',use:'feature'},
  {id:'digitalRoot',name:'Digital root',family:'Digit',description:'Repeated digit sum reduced to 1..9, with 0 retained for zero.',use:'feature'},
  {id:'digitSum',name:'Digit sum',family:'Digit',description:'Sum of the four displayed digits.',use:'feature'},
  {id:'palindrome',name:'Palindrome',family:'Digit',description:'Four-digit string reads identically in reverse.',use:'feature'},
  {id:'repdigit',name:'Repdigit',family:'Digit',description:'All four displayed digits are equal.',use:'feature'},
  {id:'kaprekar',name:'Kaprekar number',family:'Digit',description:'For n, n² split at the fixed 4-digit boundary yields parts whose sum is n.',use:'feature'},
  {id:'kaprekar6174',name:'Kaprekar 4-digit routine / 6174',family:'Digit',description:'Four-digit Kaprekar routine reaches 6174 for eligible inputs.',use:'feature'},
  {id:'narcissistic',name:'Armstrong / Narcissistic',family:'Digit',description:'Sum of each digit raised to the number of displayed digits equals n.',use:'feature'},
  {id:'happy',name:'Happy number',family:'Digit',description:'Repeated sum-of-squared-digits reaches 1.',use:'feature'},
  {id:'harshad',name:'Harshad / Niven',family:'Digit',description:'n is divisible by its digit sum.',use:'feature'},
  {id:'smith',name:'Smith number',family:'Digit',description:'Composite n whose digit sum equals the digit sum of its prime factors counted with multiplicity.',use:'feature'},
  {id:'automorphic',name:'Automorphic number',family:'Digit',description:'n² ends with the decimal digits of n.',use:'feature'},
  {id:'factorion',name:'Factorion',family:'Digit',description:'Sum of factorials of digits equals n.',use:'feature'},
  {id:'strobogrammatic',name:'Strobogrammatic',family:'Digit',description:'Looks valid after 180° rotation under the 0/1/2/5/6/8/9 mapping.',use:'feature'},
  {id:'perfectSquare',name:'Perfect square',family:'Polygonal / Power',description:'n is an integer square.',use:'feature'},
  {id:'perfectCube',name:'Perfect cube',family:'Polygonal / Power',description:'n is an integer cube.',use:'feature'},
  {id:'triangular',name:'Triangular number',family:'Polygonal / Power',description:'n=k(k+1)/2 for an integer k.',use:'feature'},
  {id:'pentagonal',name:'Pentagonal number',family:'Polygonal / Power',description:'n=k(3k-1)/2 for an integer k.',use:'feature'},
  {id:'hexagonal',name:'Hexagonal number',family:'Polygonal / Power',description:'n=k(2k-1) for an integer k.',use:'feature'},
  {id:'fibonacci',name:'Fibonacci number',family:'Sequence',description:'n belongs to the Fibonacci sequence.',use:'feature'},
  {id:'lucas',name:'Lucas number',family:'Sequence',description:'n belongs to the Lucas sequence.',use:'feature'},
  {id:'perfect',name:'Perfect number',family:'Divisor',description:'Proper-divisor sum equals n.',use:'feature'},
  {id:'abundant',name:'Abundant number',family:'Divisor',description:'Proper-divisor sum exceeds n.',use:'feature'},
  {id:'deficient',name:'Deficient number',family:'Divisor',description:'Proper-divisor sum is below n.',use:'feature'},
  {id:'sphenic',name:'Sphenic number',family:'Divisor',description:'Product of exactly three distinct primes.',use:'feature'},
  {id:'powerful',name:'Powerful number',family:'Divisor',description:'Every prime factor p has p² dividing n.',use:'feature'},
  {id:'squareFree',name:'Square-free number',family:'Divisor',description:'No prime square divides n.',use:'feature'},
  {id:'semiperfect',name:'Semiperfect number',family:'Divisor',description:'Some proper divisors sum exactly to n.',use:'feature'},
  {id:'weird',name:'Weird number',family:'Divisor',description:'Abundant but not semiperfect.',use:'feature'},
  {id:'tau',name:'Tau function τ(n)',family:'Divisor',description:'Number of positive divisors.',use:'feature'},
  {id:'sigma',name:'Sigma function σ(n)',family:'Divisor',description:'Sum of positive divisors.',use:'feature'},
  {id:'phi',name:'Euler totient φ(n)',family:'Divisor',description:'Count of positive integers <=n that are coprime to n.',use:'feature'},
  {id:'mobius',name:'Möbius μ(n)',family:'Divisor',description:'Square-free parity indicator with μ(1)=1.',use:'feature'},
  {id:'amicable',name:'Amicable-number relation',family:'Divisor',description:'Checks whether the aliquot sum of n forms a 2-cycle with another integer.',use:'feature'},
  {id:'practical',name:'Practical number',family:'Divisor',description:'Checks whether every positive integer <=n can be represented as a sum of distinct divisors of n.',use:'feature'},
  {id:'untouchable',name:'Untouchable number',family:'Divisor',description:'Checks whether n is not the sum of proper divisors of any positive integer in the supported domain.',use:'feature'},
  {id:'collatz',name:'Collatz / 3n+1 trajectory',family:'Sequence',description:'Checks whether the trajectory reaches 1 and records its stopping length.',use:'feature'},
  {id:'pythagorean',name:'Pythagorean-triple membership',family:'Diophantine',description:'Checks whether n can occur as a side of an integer Pythagorean triple.',use:'feature'},
  {id:'goldbach',name:'Goldbach decomposition count',family:'Prime',description:'For even n>2, counts prime pairs p+q=n.',use:'feature'},
  {id:'catalan',name:'Catalan number',family:'Sequence',description:'Checks membership in the Catalan sequence.',use:'feature'},
  {id:'octahedral',name:'Octahedral number',family:'Polygonal / Power',description:'Checks membership in the octahedral sequence.',use:'feature'},
  {id:'pyramidal',name:'Square-pyramidal number',family:'Polygonal / Power',description:'Checks membership in 1²+2²+...+k².',use:'feature'},
  {id:'centeredPolygonal',name:'Centered polygonal structure',family:'Polygonal / Power',description:'Checks common centered triangular/square/hexagonal forms.',use:'feature'},
  {id:'factorial',name:'Factorial number',family:'Sequence',description:'Checks whether n=k! for integer k.',use:'feature'},
  {id:'superfactorial',name:'Superfactorial number',family:'Sequence',description:'Checks whether n is the product 1!·2!·...·k! within the 4-digit domain.',use:'feature'},
  {id:'aliquotCycle',name:'Aliquot-cycle relation',family:'Divisor',description:'Checks whether repeated proper-divisor sums enter a short cycle.',use:'feature'},
  {id:'primorialRelated',name:'Primorial relation',family:'Prime',description:'Checks whether n is itself a primorial or differs from one by ±1.',use:'feature'},
];

const primeCache = new Map<number, boolean>();
const factorCache = new Map<number, number[]>();
const divisorCache = new Map<number, number[]>();
const featureCache = new Map<number, NumberTheoryFeatures>();
const fibonacciSet = new Set<number>();
const lucasSet = new Set<number>();

function initSequenceSets() {
  if (fibonacciSet.size) return;
  let a=0,b=1; while(a<=9999){fibonacciSet.add(a); [a,b]=[b,a+b];}
  let x=2,y=1; while(x<=9999){lucasSet.add(x); [x,y]=[y,x+y];}
}

export function isPrime(n:number): boolean {
  if (primeCache.has(n)) return primeCache.get(n)!;
  if (n<2 || n%1!==0){primeCache.set(n,false);return false;}
  if(n===2){primeCache.set(n,true);return true;}
  if(n%2===0){primeCache.set(n,false);return false;}
  for(let d=3;d*d<=n;d+=2) if(n%d===0){primeCache.set(n,false);return false;}
  primeCache.set(n,true);return true;
}

export function primeFactors(n:number): number[] {
  if(factorCache.has(n)) return factorCache.get(n)!;
  const out:number[]=[]; let x=Math.abs(Math.trunc(n));
  for(let p=2;p*p<=x;p+=(p===2?1:2)) while(x%p===0){out.push(p);x=Math.trunc(x/p);}
  if(x>1)out.push(x);
  factorCache.set(n,out);return out;
}

export function divisors(n:number): number[] {
  if(divisorCache.has(n)) return divisorCache.get(n)!;
  const out:number[]=[]; if(n<1){divisorCache.set(n,out);return out;}
  for(let d=1;d*d<=n;d++) if(n%d===0){out.push(d);if(d*d!==n)out.push(n/d);}
  out.sort((a,b)=>a-b);divisorCache.set(n,out);return out;
}

export function digitSum(n:number|string):number { return String(n).padStart(4,'0').split('').reduce((s,d)=>s+Number(d),0); }
export function digitalRoot(n:number|string):number { let x=Math.abs(Number(n)); if(x===0)return 0; return 1+((Math.trunc(x)-1)%9); }
export function reverse4(n:number|string):number { return Number(String(n).padStart(4,'0').split('').reverse().join('')); }
function isPowerOfTwo(n:number){return n>0&&(n&(n-1))===0;}
function digitFactorialSum(n:number){const f=[1,1,2,6,24,120,720,5040,40320,362880];return String(Math.abs(Math.trunc(n))).split('').reduce((s,d)=>s+f[Number(d)],0);}
function sumSquaredDigits(n:number){return String(n).padStart(4,'0').split('').reduce((s,d)=>s+Number(d)**2,0);}
function isHappy(n:number){let x=n;const seen=new Set<number>();while(x!==1&&!seen.has(x)){seen.add(x);x=sumSquaredDigits(x);}return x===1;}
function properDivisorSum(n:number){return divisors(n).filter(d=>d!==n).reduce((a,b)=>a+b,0);}
function isTriangular(n:number){const x=8*n+1;const r=Math.floor(Math.sqrt(x));return r*r===x;}
function isPentagonal(n:number){const x=24*n+1;const r=Math.floor(Math.sqrt(x));return r*r===x&&(1+r)%6===0;}
function isHexagonal(n:number){const x=8*n+1;const r=Math.floor(Math.sqrt(x));return r*r===x&&(1+r)%4===0;}
function isPowerful(n:number){if(n<1)return false;const f=primeFactors(n);return [...new Set(f)].every(p=>{let x=n,c=0;while(x%p===0){x/=p;c++;}return c>=2;});}
function isSquareFree(n:number){return n>0&&primeFactors(n).every((p,i,a)=>i===a.lastIndexOf(p));}
function isSphenic(n:number){const f=primeFactors(n);return f.length===3&&new Set(f).size===3;}
function isSemiperfect(n:number){if(n<2)return false;const ds=divisors(n).filter(d=>d<n);let bits=1n;const target=BigInt(n);for(const d of ds){const shift=BigInt(d);bits |= (bits << shift);const mask=(1n << (target+1n))-1n;bits &= mask;if(((bits >> target)&1n)===1n)return true;}return false;}
function isSmith(n:number){if(n<4||isPrime(n))return false;const a=digitSum(n);return primeFactors(n).reduce((s,p)=>s+digitSum(p),0)===a;}
function isKaprekarNumber(n:number){if(n<1)return false;const sq=String(n*n);const width=String(n).length;const cut=Math.max(1,sq.length-width);const left=Number(sq.slice(0,cut)||'0');const right=Number(sq.slice(cut)||'0');return left+right===n;}
function kaprekarRoutine(n:number,maxSteps=20){let cur=String(n).padStart(4,'0');const seen=new Set<string>();const path:string[]=[];for(let i=0;i<maxSteps;i++){if(seen.has(cur))return {path,terminal:cur,reaches6174:false,cycle:true};seen.add(cur);path.push(cur);if(cur==='6174')return{path,terminal:cur,reaches6174:true,cycle:false};if(/^([0-9])\1{3}$/.test(cur))return{path,terminal:cur,reaches6174:false,cycle:true};const hi=cur.split('').sort((a,b)=>Number(b)-Number(a)).join('');const lo=cur.split('').sort((a,b)=>Number(a)-Number(b)).join('');cur=String(Number(hi)-Number(lo)).padStart(4,'0');}return{path,terminal:cur,reaches6174:cur==='6174',cycle:false};}
function isWilsonPrime(n:number){if(!isPrime(n))return false;let fact=1;for(let i=2;i<n;i++)fact=(fact*i)%n;return fact===n-1;}
function isFermatPrimeForm(n:number){if(!isPrime(n))return false;let x=n-1; if(x<2||!isPowerOfTwo(x))return false;const k=Math.log2(x);return Number.isInteger(k)&&isPowerOfTwo(k);}
function isCatalan(n:number){let c=1;for(let k=0;k<20;k++){if(c===n)return true;c=Math.trunc(c*(4*k+2)/(k+2));if(c>99999)break;}return false;}
function isOctahedral(n:number){for(let k=1;k<30;k++){const v=k*(2*k*k+1)/3;if(v===n)return true;if(v>n)break;}return false;}
function isPyramidal(n:number){let s=0;for(let k=1;k<50;k++){s+=k*k;if(s===n)return true;if(s>n)break;}return false;}
function isCenteredPolygonal(n:number){for(let k=1;k<100;k++){const tri=3*k*(k-1)/2+1;const sq=k*k+(k-1)*(k-1);const hex=3*k*(k-1)+1;if(tri===n||sq===n||hex===n)return true;if(tri>n&&sq>n&&hex>n)break;}return false;}
function isFactorial(n:number){let f=1;for(let k=1;k<=10;k++){f*=k;if(f===n)return true;if(f>n)break;}return false;}
function isSuperfactorial(n:number){let f=1,s=1;for(let k=1;k<=7;k++){f*=k;s*=f;if(s===n)return true;if(s>n)break;}return false;}
function aliquotSum(n:number){return properDivisorSum(n);}
function hasAliquotCycle(n:number){let x=n;const seen=new Map<number,number>();for(let i=0;i<20;i++){if(seen.has(x))return seen.get(x)!<i;seen.set(x,i);x=aliquotSum(x);if(x===0)return false;}return false;}
function isAmicable(n:number){if(n<2)return false;const m=aliquotSum(n);return m!==n&&m>0&&aliquotSum(m)===n;}
function isPractical(n:number){if(n===1)return true;if(n<2)return false;const f=primeFactors(n);if(f[0]!==2)return false;let priorSigma=1;for(const p of [...new Set(f)]){if(p!==2&&p>priorSigma+1)return false;let pe=1;let x=n,c=0;while(x%p===0){x/=p;c++;}for(let i=0;i<c;i++)pe*=p;priorSigma*=((pe*p-1)/(p-1));}return true;}
const untouchableSet=new Set<number>();
function initUntouchableSet(){if(untouchableSet.size)return;for(let m=1;m<=9999;m++)untouchableSet.add(aliquotSum(m));}
function collatzInfo(n:number){let x=n,steps=0;const seen=new Set<number>();while(x!==1&&steps<10000&&!seen.has(x)){seen.add(x);x=x%2===0?x/2:3*x+1;steps++;}return {reaches1:x===1,steps};}
function isPythagoreanSide(n:number){
  // Every integer n >= 3 occurs as a side of an integer Pythagorean triple:
  // odd n: (n, (n²-1)/2, (n²+1)/2); even n: (n, (n/2)²-1, (n/2)²+1).
  // Therefore the property is exactly n >= 3; this explicit proof avoids a misleading brute-force test.
  return Number.isInteger(n)&&n>=3;
}
function goldbachCount(n:number){if(n<=2||n%2!==0)return 0;let c=0;for(let p=2;p<=n/2;p++)if(isPrime(p)&&isPrime(n-p))c++;return c;}
function isPrimorialRelated(n:number){let p=1;for(let k=2;k<=97;k++){if(isPrime(k))p*=k;if(p>99999)break;if(n===p||n===p-1||n===p+1)return true;}return false;}

export interface NumberTheoryFeatures {
  n:number; text:string; properties: Partial<Record<MathPropertyId, number|boolean>>;
  factors:number[]; tau:number; sigma:number; phi:number; mobius:number; properDivisorSum:number;
  kaprekarSteps:number; kaprekarTerminal:string; reaches6174:boolean;
}

export function classify4D(input:string|number): NumberTheoryFeatures {
  initUntouchableSet();
  const text=String(input).padStart(4,'0').slice(-4); const n=Number(text);
  const cached=featureCache.get(n); if(cached && cached.text===text) return cached;
  initSequenceSets();
  const f=primeFactors(n), ds=divisors(n), tau=ds.length, sigma=ds.reduce((a,b)=>a+b,0), proper=sigma-n;
  const distinct=new Set(f); let mob=0;
  if(n===0) mob=0; else if(n===1) mob=1; else if(f.some((p,i,a)=>i!==a.lastIndexOf(p))) mob=0; else mob=(f.length%2===0?1:-1);
  const rev=reverse4(text); const kap=kaprekarRoutine(n);
  let phiValue=n; for(const p of new Set(f)) phiValue=Math.trunc(phiValue/p*(p-1));
  const props:Partial<Record<MathPropertyId,number|boolean>>={
    prime:isPrime(n), composite:n>1&&!isPrime(n), twinPrime:isPrime(n)&&isPrime(n+2), cousinPrime:isPrime(n)&&isPrime(n+4), sexyPrime:isPrime(n)&&isPrime(n+6),
    mersennePrime:isPrime(n)&&isPowerOfTwo(n+1), fermatPrime:isFermatPrimeForm(n), sophieGermainPrime:isPrime(n)&&isPrime(2*n+1), safePrime:isPrime(n)&&isPrime((n-1)/2),
    wilsonPrime:isWilsonPrime(n), emirp:isPrime(n)&&rev!==n&&isPrime(rev), palindromicPrime:isPrime(n)&&text===text.split('').reverse().join(''), repunitPrime:isPrime(n)&&/^1{4}$/.test(text),
    primeGap2:isPrime(n)&&isPrime(n+2), primeGap4:isPrime(n)&&isPrime(n+4), primeGap6:isPrime(n)&&isPrime(n+6),
    digitalRoot:digitalRoot(n), digitSum:digitSum(text), palindrome:text===text.split('').reverse().join(''), repdigit:/^(\d)\1{3}$/.test(text),
    kaprekar:isKaprekarNumber(n), kaprekar6174:kap.reaches6174, narcissistic:Number(text.split('').reduce((s,d)=>s+Number(d)**4,0))===n, happy:isHappy(n),
    harshad:n>0&&n%digitSum(text)===0, smith:isSmith(n), automorphic:String(n*n).endsWith(String(n)), factorion:digitFactorialSum(n)===n,
    strobogrammatic:text.split('').reverse().map(d=>({0:'0',1:'1',2:'2',5:'5',6:'9',8:'8',9:'6'} as Record<string,string>)[d]||'?').join('')===text,
    perfectSquare:Math.floor(Math.sqrt(n))**2===n, perfectCube:Math.round(Math.cbrt(n))**3===n, triangular:isTriangular(n), pentagonal:isPentagonal(n), hexagonal:isHexagonal(n),
    fibonacci:fibonacciSet.has(n), lucas:lucasSet.has(n), perfect:n>1&&proper===n, abundant:n>1&&proper>n, deficient:n>0&&proper<n,
    sphenic:isSphenic(n), powerful:isPowerful(n), squareFree:isSquareFree(n), semiperfect:isSemiperfect(n), weird:n>1&&proper>n&&!isSemiperfect(n),
    tau, sigma, phi:phiValue, mobius:mob,
    amicable:isAmicable(n), practical:isPractical(n), untouchable:n>0&&!untouchableSet.has(n),
    collatz:collatzInfo(n).reaches1, pythagorean:isPythagoreanSide(n), goldbach:goldbachCount(n)>0,
    catalan:isCatalan(n), octahedral:isOctahedral(n), pyramidal:isPyramidal(n), centeredPolygonal:isCenteredPolygonal(n),
    factorial:isFactorial(n), superfactorial:isSuperfactorial(n), aliquotCycle:hasAliquotCycle(n), primorialRelated:isPrimorialRelated(n)
  };
  const result={n,text,properties:props,factors:f,tau,sigma,phi:phiValue,mobius:mob,properDivisorSum:proper,kaprekarSteps:kap.path.length,kaprekarTerminal:kap.terminal,reaches6174:kap.reaches6174};
  featureCache.set(n,result); return result;
}

function gcd(a:number,b:number):number{while(b){const t=a%b;a=b;b=t;}return Math.abs(a);}

const NUMERIC_MATH_PROPERTIES = new Set<MathPropertyId>(['digitalRoot','digitSum','tau','sigma','phi','mobius']);

export interface MathPropertyEvidence {
  id:MathPropertyId; name:string; family:string; description:string;
  metric:'BOOLEAN_RATE'|'NUMERIC_MEAN';
  allRate:number; recentRate:number; baselineRate:number;
  allMean:number|null; recentMean:number|null; baselineMean:number|null;
  drift:number; foldRates:number[]; stability:number;
  occurrences:number; recentOccurrences:number; status:'STABLE'|'DRIFT'|'RARE'|'NOT_INFORMATIVE';
}

function rate(rows:string[], id:MathPropertyId){
  if(!rows.length)return 0;
  let c=0;
  for(const n of rows){const v=classify4D(n).properties[id];if(v===true)c++;}
  return c/rows.length;
}

function numericMean(rows:string[], id:MathPropertyId):number|null{
  if(!rows.length)return null;
  let sum=0,count=0;
  for(const n of rows){const v=classify4D(n).properties[id];if(typeof v==='number'&&Number.isFinite(v)){sum+=v;count++;}}
  return count?sum/count:null;
}

export function analyzeMathEvidence(numbers:string[], recentWindow?:number): MathPropertyEvidence[] {
  const clean=numbers.map(x=>String(x).padStart(4,'0')).filter(x=>/^\d{4}$/.test(x));
  const recentN=Math.max(10,Math.min(clean.length,recentWindow??Math.max(10,Math.floor(clean.length*0.2))));
  // The UI supplies observations newest-first; preserve that convention so the recent window is genuinely recent.
  const recent=clean.slice(0,recentN); const base=clean.slice(recentN);
  const foldCount=3; const foldRates:number[][]=MATH_PROPERTY_CATALOG.map(()=>[]);
  const chunks:number[][]=[]; for(let i=0;i<foldCount;i++){const start=Math.floor(clean.length*i/foldCount),end=Math.floor(clean.length*(i+1)/foldCount);if(end-start>=3)chunks.push([start,end]);}
  return MATH_PROPERTY_CATALOG.map((def,idx)=>{
    const numeric=NUMERIC_MATH_PROPERTIES.has(def.id);
    const all=numeric?0:rate(clean,def.id), rr=numeric?0:rate(recent,def.id), br=numeric?(base.length?0:0):(base.length?rate(base,def.id):all);
    const allMean=numeric?numericMean(clean,def.id):null;
    const recentMean=numeric?numericMean(recent,def.id):null;
    const baselineMean=numeric?(base.length?numericMean(base,def.id):allMean):null;
    const drift=numeric?((recentMean??0)-(baselineMean??recentMean??0)):(rr-br);
    const fr=chunks.map(([s,e])=>numeric?(numericMean(clean.slice(s,e),def.id)??0):rate(clean.slice(s,e),def.id));
    const mean=fr.length?fr.reduce((a,b)=>a+b,0)/fr.length:(numeric?(allMean??0):all);
    const variance=fr.length?fr.reduce((a,b)=>a+(b-mean)**2,0)/fr.length:0;
    const stability=numeric
      ? Math.max(0,1-(Math.sqrt(variance)/(Math.abs(mean)+1)))
      : Math.max(0,1-Math.sqrt(variance));
    const occurrences=numeric?clean.length:Math.round(all*clean.length);
    const recentOccurrences=numeric?recent.length:Math.round(rr*recent.length);
    const status:MathPropertyEvidence['status']=
      clean.length===0?'RARE':
      (!numeric&&occurrences<2)?'RARE':
      (Math.abs(drift)>= (numeric?0.5:0.20))?'DRIFT':
      stability>=0.8?'STABLE':'NOT_INFORMATIVE';
    foldRates[idx]=fr;
    return {id:def.id,name:def.name,family:def.family,description:def.description,metric:numeric?'NUMERIC_MEAN':'BOOLEAN_RATE',allRate:all,recentRate:rr,baselineRate:br,allMean,recentMean,baselineMean,drift,foldRates:fr,stability,occurrences,recentOccurrences,status};
  });
}

export function mathematicalFingerprint(input:string|number){
  const f=classify4D(input); const trueProps=MATH_PROPERTY_CATALOG.filter(x=>f.properties[x.id]===true).map(x=>x.id);
  return {number:f.text, trueProperties:trueProps, factors:f.factors, tau:f.tau, sigma:f.sigma, phi:f.phi, mobius:f.mobius, digitSum:f.properties.digitSum, digitalRoot:f.properties.digitalRoot, kaprekarSteps:f.kaprekarSteps, reaches6174:f.reaches6174};
}
