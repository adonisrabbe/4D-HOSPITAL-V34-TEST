import { runHistoricalAnalysisCore, type HistoricalAnalysisCoreResult } from './historical-analysis-core';
import { ANALYSIS_CONTRACTS, validateAnalysisContracts, type AnalysisContract } from './analysis-contract';
import { ANALYSIS_CATALOG } from './analysis-catalog';
import type { CanonicalDraw } from './canonical-data';

export type AnalysisLevel='DESCRIPTIVE'|'STRUCTURAL'|'INFERENTIAL'|'PREDICTIVE'|'CONFIRMATORY';
export interface AnalysisRegistryEntry extends AnalysisContract {
  name:string; category:string; level:AnalysisLevel; formula:string; assumptions:string[];
  nullHypothesis:string; limitations:string[]; sampleRequirement:string;
  multipleTestingFamily:string; validationMethod:string; oosStatus:'NOT_APPLICABLE'|'REQUIRED'|'AVAILABLE'; version:string;
}
const inferLevel=(id:number):AnalysisLevel=>id>=104?'PREDICTIVE':id>=82?'INFERENTIAL':id>=26?'STRUCTURAL':'DESCRIPTIVE';
const names:Record<number,string>=Object.fromEntries(ANALYSIS_CATALOG.map(x=>[x.id,x.name]));
const nullFor=(c:AnalysisContract)=>c.target.includes('predict')||c.target.includes('future')?'H0: the evaluated model/signal does not outperform its declared baseline under the locked test protocol.':'H0: the observed historical structure is compatible with the declared null/reference model.';
export const ANALYSIS_REGISTRY:AnalysisRegistryEntry[]=ANALYSIS_CONTRACTS.map(c=>({
  ...c,name:names[c.id],category:c.family,level:inferLevel(c.id),formula:c.definition,
  assumptions:['Input rows are canonicalized and chronologically ordered.','Missing/invalid observations are excluded explicitly, never silently imputed.','A descriptive association is not treated as a causal or predictive claim.'],
  nullHypothesis:nullFor(c),limitations:['4D historical observations do not establish future causality.','Results can be unstable under regime change, sparse strata, duplicates, or selection effects.','A passing software contract is not independent scientific validation.'],
  sampleRequirement:c.dataRequirement, multipleTestingFamily:c.redundancyGroup||c.family,
  validationMethod:c.validation, oosStatus:c.id>=104?'REQUIRED':'AVAILABLE', version:'registry-v2'
}));
export const ANALYSIS_REGISTRY_VERSION='registry-v2';
export function getAnalysisRegistryEntry(id:number){return ANALYSIS_REGISTRY.find(x=>x.id===id);}
export function validateFullAnalysisRegistry():string[]{
  const errors:string[]=[]; if(ANALYSIS_REGISTRY.length!==107)errors.push(`Registry count=${ANALYSIS_REGISTRY.length}, expected 107`);
  const ids=ANALYSIS_REGISTRY.map(x=>x.id); for(let i=1;i<=107;i++)if(ids[i-1]!==i)errors.push(`Missing/non-sequential registry id ${i}`);
  for(const x of ANALYSIS_REGISTRY)for(const k of ['formula','nullHypothesis','sampleRequirement','validationMethod','version'] as const)if(!String(x[k]).trim())errors.push(`Analysis ${x.id} missing ${k}`);
  return errors;
}
export interface CentralAnalysisRegistryResult extends HistoricalAnalysisCoreResult { registryVersion:typeof ANALYSIS_REGISTRY_VERSION; contractCount:number; contractErrors:string[]; registryErrors:string[]; executableIds:number[]; }
export function runCentralAnalysisRegistry(draws:CanonicalDraw[],datasetVersion='runtime'):CentralAnalysisRegistryResult{
  const report=runHistoricalAnalysisCore(draws,datasetVersion),contractErrors=validateAnalysisContracts(),registryErrors=validateFullAnalysisRegistry();
  return {...report,registryVersion:ANALYSIS_REGISTRY_VERSION,contractCount:ANALYSIS_CONTRACTS.length,contractErrors,registryErrors,executableIds:report.analysis107.filter(x=>x.applicable).map(x=>x.id)};
}
