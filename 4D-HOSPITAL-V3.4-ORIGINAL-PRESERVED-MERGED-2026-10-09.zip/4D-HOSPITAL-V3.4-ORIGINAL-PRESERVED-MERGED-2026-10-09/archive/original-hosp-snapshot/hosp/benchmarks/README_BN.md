# 4D HOSPITAL — Independent Benchmark Protocol v1

এই benchmark suite-এর dataset-গুলো **সম্পূর্ণ synthetic এবং deterministic**। এগুলো কোনো বাস্তব draw/source সম্পর্কে প্রমাণ নয়। উদ্দেশ্য হলো engine-এর behaviour যাচাই করা।

## Fixture classes

1. `known_math_100` — known/deterministic mathematical fixture
2. `iid_uniform_null_500` — null-model fixture; এখানে signal আবিষ্কার করাকে false-positive control হিসেবে দেখা হবে
3. `deterministic_pattern_300` — deliberately structured signal-recovery fixture
4. `distribution_drift_400` — distribution-change fixture
5. `adversarial_duplicates_200` — duplicate/repetition stress fixture

## Required independent assertions

- chronological order preserved
- four-digit zero padding preserved
- known-answer behaviour is deterministic
- null data is not automatically treated as evidence
- duplicate adversary is detected
- drift fixture is treated as a drift candidate
- discovered signals are evaluated out-of-sample before confirmatory claims

## Important boundary

Benchmark PASS মানে software behaviour PASS। এটি কোনো real-world predictive accuracy, winning probability, medical safety, বা future-result guarantee প্রমাণ করে না।

Dataset SHA-256 hashes are emitted by `npm run audit:benchmark` so a benchmark run can be reproduced against the exact fixture version.
