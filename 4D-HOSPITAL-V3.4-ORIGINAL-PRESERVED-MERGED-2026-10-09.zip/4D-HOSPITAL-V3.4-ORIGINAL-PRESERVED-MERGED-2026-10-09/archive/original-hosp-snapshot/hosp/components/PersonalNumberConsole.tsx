import { useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "4d_hospital_personal_number_console_v1";
const PRIZES = [
  { id: "first", label: "FIRST PRIZE", bn: "ফার্স্ট প্রাইজ", accent: "#facc15" },
  { id: "second", label: "SECOND PRIZE", bn: "সেকেন্ড প্রাইজ", accent: "#38bdf8" },
  { id: "third", label: "THIRD PRIZE", bn: "থার্ড প্রাইজ", accent: "#a78bfa" },
  { id: "special", label: "SPECIAL", bn: "স্পেশাল", accent: "#34d399" },
] as const;
type PrizeId = typeof PRIZES[number]["id"];
type Slot = { primary: string; batch: string[]; locked: boolean };
type Store = Record<PrizeId, Slot>;

const emptySlot = (): Slot => ({ primary: "", batch: Array.from({ length: 12 }, () => ""), locked: false });
const emptyStore = (): Store => ({ first: emptySlot(), second: emptySlot(), third: emptySlot(), special: emptySlot() });

function normalize4(value: string) {
  return value.replace(/\D/g, "").slice(0, 4);
}
function loadStore(): Store {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyStore();
    const parsed = JSON.parse(raw) as Partial<Store>;
    const base = emptyStore();
    for (const p of PRIZES) {
      const s = parsed[p.id];
      if (!s) continue;
      base[p.id] = {
        primary: /^\d{4}$/.test(String(s.primary ?? "")) ? String(s.primary) : "",
        batch: Array.from({ length: 12 }, (_, i) => /^\d{4}$/.test(String(s.batch?.[i] ?? "")) ? String(s.batch[i]) : ""),
        locked: Boolean(s.locked),
      };
    }
    return base;
  } catch {
    return emptyStore();
  }
}

function persist(store: Store) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(store)); } catch { /* UI remains usable if storage is unavailable. */ }
}

export function PersonalNumberConsole() {
  const [store, setStore] = useState<Store>(() => loadStore());
  const [prize, setPrize] = useState<PrizeId>("first");
  const [draftPrimary, setDraftPrimary] = useState("");
  const [draftBatch, setDraftBatch] = useState<string[]>(Array.from({ length: 12 }, () => ""));
  const [notice, setNotice] = useState("নিজের কাজের জন্য প্রস্তুত · Local Private Workspace");

  const activePrize = PRIZES.find(p => p.id === prize)!;
  const active = store[prize];
  const filled = useMemo(() => draftBatch.filter(Boolean).length, [draftBatch]);

  useEffect(() => {
    const s = store[prize];
    setDraftPrimary(s.primary);
    setDraftBatch([...s.batch]);
  }, [prize, store]);

  function updateStore(next: Store, message: string) {
    setStore(next);
    persist(next);
    setNotice(message);
    window.setTimeout(() => setNotice("Auto-saved locally · Workspace ready"), 2200);
  }

  function savePrimary() {
    if (active.locked) return;
    if (draftPrimary && !/^\d{4}$/.test(draftPrimary)) {
      setNotice("প্রধান নাম্বার অবশ্যই ৪ ডিজিট হতে হবে।");
      return;
    }
    const next = { ...store, [prize]: { ...active, primary: draftPrimary } } as Store;
    updateStore(next, `${activePrize.label} · প্রধান নাম্বার সংরক্ষণ হয়েছে`);
  }

  function saveBatch() {
    if (active.locked) return;
    const clean = draftBatch.map(normalize4);
    if (clean.some(v => v.length > 0 && v.length !== 4)) {
      setNotice("Batch-এর প্রতিটি ব্যবহৃত ঘরে ৪ ডিজিট দিতে হবে।");
      return;
    }
    const next = { ...store, [prize]: { ...active, batch: clean } } as Store;
    updateStore(next, `${activePrize.label} · ${clean.filter(Boolean).length}টি batch number সংরক্ষণ হয়েছে`);
  }

  function toggleLock() {
    const next = { ...store, [prize]: { ...active, locked: !active.locked } } as Store;
    updateStore(next, active.locked ? `${activePrize.label} · Workspace UNLOCKED` : `${activePrize.label} · Workspace LOCKED`);
  }

  function clearCurrent() {
    if (active.locked) return;
    if (!window.confirm(`${activePrize.label} এর private numbers পরিষ্কার করবেন?`)) return;
    const next = { ...store, [prize]: emptySlot() } as Store;
    updateStore(next, `${activePrize.label} · workspace cleared`);
  }

  return (
    <div className="number-console min-h-full overflow-hidden">
      <div className="number-console-grid" aria-hidden="true" />
      <div className="number-rain" aria-hidden="true">
        {Array.from({ length: 42 }, (_, i) => <span key={i}>{(i * 731 + 4) % 10000}</span>)}
      </div>

      <div className="relative z-10 max-w-[1500px] mx-auto p-3 md:p-6 space-y-5">
        <section className="console-hero rounded-[2rem] overflow-hidden">
          <div className="heartbeat-line" aria-hidden="true"><svg viewBox="0 0 900 120" preserveAspectRatio="none"><path d="M0 65 H120 L145 65 L165 20 L190 104 L218 65 H310 L335 65 L352 42 L370 78 L388 65 H505 L530 65 L550 14 L575 108 L603 65 H700 L725 65 L745 36 L765 82 L785 65 H900" fill="none" pathLength="1" /></svg></div>
          <div className="p-5 md:p-8 relative">
            <div className="flex flex-col lg:flex-row lg:items-center gap-6">
              <div className="logo-3d" aria-label="4D HOSPITAL">
                <div className="logo-face">4D</div><div className="logo-depth">HOSPITAL</div>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 text-[10px] font-black tracking-[.28em] text-cyan-300"><span className="pulse-dot" /> PERSONAL NUMBER CONSOLE · PRIVATE WORKSPACE</div>
                <h1 className="text-3xl md:text-5xl font-black text-white mt-2 tracking-tight">Number Control <span className="text-cyan-300">∞</span></h1>
                <p className="text-slate-400 text-sm mt-2 max-w-3xl">নিজের জন্য 4-digit number লিখুন, edit করুন, save করুন এবং workspace lock করুন। এই পেজটি research result বা ভবিষ্যৎ ফলের prediction claim তৈরি করে না।</p>
              </div>
              <div className="console-status"><div className="text-[9px] text-slate-500 tracking-[.25em]">SYSTEM STATUS</div><div className="text-emerald-300 font-black text-lg mt-1">LOCAL · READY</div><div className="text-[9px] text-slate-600 mt-1">No cloud sync</div></div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-2 lg:grid-cols-4 gap-2">
          {PRIZES.map(p => {
            const s = store[p.id]; const selected = prize === p.id;
            return <button key={p.id} onClick={() => setPrize(p.id)} className={`prize-orb ${selected ? "selected" : ""}`} style={{ "--accent": p.accent } as React.CSSProperties}>
              <span className="orb-glow" /><span className="relative block text-[9px] tracking-[.2em] font-black" style={{ color: p.accent }}>{p.label}</span>
              <span className="relative block font-mono text-2xl md:text-3xl font-black text-white mt-1 tracking-widest">{s.primary || "----"}</span>
              <span className="relative block text-[9px] text-slate-500 mt-1">{s.batch.filter(Boolean).length}/12 batch · {s.locked ? "LOCKED" : "EDITABLE"}</span>
            </button>;
          })}
        </section>

        <div className="grid xl:grid-cols-[.9fr_1.1fr] gap-5">
          <section className="console-panel rounded-[1.75rem] p-4 md:p-6">
            <div className="flex items-center justify-between gap-3 mb-5"><div><div className="text-[9px] tracking-[.25em] font-black" style={{ color: activePrize.accent }}>PRIMARY NUMBER CONTROL</div><h2 className="text-xl md:text-2xl font-black text-white mt-1">{activePrize.bn}</h2></div><div className={`lock-badge ${active.locked ? "locked" : "unlocked"}`}>{active.locked ? "🔒 LOCKED" : "🔓 EDITABLE"}</div></div>
            <div className="digit-display" style={{ "--accent": activePrize.accent } as React.CSSProperties}>
              <div className="digit-scan" />
              <input aria-label={`${activePrize.label} primary number`} disabled={active.locked} inputMode="numeric" maxLength={4} value={draftPrimary} onChange={e => setDraftPrimary(normalize4(e.target.value))} placeholder="0000" />
              <div className="digit-caption">4 DIGIT · MANUAL INPUT</div>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              <button disabled={active.locked} onClick={savePrimary} className="console-btn primary">💾 SAVE NUMBER</button>
              <button onClick={toggleLock} className={`console-btn ${active.locked ? "unlock" : "lock"}`}>{active.locked ? "🔓 UNLOCK" : "🔒 LOCK"}</button>
            </div>
            <button disabled={active.locked} onClick={clearCurrent} className="w-full mt-2 rounded-xl py-2 text-[10px] font-black tracking-widest text-red-300/70 hover:text-red-200 hover:bg-red-500/5 disabled:opacity-30">CLEAR THIS PRIZE WORKSPACE</button>
          </section>

          <section className="console-panel rounded-[1.75rem] p-4 md:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4"><div><div className="text-[9px] tracking-[.25em] font-black text-purple-300">BATCH NUMBER MATRIX</div><h2 className="text-xl md:text-2xl font-black text-white mt-1">10–12 Number Private Editor</h2></div><div className="text-xs text-slate-500">{filled}/12 filled</div></div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
              {draftBatch.map((value, i) => <label key={i} className="batch-slot" style={{ "--accent": activePrize.accent } as React.CSSProperties}><span>{String(i + 1).padStart(2, "0")}</span><input disabled={active.locked} inputMode="numeric" maxLength={4} value={value} onChange={e => setDraftBatch(prev => prev.map((x, j) => j === i ? normalize4(e.target.value) : x))} placeholder="----" /></label>)}
            </div>
            <div className="flex gap-2 mt-4"><button disabled={active.locked} onClick={saveBatch} className="console-btn primary flex-1">💾 SAVE BATCH</button><button disabled={active.locked} onClick={() => setDraftBatch(Array.from({ length: 12 }, () => ""))} className="console-btn secondary">RESET</button></div>
          </section>
        </div>

        <section className="console-panel rounded-2xl px-4 py-3 flex flex-col md:flex-row md:items-center gap-2 md:gap-4"><span className="pulse-dot" /><span className="text-xs font-bold text-cyan-200">{notice}</span><span className="md:ml-auto text-[9px] text-slate-600">Storage: device-local · {new Date().toLocaleDateString("bn-BD")}</span></section>
      </div>
    </div>
  );
}
