import { useMemo, useState, type ReactNode } from "react";
import { run107Analysis, type Analysis107Result } from "../lib/analysis-engine-107";
import { ANALYSIS_CATALOG } from "../lib/analysis-catalog";
import type { CanonicalDraw } from "../lib/canonical-data";

type ResultRow = {
  id:number; company:string; date:string; drawNo:string|null;
  first:string; second:string; third:string; special:string[]; consolation:string[];
};

type Props = { results: ResultRow[]; onView?: (v:any)=>void };

const familyOf=(id:number)=>ANALYSIS_CATALOG[id-1]?.family ?? "General";
const categoryOf=(id:number)=>ANALYSIS_CATALOG[id-1]?.category ?? "validation";

function panel(title:string, subtitle:string, children:ReactNode, accent="rgba(59,130,246,.28)"){
  return <section className="rounded-3xl p-4 md:p-5 bg-white/[.035] border" style={{borderColor:accent,boxShadow:"0 12px 45px rgba(0,0,0,.22)"}}>
    <div className="mb-4"><div className="text-white font-black text-base md:text-lg">{title}</div><div className="text-slate-400 text-xs mt-1">{subtitle}</div></div>{children}
  </section>;
}

function Stat({label,value,sub}:{label:string;value:string|number;sub?:string}){
  return <div className="rounded-2xl p-3 bg-black/25 border border-white/10"><div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div><div className="text-xl md:text-2xl font-black font-mono text-white mt-1">{value}</div>{sub&&<div className="text-[10px] text-slate-500 mt-1">{sub}</div>}</div>
}

function statusLabel(x:Analysis107Result){
  if(x.evidence==='SUPPORT') return {t:"SUPPORT",c:"text-emerald-300 bg-emerald-500/10 border-emerald-500/20"};
  if(x.evidence==='CONFLICT') return {t:"CONFLICT",c:"text-red-300 bg-red-500/10 border-red-500/20"};
  if(x.evidence==='INSUFFICIENT_DATA') return {t:"INSUFFICIENT",c:"text-amber-300 bg-amber-500/10 border-amber-500/20"};
  if(x.evidence==='NOT_APPLICABLE') return {t:"N/A",c:"text-slate-400 bg-white/5 border-white/10"};
  return {t:"NEUTRAL",c:"text-sky-300 bg-sky-500/10 border-sky-500/20"};
}

function scoreEvidence(rows:Analysis107Result[], sample:number){
  const applicable=rows.filter(x=>x.applicable);
  const support=applicable.filter(x=>x.evidence==='SUPPORT').length;
  const neutral=applicable.filter(x=>x.evidence==='NEUTRAL').length;
  const conflict=applicable.filter(x=>x.evidence==='CONFLICT').length;
  const dataFactor=Math.min(1,sample/200);
  const agreement=applicable.length ? (support + .5*neutral)/(applicable.length) : 0;
  const penalty=conflict/Math.max(1,applicable.length)*.35;
  return Math.max(0,Math.min(99.9,100*(.35*dataFactor+.65*Math.max(0,agreement-penalty))));
}

function digitFrequency(results:ResultRow[]){
  const c=Array(10).fill(0); let n=0;
  for(const r of results){ for(const num of [r.first,r.second,r.third]) for(const ch of num){c[Number(ch)]++;n++;} }
  return c.map((count,digit)=>({digit,count,share:n?count/n:0})).sort((a,b)=>b.count-a.count);
}

function candidateScore(num:string, freq:{digit:number;count:number;share:number}[], rows:Analysis107Result[]){
  const map=new Map(freq.map(x=>[x.digit,x.share]));
  const base=num.split("").reduce((s,d)=>s+(map.get(Number(d))??0),0)/4;
  const support=rows.filter(x=>x.evidence==='SUPPORT').length/Math.max(1,rows.length);
  return Math.min(99.9,Math.max(0,(base*70+support*30)*100));
}

export function AllAnalysisResultsPage({results}:Props){
  const [query,setQuery]=useState("");
  const [family,setFamily]=useState("ALL");
  const draws=useMemo(()=>results.map(r=>r as unknown as CanonicalDraw),[results]);
  const analysis=useMemo(()=>run107Analysis(draws),[draws]);
  const families=useMemo(()=>["ALL",...Array.from(new Set(analysis.map(x=>familyOf(x.id))))],[analysis]);
  const filtered=analysis.filter(x=>(family==='ALL'||familyOf(x.id)===family)&&(x.name.toLowerCase().includes(query.toLowerCase())||String(x.id)===query.trim()));
  const support=analysis.filter(x=>x.evidence==='SUPPORT').length;
  const conflicts=analysis.filter(x=>x.evidence==='CONFLICT').length;
  const insufficient=analysis.filter(x=>x.evidence==='INSUFFICIENT_DATA').length;
  const implemented=analysis.filter(x=>x.status===1).length;
  return <div className="max-w-7xl mx-auto p-3 md:p-5 space-y-4">
    {panel("① ALL ANALYSIS RESULTS","107টি canonical analysis-এর live output — একই dataset, একই calculation engine, একই evidence vocabulary.",<>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 mb-4"><Stat label="Analyses" value={analysis.length}/><Stat label="Implemented" value={implemented}/><Stat label="Support" value={support}/><Stat label="Conflict" value={conflicts}/><Stat label="Insufficient" value={insufficient}/></div>
      <div className="flex flex-col md:flex-row gap-2 mb-3"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Analysis ID বা নাম খুঁজুন…" className="flex-1 rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm text-white outline-none"/><select value={family} onChange={e=>setFamily(e.target.value)} className="rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm text-white">{families.map(f=><option key={f} value={f}>{f}</option>)}</select></div>
      <div className="overflow-auto rounded-2xl border border-white/10"><table className="w-full text-xs min-w-[900px]"><thead className="bg-slate-950 sticky top-0"><tr className="text-slate-500"><th className="p-2 text-left">#</th><th className="p-2 text-left">Analysis</th><th className="p-2 text-left">Family</th><th className="p-2 text-left">Category</th><th className="p-2 text-left">Evidence</th><th className="p-2 text-left">State</th><th className="p-2 text-right">n</th><th className="p-2 text-left">Note</th></tr></thead><tbody>{filtered.map(x=>{const s=statusLabel(x);return <tr key={x.id} className="border-t border-white/5"><td className="p-2 text-slate-600">{x.id}</td><td className="p-2 text-white font-semibold">{x.name}</td><td className="p-2 text-purple-300">{familyOf(x.id)}</td><td className="p-2 text-slate-400">{categoryOf(x.id)}</td><td className="p-2"><span className={`inline-flex rounded-full border px-2 py-1 text-[9px] font-black ${s.c}`}>{s.t}</span></td><td className="p-2 text-slate-400">{x.status===1?"IMPLEMENTED":x.status===5?"INSUFFICIENT_DATA":x.status===6?"NOT_APPLICABLE":`STATUS ${x.status}`}</td><td className="p-2 text-right text-slate-500">{x.sampleSize}</td><td className="p-2 text-slate-500 max-w-[280px]">{x.note||"—"}</td></tr>})}</tbody></table></div>
      <div className="mt-3 text-[10px] text-slate-600">Dataset rows: {results.length.toLocaleString()} · 107-core-v1 · ফলাফল descriptive/evidence output; কোনো row future outcome guarantee করে না।</div>
    </>)}
  </div>;
}

export function ResearchIntelligencePage({results}:Props){
  const draws=useMemo(()=>results.map(r=>r as unknown as CanonicalDraw),[results]);
  const analysis=useMemo(()=>run107Analysis(draws),[draws]);
  const score=scoreEvidence(analysis,results.length);
  const families=useMemo(()=>Array.from(new Set(analysis.map(x=>familyOf(x.id)))),[analysis]);
  const familyStats=families.map(f=>{const a=analysis.filter(x=>familyOf(x.id)===f);return{f,n:a.length,s:a.filter(x=>x.evidence==='SUPPORT').length,c:a.filter(x=>x.evidence==='CONFLICT').length}}).sort((a,b)=>b.s-a.s);
  return <div className="max-w-7xl mx-auto p-3 md:p-5 space-y-4">
    {panel("② RESEARCH INTELLIGENCE INFRASTRUCTURE","107টি ফলাফল থেকে evidence-aware research architecture: signal → validation → stability → OOS → decision.",<>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2"><Stat label="Evidence Index" value={`${score.toFixed(1)}%`} sub="descriptive research index"/><Stat label="Dataset" value={results.length.toLocaleString()} sub="records"/><Stat label="Families" value={families.length}/><Stat label="Support" value={analysis.filter(x=>x.evidence==='SUPPORT').length}/><Stat label="Conflict" value={analysis.filter(x=>x.evidence==='CONFLICT').length}/></div>
      <div className="grid lg:grid-cols-5 gap-2 items-stretch mt-4">{["DATA INTEGRITY","107 ANALYSIS","EVIDENCE FILTER","OOS / STABILITY","RESEARCH DECISION"].map((x,i)=><div key={x} className="relative rounded-2xl p-4 bg-black/25 border border-white/10 min-h-[100px]"><div className="text-[10px] text-slate-500">LAYER {i+1}</div><div className="text-white font-black mt-2 text-sm">{x}</div><div className="text-slate-500 text-[10px] mt-2">{["validity · duplicates · chronology","descriptive · structural · statistical · model","support · neutral · conflict · insufficiency","walk-forward · stability · blind split","publish / hold / investigate"][i]}</div>{i<4&&<span className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 text-slate-600 text-lg">→</span>}</div>)}</div>
      <div className="grid lg:grid-cols-2 gap-3 mt-4"><div className="rounded-2xl bg-black/20 border border-white/10 p-4"><div className="text-white font-bold text-sm mb-3">Family Evidence Map</div><div className="space-y-2">{familyStats.slice(0,12).map(x=><div key={x.f}><div className="flex justify-between text-[10px] mb-1"><span className="text-slate-300">{x.f}</span><span className="text-slate-500">S {x.s} · C {x.c} · N {x.n}</span></div><div className="h-2 rounded-full bg-white/5 overflow-hidden"><div className="h-full rounded-full" style={{width:`${x.n?Math.min(100,x.s/x.n*100):0}%`,background:"linear-gradient(90deg,#22c55e,#06b6d4)"}}/></div></div>)}</div></div><div className="rounded-2xl bg-black/20 border border-white/10 p-4"><div className="text-white font-bold text-sm mb-3">Research Governance</div><div className="space-y-2 text-xs text-slate-400">{["No automatic future-certainty claim","Conflicts remain visible","Insufficient data blocks over-interpretation","OOS validation is required before predictive claims","Every result is tied to dataset + calculation version"].map((x,i)=><div key={x} className="flex gap-2"><span className="text-emerald-400">{i<4?"✓":"◆"}</span><span>{x}</span></div>)}</div></div></div>
    </>)}
  </div>;
}

export function FinalResearchResultPage({results}:Props){
  const [company,setCompany]=useState("ALL");
  const filtered=useMemo(()=>company==='ALL'?results:results.filter(r=>r.company===company),[results,company]);
  const analysis=useMemo(()=>run107Analysis(filtered.map(r=>r as unknown as CanonicalDraw)),[filtered]);
  const freq=useMemo(()=>digitFrequency(filtered),[filtered]);
  const candidates=useMemo(()=>{
    const latest=[...filtered].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
    const seeds=new Set<string>();
    for(const r of latest.slice(0,30)) seeds.add(r.first);
    for(let i=0;i<10&&i<freq.length;i++){
      const d=String(freq[i].digit); for(let p=0;p<4;p++) seeds.add(d+"000".slice(0,3).replace(/0/g,d));
    }
    const vals=[...seeds].filter(x=>/^\d{4}$/.test(x)).map(num=>({num,score:candidateScore(num,freq,analysis)})).sort((a,b)=>b.score-a.score).slice(0,10);
    return vals;
  },[filtered,freq,analysis]);
  const index=Math.min(99.9,scoreEvidence(analysis,filtered.length));
  const top=candidates[0];
  return <div className="max-w-7xl mx-auto p-3 md:p-5 space-y-4">
    {panel("③ FINAL RESEARCH RESULT","চূড়ান্ত ফল হলো evidence-ranked research output; এটি ভবিষ্যৎ ড্র-এর নিশ্চিত probability নয়।",<>
      <div className="flex flex-col md:flex-row gap-2 mb-4"><select value={company} onChange={e=>setCompany(e.target.value)} className="rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm text-white"><option value="ALL">সব কোম্পানি</option><option value="magnum">Magnum 4D</option><option value="toto">Toto 4D</option><option value="damacai">Da Ma Cai</option><option value="singapore">Singapore 4D</option></select><div className="flex-1 rounded-xl px-3 py-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs">99.9% = maximum evidence-index display ceiling, <b>winning probability নয়</b>। Actual index: {index.toFixed(1)}%.</div></div>
      <div className="grid lg:grid-cols-[1.15fr_.85fr] gap-4"><div className="rounded-3xl p-5 bg-gradient-to-br from-emerald-500/15 via-cyan-500/5 to-purple-500/10 border border-emerald-400/20"><div className="text-[10px] tracking-[.2em] text-emerald-300">TOP EVIDENCE-RANKED CANDIDATE</div><div className="font-mono text-6xl md:text-8xl font-black text-white tracking-[.12em] mt-3">{top?.num??"—"}</div><div className="text-emerald-300 font-black text-xl mt-2">{top?top.score.toFixed(1):"0.0"}% Evidence / Model Index</div><div className="text-slate-400 text-xs mt-3">Dataset n={filtered.length.toLocaleString()} · 107 analyses executed · ranking is reproducible from current data.</div></div><div className="grid grid-cols-2 gap-2"><Stat label="Research Index" value={`${index.toFixed(1)}%`} sub="not win probability"/><Stat label="Candidates" value={candidates.length}/><Stat label="Support" value={analysis.filter(x=>x.evidence==='SUPPORT').length}/><Stat label="Conflicts" value={analysis.filter(x=>x.evidence==='CONFLICT').length}/></div></div>
      <div className="mt-4 rounded-2xl border border-white/10 overflow-auto"><table className="w-full text-xs"><thead className="bg-slate-950"><tr className="text-slate-500"><th className="p-3 text-left">Rank</th><th className="p-3 text-left">4D</th><th className="p-3 text-right">Index</th><th className="p-3 text-left">Interpretation</th></tr></thead><tbody>{candidates.map((x,i)=><tr key={x.num} className="border-t border-white/5"><td className="p-3 text-slate-500">#{i+1}</td><td className="p-3 font-mono font-black text-white text-lg">{x.num}</td><td className="p-3 text-right text-emerald-300 font-black">{x.score.toFixed(1)}%</td><td className="p-3 text-slate-400">Evidence-ranked candidate; independent OOS calibration ছাড়া probability claim করা হয়নি।</td></tr>)}</tbody></table></div>
      <div className="mt-4 grid md:grid-cols-3 gap-2">{freq.slice(0,6).map(x=><div key={x.digit} className="rounded-xl bg-black/20 border border-white/10 p-3"><div className="flex justify-between"><span className="text-white font-black">Digit {x.digit}</span><span className="text-slate-500">{(x.share*100).toFixed(2)}%</span></div><div className="h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden"><div className="h-full rounded-full bg-cyan-400" style={{width:`${Math.min(100,x.share*1000)}%`}}/></div></div>)}</div>
    </>)}
    <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-4 text-xs text-red-200">⚠️ Scientific guard: historical 4D data alone cannot establish a 99.9% chance that a specific number will appear next. This page deliberately separates <b>evidence/model confidence</b> from <b>future-outcome probability</b>.</div>
  </div>;
}

export function ResearchResultTriad({results,onView}:Props){
  const [tab,setTab]=useState<"all"|"infra"|"final">("all");
  return <div className="min-h-full"><div className="sticky top-0 z-20 px-3 md:px-5 py-3 bg-[#0f0f0f]/95 backdrop-blur border-b border-white/10"><div className="max-w-7xl mx-auto flex gap-2 overflow-x-auto"><button onClick={()=>setTab("all")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='all'?"bg-blue-500/20 text-blue-200 border border-blue-500/30":"bg-white/5 text-slate-400"}`}>① All Analysis Results</button><button onClick={()=>setTab("infra")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='infra'?"bg-purple-500/20 text-purple-200 border border-purple-500/30":"bg-white/5 text-slate-400"}`}>② Research Intelligence</button><button onClick={()=>setTab("final")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='final'?"bg-emerald-500/20 text-emerald-200 border border-emerald-500/30":"bg-white/5 text-slate-400"}`}>③ Final Research Result</button></div></div>{tab==='all'?<AllAnalysisResultsPage results={results} onView={onView}/>:tab==='infra'?<ResearchIntelligencePage results={results} onView={onView}/>:<FinalResearchResultPage results={results} onView={onView}/>}</div>;
}
