import React, { useMemo, useState, type ReactNode } from 'react';
import { analyzeMathEvidence, classify4D, MATH_PROPERTY_CATALOG, type MathPropertyId } from '../lib/number-theory-lab';

type Row = { first:string; second:string; third:string; special?:string[]; consolation?:string[]; date?:string };

function all4D(rows:Row[]):string[]{
  const ordered=[...rows].sort((a,b)=>String(b.date??'').localeCompare(String(a.date??'')));
  return ordered.flatMap(r=>[r.first,r.second,r.third,...(r.special||[]),...(r.consolation||[])])
    .map(x=>String(x||'').padStart(4,'0')).filter(x=>/^\d{4}$/.test(x));
}
function pct(x:number){return `${Math.round(x*100)}%`;}
function Badge({children,kind='gray'}:{children:ReactNode;kind?:'green'|'amber'|'red'|'gray';key?:string}){
  const cls=kind==='green'?'text-emerald-300 bg-emerald-500/10 border-emerald-500/20':kind==='amber'?'text-amber-300 bg-amber-500/10 border-amber-500/20':kind==='red'?'text-red-300 bg-red-500/10 border-red-500/20':'text-slate-300 bg-white/5 border-white/10';
  return <span className={`inline-flex px-2 py-1 rounded-lg border text-[10px] font-bold ${cls}`}>{children}</span>;
}

export function NumberTheoryLabView({results}:{results:Row[]}){
  const [query,setQuery]=useState('6174');
  const [family,setFamily]=useState('All');
  const numbers=useMemo(()=>all4D(results),[results]);
  const evidence=useMemo(()=>analyzeMathEvidence(numbers),[numbers]);
  const fingerprint=useMemo(()=>/^\d{4}$/.test(query)?classify4D(query):null,[query]);
  const families=useMemo(()=>['All',...Array.from(new Set(MATH_PROPERTY_CATALOG.map(x=>x.family)))],[ ]);
  const filtered=evidence.filter(e=>family==='All'||e.family===family);
  const stable=evidence.filter(e=>e.status==='STABLE').length;
  const drift=evidence.filter(e=>e.status==='DRIFT').length;
  return <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-5">
    <div className="rounded-2xl p-5 bg-gradient-to-br from-cyan-500/10 to-indigo-500/10 border border-cyan-500/20">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><h1 className="text-2xl font-black text-white">🧮 Number Theory & Mathematical Laboratory</h1>
          <p className="text-slate-400 text-xs mt-1">4-digit historical data-কে mathematical fingerprint, prevalence, drift এবং chronological stability দিয়ে যাচাই করে। এটি নিজে কোনো guaranteed result বা winning probability নয়।</p></div>
        <Badge kind="green">Evidence-first</Badge>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4">
        {[['4D observations',numbers.length],['Properties',MATH_PROPERTY_CATALOG.length],['Stable',stable],['Drift',drift],['Families',families.length-1]].map(([a,b])=><div key={String(a)} className="rounded-xl p-3 bg-black/20 border border-white/5"><div className="text-[9px] text-slate-500">{a}</div><div className="text-xl font-black text-white">{b}</div></div>)}
      </div>
    </div>

    <div className="grid lg:grid-cols-2 gap-4">
      <div className="rounded-2xl p-4 bg-white/5 border border-white/10">
        <div className="text-white font-black mb-2">① একটি 4-digit-এর Mathematical Fingerprint</div>
        <div className="flex gap-2"><input inputMode="numeric" maxLength={4} value={query} onChange={e=>setQuery(e.target.value.replace(/\D/g,'').slice(0,4))} className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-lg"/><Badge kind="gray">0000–9999</Badge></div>
        {!fingerprint?<div className="text-red-300 text-xs mt-3">৪ digit দিন।</div>:<>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
            {[['Digit sum',String(fingerprint.properties.digitSum)],['Digital root',String(fingerprint.properties.digitalRoot)],['τ(n)',String(fingerprint.tau)],['σ(n)',String(fingerprint.sigma)],['φ(n)',String(fingerprint.phi)],['μ(n)',String(fingerprint.mobius)],['Factors',fingerprint.factors.length?fingerprint.factors.join(' × '):'—'],['Kaprekar',fingerprint.reaches6174?`6174 · ${fingerprint.kaprekarSteps} steps`:fingerprint.kaprekarTerminal]].map(([a,b])=><div key={a} className="rounded-xl p-2.5 bg-black/20 border border-white/5"><div className="text-[9px] text-slate-500">{a}</div><div className="text-xs text-white font-bold break-all">{b}</div></div>)}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">{MATH_PROPERTY_CATALOG.filter(p=>fingerprint.properties[p.id]===true).map(p=><Badge key={p.id} kind="green">{p.name}</Badge>)}</div>
          <div className="text-[9px] text-slate-600 mt-3">নোট: কিছু property domain-specific। যেমন Mersenne/Fermat/Sophie Germain ইত্যাদি এখানে mathematical classification; historical evidence না থাকলে ranking weight দেওয়া হবে না।</div>
        </>}
      </div>

      <div className="rounded-2xl p-4 bg-white/5 border border-white/10">
        <div className="text-white font-black mb-2">② Research Gate — কোন formula সত্যিই কাজে লাগে?</div>
        <div className="space-y-2 text-[10px] text-slate-400">
          <div className="rounded-xl p-3 bg-black/20 border border-white/5"><b className="text-white">Step 1 · Classification</b><br/>প্রতিটি 4-digit-এর property নির্ধারণ।</div>
          <div className="rounded-xl p-3 bg-black/20 border border-white/5"><b className="text-white">Step 2 · Historical prevalence</b><br/>পুরো dataset-এ property কতবার এসেছে।</div>
          <div className="rounded-xl p-3 bg-black/20 border border-white/5"><b className="text-white">Step 3 · Recent drift</b><br/>recent window বনাম older baseline; বড় drift হলে সতর্কতা।</div>
          <div className="rounded-xl p-3 bg-black/20 border border-white/5"><b className="text-white">Step 4 · Chronological stability</b><br/>৩টি chronological block-এ property rate একই রকম থাকে কি না।</div>
          <div className="rounded-xl p-3 bg-black/20 border border-white/5"><b className="text-white">Step 5 · Promotion gate</b><br/>stable + sufficiently observed + leakage-safe OOS validation ছাড়া formula-কে active signal হিসেবে গণ্য করা হবে না।</div>
        </div>
      </div>
    </div>

    <div className="rounded-2xl p-4 bg-white/5 border border-white/10">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3"><div><div className="text-white font-black">③ Mathematical Evidence Register</div><div className="text-slate-500 text-[10px]">Prevalence ≠ predictive power. Drift ≠ causation. এখানে formula-কে আগে research feature হিসেবে যাচাই করা হচ্ছে।</div></div>
        <select value={family} onChange={e=>setFamily(e.target.value)} className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs">{families.map(f=><option key={f}>{f}</option>)}</select>
      </div>
      <div className="overflow-auto rounded-xl border border-white/10"><table className="w-full text-[10px]"><thead className="bg-slate-950 sticky top-0"><tr className="text-slate-500"><th className="text-left p-2">Formula / Property</th><th className="text-left p-2">Family</th><th className="text-right p-2">All</th><th className="text-right p-2">Recent</th><th className="text-right p-2">Baseline</th><th className="text-right p-2">Drift</th><th className="text-right p-2">Stability</th><th className="text-left p-2">Gate</th></tr></thead><tbody>{filtered.map(e=><tr key={e.id} className="border-t border-white/5"><td className="p-2 text-white font-medium">{e.name}<div className="text-[8px] text-slate-600 mt-0.5">{e.description}</div></td><td className="p-2 text-purple-300">{e.family}</td><td className="p-2 text-right text-slate-300">{e.metric==='NUMERIC_MEAN'?e.allMean?.toFixed(2):pct(e.allRate)}</td><td className="p-2 text-right text-slate-300">{e.metric==='NUMERIC_MEAN'?e.recentMean?.toFixed(2):pct(e.recentRate)}</td><td className="p-2 text-right text-slate-500">{e.metric==='NUMERIC_MEAN'?(e.baselineMean?.toFixed(2)??'—'):pct(e.baselineRate)}</td><td className={`p-2 text-right ${Math.abs(e.drift)>=(e.metric==='NUMERIC_MEAN'?.5:.2)?'text-amber-300':'text-slate-400'}`}>{e.drift>=0?'+':''}{e.metric==='NUMERIC_MEAN'?e.drift.toFixed(2):pct(e.drift)}</td><td className="p-2 text-right text-cyan-300">{pct(e.stability)}</td><td className="p-2"><Badge kind={e.status==='STABLE'?'green':e.status==='DRIFT'?'amber':e.status==='RARE'?'red':'gray'}>{e.status}</Badge></td></tr>)}</tbody></table></div>
    </div>

    <div className="rounded-xl p-3 bg-amber-500/5 border border-amber-500/15 text-[10px] text-slate-500">
      ⚠️ <b className="text-slate-300">Research rule:</b> Goldbach, Twin Prime Conjecture, Riemann Hypothesis, Fermat's Last Theorem, etc. are mathematical reference concepts—not direct 4D outcome signals. Likewise, Benford/Zipf-style laws are only evidence when the observed dataset actually satisfies their assumptions and passes validation.
    </div>
  </div>;
}
