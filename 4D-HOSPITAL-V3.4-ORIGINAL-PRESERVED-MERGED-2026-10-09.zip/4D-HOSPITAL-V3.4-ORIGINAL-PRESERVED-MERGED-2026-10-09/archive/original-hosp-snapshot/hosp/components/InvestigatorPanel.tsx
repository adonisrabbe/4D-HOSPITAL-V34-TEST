import { useMemo, useState } from 'react';
import type { CanonicalDraw } from '../lib/canonical-data';
import { buildInvestigatorReport, answerInvestigatorQuestion } from '../lib/investigator';

export function InvestigatorPanel({results,onView}:{results:CanonicalDraw[];onView?:(v:any)=>void}){
  const [question,setQuestion]=useState('');
  const report=useMemo(()=>buildInvestigatorReport(results),[results]);
  const answer=useMemo(()=>question.trim()?answerInvestigatorQuestion(question,report):'',[question,report]);
  const sev=(s:string)=>s==='GOOD'?'text-emerald-300 border-emerald-800/60 bg-emerald-950/20':s==='WATCH'?'text-amber-300 border-amber-800/60 bg-amber-950/20':s==='ALERT'?'text-rose-300 border-rose-800/60 bg-rose-950/20':'text-sky-300 border-sky-800/60 bg-sky-950/20';
  return <div className="p-4 md:p-6 space-y-4 max-w-7xl mx-auto">
    <div className="rounded-2xl p-5 border border-violet-800/40 bg-gradient-to-br from-violet-950/30 via-zinc-950 to-zinc-950">
      <div className="flex flex-wrap items-start gap-4">
        <div className="text-4xl">🕵️</div><div className="flex-1"><div className="text-white text-xl font-black">Investigator Research Panel</div><div className="text-zinc-400 text-sm mt-1">107 Core + 28 Signals + Mathematical Lab-এর ফলকে স্বাধীন প্রমাণ, conflict, drift, redundancy ও uncertainty দৃষ্টিতে তদন্ত করার কেন্দ্র।</div></div>
        <div className="rounded-xl px-3 py-2 border border-zinc-800 bg-black/30 text-right"><div className="text-zinc-500 text-[10px]">VALID RECORDS</div><div className="text-white font-black text-xl">{report.sampleSize.toLocaleString()}</div></div>
      </div>
    </div>

    <div className="grid grid-cols-2 lg:grid-cols-5 gap-2">
      {[['Records',report.sampleSize.toLocaleString()],['Unique',report.uniqueNumbers.toLocaleString()],['Duplicate',`${(report.duplicateRate*100).toFixed(1)}%`],['Recent window',report.recentWindow.toLocaleString()],['Math drift',String(report.driftMath.length)]].map(([a,b])=><div key={a} className="rounded-xl border border-zinc-800 bg-zinc-950 p-3"><div className="text-zinc-600 text-[10px] uppercase">{a}</div><div className="text-white font-black text-lg mt-1">{b}</div></div>)}
    </div>

    <div className="grid lg:grid-cols-2 gap-4">
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4"><div className="text-white font-black mb-3">🔍 Evidence Detective</div><div className="space-y-2">{report.findings.map(f=><div key={f.id} className={`rounded-xl border p-3 ${sev(f.severity)}`}><div className="flex items-center justify-between gap-2"><div className="font-bold text-sm">{f.title}</div><span className="text-[9px] font-black">{f.severity}</span></div><div className="text-xs mt-1 opacity-80">{f.detail}</div><div className="text-[10px] mt-2 opacity-60">{f.evidence}</div></div>)}</div></section>
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4"><div className="text-white font-black mb-3">🧬 Redundancy & Null-model Guard</div><div className="space-y-2">{report.redundancyWarnings.map((x,i)=><div key={i} className="text-xs text-amber-200/80 rounded-xl p-3 bg-amber-950/20 border border-amber-900/40">⚠️ {x}</div>)}<div className="rounded-xl p-3 bg-zinc-900 border border-zinc-800 text-xs text-zinc-400">Uniform exact-number baseline: <b className="text-white">1 / 10,000</b>. এটি কেবল reference baseline; observed historical frequency-কে automatic evidence হিসেবে ধরা হচ্ছে না।</div><div className="rounded-xl p-3 bg-zinc-900 border border-zinc-800 text-xs text-zinc-400">Observed max exact-number concentration: <b className="text-white">{(report.nullModel.concentration*100).toFixed(2)}%</b></div></div></section>
    </div>

    <section className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4"><div className="flex items-center justify-between gap-3 mb-3"><div><div className="text-white font-black">🧮 Mathematical Evidence</div><div className="text-zinc-600 text-xs">Formula = feature; formula ≠ automatic independent vote</div></div><div className="text-[10px] text-zinc-500">{report.mathEvidence.length} properties</div></div><div className="grid md:grid-cols-2 xl:grid-cols-3 gap-2">{report.mathEvidence.filter(x=>x.status!=='NOT_INFORMATIVE').slice(0,18).map(x=><div key={x.id} className="rounded-xl border border-zinc-800 p-3"><div className="text-white text-xs font-bold truncate">{x.name}</div><div className="flex items-center justify-between mt-2 text-[10px]"><span className={x.status==='DRIFT'?'text-amber-300':x.status==='STABLE'?'text-emerald-300':'text-zinc-500'}>{x.status}</span><span className="text-zinc-600">stability {(x.stability*100).toFixed(0)}%</span></div><div className="text-zinc-500 text-[10px] mt-1">{x.metric==='NUMERIC_MEAN'?`mean ${x.allMean?.toFixed(2)??'—'} · recent ${x.recentMean?.toFixed(2)??'—'}`:`rate ${(x.allRate*100).toFixed(2)}% · recent ${(x.recentRate*100).toFixed(2)}%`}</div></div>)}</div></section>

    <section className="rounded-2xl border border-cyan-900/50 bg-cyan-950/10 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
        <div><div className="text-white font-black">🧪 Advanced Research Laboratory v3</div><div className="text-zinc-500 text-xs mt-1">Bayesian → SPRT → Information Theory → Transition/Context → Null Model → FDR → Redundancy → Stability → Motif → Symbolic → Conformal → Meta Evidence</div></div>
        <div className={`rounded-xl px-3 py-2 border text-xs font-black ${report.advancedResearch.constitution.passed?'text-emerald-300 border-emerald-800/50':'text-amber-300 border-amber-800/50'}`}>{report.advancedResearch.constitution.passed?'RESEARCH GATES PASS':'GATES INCOMPLETE'}</div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-3"><div className="text-zinc-600 text-[9px]">Bayes posterior</div><div className="text-white font-black">{(report.advancedResearch.bayesian.evenRate.posteriorMean*100).toFixed(1)}%</div><div className="text-[9px] text-zinc-600">{report.advancedResearch.bayesian.evenRate.status}</div></div>
        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-3"><div className="text-zinc-600 text-[9px]">SPRT</div><div className="text-white font-black">{report.advancedResearch.sprt.evenRate.decision}</div></div>
        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-3"><div className="text-zinc-600 text-[9px]">Mutual information</div><div className="text-white font-black">{report.advancedResearch.information.mutualInformation.toFixed(3)}</div></div>
        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-3"><div className="text-zinc-600 text-[9px]">Change points</div><div className="text-white font-black">{report.advancedResearch.changePoints.length}</div></div>
        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-3"><div className="text-zinc-600 text-[9px]">FDR tested</div><div className="text-white font-black">{report.advancedResearch.fdr.length}</div></div>
      </div>
      <div className="grid md:grid-cols-3 gap-2 mt-3">
        <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-3"><div className="text-white text-xs font-bold mb-1">Null Model</div><div className="text-zinc-500 text-[10px]">empirical p = {report.advancedResearch.nullTests.recentBaseline.empiricalP.toFixed(3)} · effect = {report.advancedResearch.nullTests.recentBaseline.effectSize.toFixed(2)}</div></div>
        <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-3"><div className="text-white text-xs font-bold mb-1">Conformal calibration</div><div className="text-zinc-500 text-[10px]">coverage {(report.advancedResearch.conformal.coverage*100).toFixed(1)}% · target {(report.advancedResearch.conformal.targetCoverage*100).toFixed(1)}%</div></div>
        <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-3"><div className="text-white text-xs font-bold mb-1">Meta evidence</div><div className="text-zinc-500 text-[10px]">{Object.entries(report.advancedResearch.metaWeights).map(([k,v])=>`${k}: ${(v*100).toFixed(0)}%`).join(' · ')}</div></div>
      </div>
      {report.advancedResearch.constitution.blockers.length>0&&<div className="mt-3 rounded-xl border border-amber-900/40 bg-amber-950/10 p-3 text-[10px] text-amber-200/80">{report.advancedResearch.constitution.blockers.map((x,i)=><div key={i}>⚠️ {x}</div>)}</div>}
    </section>

    <section className="rounded-2xl border border-violet-900/50 bg-violet-950/10 p-4"><div className="text-white font-black mb-2">🤖 Ask Research Investigator</div><div className="text-zinc-500 text-xs mb-3">এটি কোনো paid AI/API ব্যবহার করে না। আপনার app-এর local analysis evidence থেকেই উত্তর তৈরি করে।</div><div className="flex gap-2"><input value={question} onChange={e=>setQuestion(e.target.value.slice(0,240))} placeholder="যেমন: কোন formula stable? / দুর্বল জায়গা কী? / drift কোথায়?" className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-violet-600"/><button onClick={()=>setQuestion(question.trim())} className="px-4 rounded-xl bg-violet-700 hover:bg-violet-600 text-white text-sm font-bold">বিশ্লেষণ</button></div>{answer&&<div className="mt-3 rounded-xl border border-violet-900/50 bg-black/30 p-4 text-sm text-zinc-300 whitespace-pre-line leading-6">{answer}</div>}</section>

    <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-3 text-[11px] text-zinc-500">⚠️ Investigator historical evidence পরীক্ষা করে। এটি ভবিষ্যৎ ৪-ডিজিট ফলের নিশ্চয়তা, guarantee বা certainty score তৈরি করে না। OOS/device validation ছাড়া কোনো গবেষণা ফলকে final claim হিসেবে দেখানো হবে না।</div>
  </div>;
}
