# 4D HOSPITAL — Release Status — 2026-10-05

## Source repairs completed
- Vite entry path corrected to the canonical root `main.tsx`.
- Canonical root source tree (`App.tsx`, `lib/`, `components/`, `hooks/`, `pages/`, `types/`) is documented and used.
- Admin API compatibility layer now requires an authenticated in-memory local admin session; `sessionStorage` is not trusted as authorization.
- Invite TTL `0` now correctly means never-expire.
- OCR is explicitly online-only and requires internet access; offline data entry remains available.
- Source checksum manifest regenerated.
- Local-auth regression audit added to the validation pipeline.

## Verified in this environment
- Static audit: PASS.
- Runtime contract audit: PASS.
- Research Cycle E2E: PASS.
- Master inventory audit: PASS.
- Research layers audit: PASS.
- Stability hardening audit: PASS.
- Mathematical research audit: PASS.
- Advanced research audit: PASS.
- Investigator audit: PASS.
- Scientific Core v3 audit: PASS.
- Storage/security audit: PASS.
- Local auth/release hardening audit: PASS.
- Exact dependency-version audit: PASS.

## Environment-limited gates
This repair sandbox cannot resolve `registry.npmjs.org`, so dependencies could not be installed. Therefore these remain unclaimed until a networked CI runner executes them:

- Full TypeScript typecheck.
- Vite production build.
- Capacitor Android/Gradle APK build.
- Android emulator/device E2E.
- Genuine npm lockfile generation on a networked GitHub runner (the canonical workflow performs this automatically when the ZIP does not contain one); repository persistence is attempted but is not allowed to block the current build.

## Security scope
This remains an offline/local application. The local admin session hardening is not a substitute for server-side authentication. A remotely shared or multi-device deployment requires a trusted backend authorization boundary.
