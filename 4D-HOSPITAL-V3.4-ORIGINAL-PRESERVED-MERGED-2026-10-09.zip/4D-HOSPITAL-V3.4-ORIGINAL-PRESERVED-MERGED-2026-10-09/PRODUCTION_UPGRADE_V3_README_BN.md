# 4D HOSPITAL Production Upgrade v3

## কোথা থেকে শুরু করবেন

1. Project খুলুন
2. canonical GitHub workflow genuine `package-lock.json` তৈরি/হ্যান্ড-অফ করবে; lockfile তৈরি হওয়ার পর `npm ci` ব্যবহার হবে
3. `npm run production:verify` চালান
4. `npm run dev` দিয়ে UI চালু করুন
5. Sidebar → **🧬 Scientific Core v3**

## মূল ধারণা

এই version-এর লক্ষ্য বেশি formula যোগ করা নয়। লক্ষ্য হলো formula/pattern-কে challenge, validation, reproducibility এবং failure analysis-এর মধ্যে রাখা।

### Research flow

Discovery → Null → OOS → Stability → Redundancy → Adversarial Challenge → Evidence Arbitration → Research Memory

### Release principle

**Pattern found ≠ evidence proven.**

একটি hypothesis promotion-এর আগে chronological validation, uncertainty, redundancy এবং adversarial checks দেখতে হবে।
