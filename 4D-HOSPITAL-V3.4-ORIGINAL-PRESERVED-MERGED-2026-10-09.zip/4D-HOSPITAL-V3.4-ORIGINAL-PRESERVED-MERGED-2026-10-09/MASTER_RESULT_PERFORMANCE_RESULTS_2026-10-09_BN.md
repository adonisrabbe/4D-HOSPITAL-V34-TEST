# 4D HOSPITAL — Full Master Result Performance Results

Environment: isolated Node 22 process, transpiled source graph; this is a source-engine benchmark, not an Android-device certification.

| Dataset | Full Master Result | 5D | 4D | 3D | 2D | 1D | 10-set |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1,000 | ~11.4 s | 5 | 4 | 4 | 4 | 4 | 10 |
| 5,000 | ~17.3 s | 5 | 4 | 4 | 4 | 4 | 10 |
| 10,000 | ~33.0 s | 5 | 4 | 4 | 4 | 4 | 10 |

The benchmark was run with each target in an isolated process to avoid cumulative memory/GC effects. The 10,000-row run used about 334 MB RSS in the Node process.

Release gate budgets are intentionally conservative: 1,000 <= 60 s, 5,000 <= 120 s, 10,000 <= 180 s.

These results certify the Master Result engine path in the test environment only. They do not certify an arbitrary Android handset's RAM/thermal performance. The GitHub workflow now runs the same 1k/5k/10k gate on a clean runner.
