# 4D HOSPITAL — A-to-Z Handoff Status — 2026-10-05

## Canonical project
- Runtime source: root `App.tsx` + `lib/` + `components/` + `hooks/` + `pages/` + `types/`.
- No duplicate `src/` runtime tree is present.
- `main.tsx` is the Vite entry point.
- Source checksum manifest has been regenerated from the current canonical files.

## Security/behavior repairs
- Admin API endpoints are guarded by an in-memory local authenticated session.
- A manually edited `sessionStorage` admin marker is not sufficient to activate Admin API access.
- Invite TTL `0` is implemented as non-expiring.
- OCR UI explicitly reports that OCR is online-only and requires internet access.

## Verified in this environment
- Static/runtime contract: PASS.
- Research Cycle E2E: PASS.
- Inventory/research-layer/stability audits: PASS.
- Mathematical/advanced/investigator/scientific/storage audits: PASS.
- Local-auth/release hardening audit: PASS.

## Environment-limited gates
The sandbox cannot access the npm registry and does not have the full Android build toolchain. Therefore dependency installation, final TypeScript/Vite build, APK build, and device E2E remain CI certification steps.

## Data/research rule
Existing and imported data are merged additively. Invalid rows are rejected. Research-cycle actual results are validated separately to prevent future-data leakage. Outputs remain historical/statistical evidence, not guaranteed future outcomes.
