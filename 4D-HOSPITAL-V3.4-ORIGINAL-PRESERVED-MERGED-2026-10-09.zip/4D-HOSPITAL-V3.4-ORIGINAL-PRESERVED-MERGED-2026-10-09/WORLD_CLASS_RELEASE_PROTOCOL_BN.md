# 4D HOSPITAL — World-Class Release Protocol (A→Z)

## উদ্দেশ্য

4D HOSPITAL-কে “107টি analysis আছে” এমন একটি app হিসেবে নয়, বরং **reproducible historical numerical research platform** হিসেবে পরিচালনা করা।

## A→Z release pillars

### A — Analysis integrity
- 107 public analysis-এর একক contract/registry
- dependency graph ও cycle check
- mathematical known-answer verification

### B — Benchmark
- deterministic known-answer fixture
- IID null fixture
- deterministic signal fixture
- drift fixture
- adversarial duplicate fixture
- dataset SHA-256 fingerprint

### C — Chronology
- historical ordering বাধ্যতামূলক
- train → validation → test/OOS temporal separation
- signal freeze governance

### D — Data integrity
- schema/range/missing/duplicate validation
- additive merge policy
- source/company/draw-type stratification যেখানে প্রযোজ্য

### E — Evidence
- effect size + uncertainty
- explicit null model
- multiple-testing correction
- redundancy control
- stability/OOS evidence

### F — FDR
- inferential hypothesis family-তে global false-discovery control
- dashboard score ≠ statistical probability

### G — Governance
- discovery → freeze → blind OOS
- frozen signal manifest
- reproducibility fingerprint

### H — Hardening
- React error boundary
- worker termination/stale-job guards
- storage transaction/rollback safeguards
- encrypted backup/local database configuration

### I — Investigator
- conflict, drift, rarity, redundancy, uncertainty
- evidence is ranked, not guaranteed

### J — Job/CI
- Node 22 + JDK 21
- canonical release run must have a genuine `package-lock.json` in the workspace; the workflow bootstraps it automatically when missing, then hands the exact artifact to validation/build jobs
- deterministic `npm ci`

### K — Knowledge transparency
- every scientific claim has an explicit boundary
- no “100%”, “certain”, “guaranteed future number” API

### L — Local-first
- runtime UI font bundled locally
- no Google Fonts dependency
- offline-first app shell

### M — Mathematical correctness
- 64 known mathematical cases currently pass in the regression harness
- special definitions are documented rather than silently generalized

### N — Null laboratory
- permutation/randomization methods use a null that actually changes the tested statistic
- invariant-mean shuffle misuse is regression-tested out

### O — OOS
- chronological blocked/walk-forward evaluation
- blind OOS governance
- no test-set model selection

### P — Performance
- heavy analysis runs through Web Worker
- timeout/stale-job protection
- future release gate should include measured 1k/10k/100k/500k/1M-row stress runs

### Q — Quality gates
- static audit
- scientific-gap regression
- research-cycle E2E
- benchmark audit
- production-integrity audit
- TypeScript/build/Android gates in GitHub

### R — Reproducibility
- exact dependency lock
- source inventory
- dataset/benchmark hashes
- protocol version

### S — Security
- CSP
- CodeQL workflow
- Dependabot
- security policy
- no secrets/signing keys in repository

### T — Testing
- mathematical tests
- 107-engine contract tests
- research-cycle E2E
- benchmark fixtures
- Android emulator smoke test in CI

### U — Uncertainty
- Wilson/bootstrap/conformal diagnostics are reported with their assumptions
- uncertainty is never converted into certainty language

### V — Versioning
- research protocol versions
- analysis registry version
- benchmark protocol version
- reproducibility fingerprint

### W — Web/Android parity
- same `dist` application is packaged through Capacitor
- Android build generates from the same locked dependency tree

### X — eXternal validation

A future “world-class” scientific claim must be supported by datasets outside the development fixtures and, ideally, by an independent evaluator.

### Y — Your release rule

A release may be called **production-ready** only when all applicable automated gates pass and the remaining manual gates are explicitly signed off.

### Z — Zero overclaim

The software can prove that its calculations, controls, and validation protocol behaved correctly. It cannot manufacture proof that a random future 4-digit outcome is predictable.

## Current certification boundary

Automated source-level and research-layer audits are strong. Full TypeScript/Vite/Android compilation and emulator execution must be performed in a networked GitHub Actions environment because the repair sandbox does not contain the npm registry cache or Android SDK/device stack.

The current source bundle includes a committed `package-lock.json` v3. The canonical release workflow verifies and hands off that exact lockfile to validation, performance, and Android jobs before `npm ci`. It does not generate or commit a missing lockfile. If a future copy lacks the lockfile, use the separate manual Bootstrap package-lock.json workflow, commit the result, and then run the canonical release workflow.
