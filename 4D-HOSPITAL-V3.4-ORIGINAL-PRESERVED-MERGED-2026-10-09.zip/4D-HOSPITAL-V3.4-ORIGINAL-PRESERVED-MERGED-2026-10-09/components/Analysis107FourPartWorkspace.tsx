import { useMemo, useState, type CSSProperties } from "react";
import { ANALYSIS_CATALOG, type AnalysisOption } from "../lib/analysis-catalog";
import { run107Analysis, type Analysis107Result } from "../lib/analysis-engine-107";

type Row = { id:number; company:string; date:string; drawNo:string|null; first:string; second:string; third:string; special:string[]; consolation:string[] };
type Step = "what" | "why" | "next" | "final";

type PartDef = { id:number; title:string; short:string; range:string; ids:number[]; accent:string; desc:string };

// Canonical public 107-analysis partition. These boundaries are locked by the
// product specification and must not be inferred from catalog divisions.
const PARTS:PartDef[] = [
  {id:1,title:"Data & Arithmetic",short:"DATA",range:"01–18",ids:Array.from({length:18},(_,i)=>i+1),accent:"#22d3ee",desc:"Data quality, arithmetic change, number theory and basic numerical structure."},
  {id:2,title:"Digit Analysis",short:"DIGIT",range:"19–25",ids:Array.from({length:7},(_,i)=>i+19),accent:"#34d399",desc:"Digit frequency, position behavior, sum/product, repetition, diversity and reverse structure."},
  {id:3,title:"Pattern & Sequence",short:"PATTERN",range:"26–37",ids:Array.from({length:12},(_,i)=>i+26),accent:"#a78bfa",desc:"Recurrence, lag, repetition, motifs, polynomial fits, residuals and complexity penalty."},
  {id:4,title:"Modular & Combinatorial",short:"MODULAR",range:"38–51",ids:Array.from({length:14},(_,i)=>i+38),accent:"#f59e0b",desc:"Residues, pairs, triplets, permutations, combinations, position matrices and classes."},
  {id:5,title:"Statistics & Dependency",short:"STATISTICS",range:"52–70",ids:Array.from({length:19},(_,i)=>i+52),accent:"#06b6d4",desc:"Descriptive statistics, intervals, dependency, transitions, rolling behavior and change points."},
  {id:6,title:"Spectral / Frequency",short:"SPECTRAL",range:"71–75",ids:Array.from({length:5},(_,i)=>i+71),accent:"#d946ef",desc:"FFT/DFT, dominant frequency, spectral entropy, periodogram and periodicity."},
  {id:7,title:"Information / Randomness",short:"INFORMATION",range:"76–88",ids:Array.from({length:13},(_,i)=>i+76),accent:"#22c55e",desc:"Entropy, information gain and statistical randomness/null-model diagnostics."},
  {id:8,title:"Complexity",short:"COMPLEXITY",range:"89–94",ids:Array.from({length:6},(_,i)=>i+89),accent:"#eab308",desc:"Lempel-Ziv, linear complexity, compression, pattern complexity and state encoding."},
  {id:9,title:"Dynamical / Regime",short:"DYNAMICAL",range:"95–98",ids:Array.from({length:4},(_,i)=>i+95),accent:"#14b8a6",desc:"Recurrence, attractor-style clustering, transition stability and regime detection."},
  {id:10,title:"Research / Discovery",short:"DISCOVERY",range:"99–103",ids:Array.from({length:5},(_,i)=>i+99),accent:"#8b5cf6",desc:"Symbolic regression, rule mining, association, interactions and formula ranking."},
  {id:11,title:"Prediction / Signal",short:"PREDICTION",range:"104–107",ids:Array.from({length:4},(_,i)=>i+104),accent:"#f43f5e",desc:"Baseline, AR/ARIMA-style, tree/ensemble and recurrent research signals."},
];

const STEP_META:Record<Step,{label:string;short:string;question:string}> = {
  what:{label:"মূল বিশ্লেষণ",short:"WHAT",question:"What is happening?"},
  why:{label:"কেন পরিবর্তন হলো",short:"WHY",question:"Why did it change?"},
  next:{label:"পরবর্তীতে কীভাবে পরিবর্তন হতে পারে",short:"NEXT",question:"How may it change next?"},
  final:{label:"চূড়ান্ত বিশ্লেষণ ফলাফল",short:"FINAL",question:"What is the final evidence state?"},
};

function safeJson(value:unknown){try{return JSON.stringify(value,null,2)}catch{return String(value)}}
function nums(row:Row[]){return row.flatMap(r=>[r.first,r.second,r.third,...r.special,...r.consolation]).filter(x=>/^\d{4}$/.test(x))}
function summarizeRaw(raw:unknown):Array<[string,string]> {
  if(raw==null) return [["Result","No result returned"]];
  if(typeof raw !== "object") return [["Value",String(raw)]];
  const o=raw as Record<string,unknown>;
  const entries=Object.entries(o).slice(0,12).map(([k,v])=>{let s=typeof v==='string'?v:safeJson(v);if(s.length>180)s=s.slice(0,177)+"…";return [k,s] as [string,string]});
  return entries.length?entries:[["Result","{}"]];
}

function numericSeriesFromRaw(raw:unknown):{label:string;values:number[]}[]{
  const out:{label:string;values:number[]}[]=[];
  const walk=(v:unknown,label:string)=>{
    if(Array.isArray(v)){
      if(v.length>2 && v.every(x=>typeof x==='number' && Number.isFinite(x))) out.push({label,values:v as number[]});
      else if(v.length>2 && v.every(x=>x && typeof x==='object' && !Array.isArray(x))){
        const keys=[...new Set(v.flatMap(x=>Object.keys(x as Record<string,unknown>)))];
        for(const k of keys){const a=v.map(x=>(x as Record<string,unknown>)[k]).filter((x):x is number=>typeof x==='number'&&Number.isFinite(x));if(a.length===v.length)out.push({label:`${label}.${k}`,values:a});}
      }
      return;
    }
    if(v && typeof v==='object') for(const [k,x] of Object.entries(v as Record<string,unknown>)) walk(x,label?`${label}.${k}`:k);
  };
  walk(raw,'result');
  return out.filter(x=>x.values.length>2).slice(0,8);
}
function distributionFromRaw(raw:unknown):{label:string;entries:[string,number][]}[]{
  const out:{label:string;entries:[string,number][]}[]=[];
  const walk=(v:unknown,label:string)=>{
    if(v && typeof v==='object' && !Array.isArray(v)){
      const entries=Object.entries(v as Record<string,unknown>).filter(([,x])=>typeof x==='number'&&Number.isFinite(x)).map(([k,x])=>[k,x as number] as [string,number]);
      if(entries.length>=2) out.push({label,entries:entries.sort((a,b)=>b[1]-a[1]).slice(0,10)});
      for(const [k,x] of Object.entries(v as Record<string,unknown>)) walk(x,label?`${label}.${k}`:k);
    } else if(Array.isArray(v)) v.slice(0,8).forEach((x,i)=>walk(x,`${label}[${i}]`));
  };
  walk(raw,'result');
  return out.slice(0,8);
}
function ActualResultVisual({raw,accent,mode,label}:{raw:unknown;accent:string;mode:'what'|'why'|'next'|'final';label:string}){
  const series=numericSeriesFromRaw(raw);
  const distributions=distributionFromRaw(raw);
  const primary:number[]=mode==='why'?(distributions[0]?.entries.map(([,value])=>value)??[]):(series[0]?.values??[]);
  const vals:number[]=primary.length?primary:(distributions[0]?.entries.map(([,value])=>value)??[]);
  const finite=vals.filter(Number.isFinite), min=finite.length?Math.min(...finite):0,max=finite.length?Math.max(...finite):1,span=max-min||1;
  const points=finite.slice(-40).map((v,i)=>`${(i/Math.max(1,finite.slice(-40).length-1))*100},${92-((v-min)/span)*78}`).join(' ');
  const bars=finite.slice(-16);
  return <div className="a107-result-visual" style={{'--result-accent':accent} as CSSProperties}>
    <div className="a107-result-visual-head"><b>{label}</b><span>LIVE FROM ANALYSIS RESULT</span></div>
    <div className="a107-result-visual-body">
      <div className="a107-result-chart">
        {mode==='why' && distributions[0] ? <div className="a107-result-bars">{bars.map((v,i)=><i key={i} style={{height:`${Math.max(8,((v-min)/span)*100)}%`}} title={distributions[0].entries[i]?.[0]??String(i)}/>)}</div> : <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="analysis result trend"><polyline points={points||'0,92 100,92'} fill="none" stroke="var(--result-accent)" strokeWidth="3" vectorEffect="non-scaling-stroke"/></svg>}
      </div>
      <div className="a107-result-metrics"><div><small>OBSERVATIONS</small><b>{finite.length.toLocaleString()}</b></div><div><small>MIN</small><b>{Number.isFinite(min)?min.toFixed(3):'—'}</b></div><div><small>MAX</small><b>{Number.isFinite(max)?max.toFixed(3):'—'}</b></div><div><small>SERIES</small><b>{series[0]?.label?.replace(/^result\.?/,'')||distributions[0]?.label?.replace(/^result\.?/,'')||'summary'}</b></div></div>
    </div>
    <small className="a107-result-note">এই visual একই analysis result থেকে তৈরি; decorative placeholder নয়। WHY অংশে এটি কারণের প্রমাণ/সহযোগী evidence দেখায়, নিশ্চিত causal proof নয়।</small>
  </div>;
}

function MiniVisual({step,accent,index,summary}:{step:Step;accent:string;index:number;summary:{samples:number[];support:number;conflict:number;insufficient:number}}){
  const bars = (summary.samples.length?summary.samples:Array.from({length:9},()=>0)).slice(-9).map(v=>{const max=Math.max(1,...summary.samples);return 18+(v/max)*55;});
  const total=summary.support+summary.conflict+summary.insufficient; const supportRate=total?Math.round(summary.support/total*100):0;
  if(step==="what") return <div className="a107-mini-chart" aria-hidden="true"><div className="a107-line"><i style={{left:"2%",top:`${60-index%3*8}%`}}/><i style={{left:"18%",top:"30%"}}/><i style={{left:"35%",top:`${62-index%4*7}%`}}/><i style={{left:"54%",top:"25%"}}/><i style={{left:"73%",top:`${48-index%5*6}%`}}/><i style={{left:"94%",top:"18%"}}/></div><div className="a107-bars">{bars.map((h,i)=><b key={i} style={{height:`${h}%`,background:accent}}/> )}</div></div>;
  if(step==="why") return <div className="a107-mini-matrix" aria-hidden="true">{Array.from({length:48},(_,i)=><i key={i} style={{opacity:.25+((i*7+index)%7)/10,background:accent}}/> )}</div>;
  if(step==="next") return <div className="a107-mini-trend" aria-hidden="true"><svg viewBox="0 0 260 100" preserveAspectRatio="none"><path d="M0 76 C35 52 45 84 72 55 S108 28 135 48 S172 78 198 40 S226 32 260 18" fill="none" stroke={accent} strokeWidth="4"/><path d="M0 88 C35 72 50 90 76 66 S112 44 138 58 S176 85 204 55 S235 48 260 34" fill="none" stroke="#64748b" strokeWidth="2" opacity=".55"/></svg></div>;
  return <div className="a107-mini-final" aria-hidden="true"><div className="a107-ring" style={{borderTopColor:accent,borderRightColor:accent,transform:`rotate(${supportRate*3.6}deg)`}}><strong style={{transform:`rotate(-${supportRate*3.6}deg)`}}>{supportRate}%</strong></div><div className="a107-checks"><span style={{borderColor:accent}}>LIVE EVIDENCE</span><span>{summary.support} SUPPORT</span><span>{summary.conflict} CONFLICT · {summary.insufficient} LOW</span></div></div>;
}

function MiniPage({step,part,index,onClick,summary}:{step:Step;part:PartDef;index:number;onClick:()=>void;summary:{samples:number[];support:number;conflict:number;insufficient:number}}){
  return <button className="a107-mini-page" style={{"--mini-accent":part.accent} as CSSProperties} onClick={onClick}>
    <div className="a107-mini-head"><b>PAGE {index+1}</b><span>{STEP_META[step].short}</span></div>
    <MiniVisual step={step} accent={part.accent} index={part.id} summary={summary}/>
    <div className="a107-mini-foot"><strong>{STEP_META[step].label}</strong><small>{STEP_META[step].question}</small></div>
  </button>
}

function StepView({step,item,result,rows}:{step:Step;item:AnalysisOption;result?:Analysis107Result;rows:Row[]}){
  const valid=rows.filter(r=>/^\d{4}$/.test(r.first)).length;
  const sample=result?.sampleSize??valid;
  const evidence=result?.evidence??"INSUFFICIENT_DATA";
  const raw=result?.raw;
  if(step==="what") return <>
    <div className="a107-kpi-grid"><div><small>ANALYSIS</small><b>#{item.id}</b></div><div><small>VALID ROWS</small><b>{valid.toLocaleString()}</b></div><div><small>SAMPLE USED</small><b>{sample.toLocaleString()}</b></div><div><small>STATUS</small><b>{result?.applicable?item.implementationStatusLabel:"INSUFFICIENT"}</b></div></div>
    <ActualResultVisual raw={raw} accent="#22d3ee" mode="what" label={`Analysis #${item.id} · ${item.name}`}/><div className="a107-table-wrap"><table><thead><tr><th>Field</th><th>Actual value / definition</th></tr></thead><tbody>
      <tr><td>Name</td><td>{item.name}</td></tr><tr><td>Division</td><td>{item.division}</td></tr><tr><td>Definition</td><td>{item.definition}</td></tr><tr><td>Input</td><td>{item.input}</td></tr><tr><td>Output</td><td>{item.output}</td></tr><tr><td>Evidence</td><td>{evidence}</td></tr>
      {summarizeRaw(raw).map(([k,v])=><tr key={k}><td>{k}</td><td className="a107-mono">{v}</td></tr>)}
    </tbody></table></div>
  </>;
  if(step==="why") return <><ActualResultVisual raw={raw} accent="#a78bfa" mode="why" label={`WHY evidence · Analysis #${item.id}`}/><div className="a107-explain-grid"><div><h3>কেন পরিবর্তন / pattern দেখা গেল?</h3><p>{item.purpose}</p><p><b>Data requirement:</b> {item.dataRequirement}</p><p><b>Dependency:</b> {item.dependencyType}{item.dependencyIds.length?` · IDs ${item.dependencyIds.join(", ")}`:""}</p></div><div><h3>Evidence & validation</h3><p><b>Current evidence:</b> {evidence}</p><p>{item.validation}</p><p className="a107-note">Historical data ব্যাখ্যা করা হচ্ছে; এটিকে নিশ্চিত ভবিষ্যৎ ফলাফল হিসেবে দেখানো হয় না।</p></div></div></>;
  if(step==="next") return <><ActualResultVisual raw={raw} accent="#22d3ee" mode="next" label={`NEXT trend · Analysis #${item.id}`}/><div className="a107-explain-grid"><div><h3>পরবর্তী পরিবর্তন কীভাবে পর্যবেক্ষণ হবে</h3><p>নতুন valid draw যোগ হলে একই calculation আবার চালানো হবে এবং আগের window-এর সঙ্গে তুলনা করা হবে।</p><ul><li>নতুন sample size</li><li>নতুন distribution / trend</li><li>window-to-window stability</li><li>evidence status পরিবর্তন</li></ul></div><div><h3>সতর্কতা</h3><p>{item.target}</p><p>OOS বা validation প্রয়োজন হলে engine-এর declared validation gate ব্যবহার করা হবে। পর্যাপ্ত data না থাকলে <b>INSUFFICIENT_DATA</b> থাকবে।</p></div></div></>;
  return <><ActualResultVisual raw={raw} accent="#34d399" mode="final" label={`FINAL evidence · Analysis #${item.id}`}/><div className="a107-final"><div className="a107-final-banner"><span>FINAL RESULT</span><strong>{evidence}</strong><small>{result?.note||"Current historical calculation completed."}</small></div><div className="a107-table-wrap"><table><thead><tr><th>Final field</th><th>Value</th></tr></thead><tbody><tr><td>Implementation</td><td>{item.implementationStatusLabel}</td></tr><tr><td>Validation</td><td>{item.validation}</td></tr><tr><td>Target</td><td>{item.target}</td></tr><tr><td>Redundancy group</td><td>{item.redundancyGroup}</td></tr><tr><td>Calculation version</td><td>{result?.calculationVersion??"107-core-v1"}</td></tr><tr><td>Raw result</td><td><pre>{safeJson(raw)}</pre></td></tr></tbody></table></div></div></>;
}

function AnalysisList({part,selectedId,setSelectedId,step,setStep,catalog,byId,rows}:{part:PartDef;selectedId:number|null;setSelectedId:(n:number|null)=>void;step:Step;setStep:(s:Step)=>void;catalog:AnalysisOption[];byId:Map<number,Analysis107Result>;rows:Row[]}){
  const selected=selectedId?catalog.find(x=>x.id===selectedId):undefined;
  const result=selectedId?byId.get(selectedId):undefined;
  if(selected) return <section className="a107-detail" style={{"--detail-accent":part.accent} as CSSProperties}>
    <div className="a107-detail-head"><button onClick={()=>setSelectedId(null)}>← BACK TO {part.title}</button><div><span>ANALYSIS #{String(selected.id).padStart(3,"0")}</span><h2>{selected.name}</h2><p>{selected.division} · {selected.family}</p></div><strong>{result?.evidence??"INSUFFICIENT_DATA"}</strong></div>
    <nav className="a107-step-tabs">{(Object.keys(STEP_META) as Step[]).map(s=><button key={s} className={step===s?"active":""} onClick={()=>setStep(s)}><b>{STEP_META[s].short}</b><span>{STEP_META[s].label}</span></button>)}</nav>
    <div className="a107-step-content"><StepView step={step} item={selected} result={result} rows={rows}/></div>
  </section>;
  return <div className="a107-analysis-list">{part.ids.map(id=>{const x=catalog[id-1],r=byId.get(id);return <button className="a107-row" key={id} onClick={()=>{setSelectedId(id);setStep("what")}}><b>#{String(id).padStart(3,"0")}</b><div><strong>{x.name}</strong><small>{x.family} · {x.purpose}</small></div><em className={String(r?.evidence??"INSUFFICIENT_DATA").toLowerCase()}>{r?.evidence??"INSUFFICIENT_DATA"}</em><span>{x.output}</span><i>DETAILS →</i></button>})}</div>;
}

export function Analysis107FourPartWorkspace({results}:{results:Row[]}){
  const [part,setPart]=useState<number|null>(null);
  const [selectedId,setSelectedId]=useState<number|null>(null);
  const [step,setStep]=useState<Step>("what");
  const catalog=ANALYSIS_CATALOG.slice(0,107);
  const engine=useMemo(()=>run107Analysis(results.map((r,i)=>({id:r.id??i+1,company:r.company,date:r.date,drawNo:r.drawNo??String(i+1),first:r.first,second:r.second,third:r.third,special:r.special,consolation:r.consolation}))),[results]);
  const byId=useMemo(()=>new Map(engine.map(x=>[x.id,x])),[engine]);
  const partSummaries=useMemo(()=>new Map(PARTS.map(p=>{const rs=p.ids.map(id=>byId.get(id)).filter((x):x is Analysis107Result=>!!x);return [p.id,{samples:rs.map(x=>x.sampleSize),support:rs.filter(x=>x.evidence==='SUPPORT').length,conflict:rs.filter(x=>x.evidence==='CONFLICT').length,insufficient:rs.filter(x=>x.evidence==='INSUFFICIENT_DATA'||!x.applicable).length}]})),[byId]);
  const valid=results.filter(r=>/^\d{4}$/.test(r.first)).length;
  const values=nums(results).length;
  const selectedPart=part?PARTS[part-1]:null;

  const openPart=(id:number, initialStep:Step="what")=>{setPart(id);setSelectedId(null);setStep(initialStep);window.scrollTo({top:0,behavior:"smooth"})};

  return <div className={`a107-page ${selectedPart ? (selectedId ? `a107-detail-surface a107-step-${step}` : "a107-part-surface") : "a107-overview-surface"}`}>
    <header className="a107-hero">
      <div className="a107-hero-brand"><div className="a107-logo">4D</div><div><div className="a107-brand">4D <span>HOSPITAL</span></div><div className="a107-kicker">HISTORICAL 4-DIGIT NUMERICAL RESEARCH & ANALYSIS LABORATORY</div></div></div>
      <div className="a107-hero-title"><b>107 ANALYSIS SYSTEM</b><span>11 PARTS × 4 PAGES = 44 ANALYSIS WORKFLOWS</span><small>Data → Analysis → Insight → Evidence</small></div>
      <div className="a107-hero-metrics"><div><b>107</b><span>ANALYSES</span></div><div><b>11</b><span>PARTS</span></div><div><b>4</b><span>PAGES</span></div><div><b>{valid}</b><span>VALID ROWS</span></div></div>
    </header>

    {!selectedPart ? <>
      <div className="a107-status-strip"><span>● LIVE RESEARCH SURFACE</span><span>DATA {results.length.toLocaleString()}</span><span>107/107 REGISTERED</span><span>11/11 PARTS</span><span>4/4 WORKFLOW PAGES</span><span>NO GUARANTEE · EVIDENCE ONLY</span></div>
      <main className="a107-part-grid">
        {PARTS.map((p)=> <article className="a107-part-card" key={p.id} style={{"--part-accent":p.accent} as CSSProperties}>
          <div className="a107-part-head"><div className="a107-part-number">{String(p.id).padStart(2,"0")}</div><div><span>PART {String(p.id).padStart(2,"0")} · ANALYSIS {p.range}</span><h2>{p.title}</h2><p>{p.desc}</p></div><button onClick={()=>openPart(p.id)}>OPEN PART →</button></div>
          <div className="a107-mini-grid">{(Object.keys(STEP_META) as Step[]).map((s,i)=><MiniPage key={s} step={s} part={p} index={i} summary={partSummaries.get(p.id)??{samples:[],support:0,conflict:0,insufficient:0}} onClick={()=>openPart(p.id,s)}/>)}</div>
          <div className="a107-part-foot"><span>{p.ids.length} analyses</span><span>4 workflow pages</span><b>{p.range}</b></div>
        </article>)}
      </main>
      <footer className="a107-overview-footer"><strong>107 TOTAL ANALYSES</strong><span>11 PARTS</span><span>44 ANALYSIS WORKFLOWS</span><span>428 PAGE INSTANCES</span><span>STRUCTURED · TRACEABLE · EVIDENCE-AWARE</span></footer>
    </> : <>
      <div className="a107-breadcrumb"><button onClick={()=>{setPart(null);setSelectedId(null)}}>← ALL PARTS</button><span>/</span><b>PART {String(selectedPart.id).padStart(2,"0")}</b><span>/</span><span>{selectedPart.range}</span></div>
      <section className="a107-part-intro" style={{"--part-accent":selectedPart.accent} as CSSProperties}><div><span>ACTIVE PART · {selectedPart.range}</span><h2>{selectedPart.title}</h2><p>{selectedPart.desc}</p></div><div className="a107-count">{selectedPart.ids.length}<small>ANALYSES</small></div></section>
      <nav className="a107-detail-workflow">{(Object.keys(STEP_META) as Step[]).map((s,i)=><button key={s} className={step===s?"active":""} onClick={()=>{setStep(s);setSelectedId(null)}}><b>PAGE {i+1}</b><strong>{STEP_META[s].label}</strong><small>{STEP_META[s].question}</small></button>)}</nav>
      <AnalysisList part={selectedPart} selectedId={selectedId} setSelectedId={setSelectedId} step={step} setStep={setStep} catalog={catalog} byId={byId} rows={results}/>
    </>}
  </div>;
}
