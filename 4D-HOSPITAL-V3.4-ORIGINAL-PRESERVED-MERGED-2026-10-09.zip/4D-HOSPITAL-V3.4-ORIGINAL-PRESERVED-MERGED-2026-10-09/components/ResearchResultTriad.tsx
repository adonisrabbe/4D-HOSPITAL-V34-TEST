import { useEffect, useMemo, useState, type ReactNode } from "react";
import { run107Analysis, type Analysis107Result } from "../lib/analysis-engine-107";
import { ANALYSIS_CATALOG } from "../lib/analysis-catalog";
import { buildFinalResultReport, type FinalCandidate, type FinalKind } from "../lib/final-result-engine";
import type { CanonicalDraw } from "../lib/canonical-data";
import { buildMasterResultSheet, type MasterLevel, type MasterResearchBundle } from "../lib/master-result-sheet";

type ResultRow = {
  id:number; company:string; date:string; drawNo:string|null;
  first:string; second:string; third:string; special:string[]; consolation:string[];
};

type Props = { results: ResultRow[]; onView?: (v:any)=>void };

const familyOf=(id:number)=>ANALYSIS_CATALOG[id-1]?.family ?? "General";
const categoryOf=(id:number)=>ANALYSIS_CATALOG[id-1]?.category ?? "validation";

function panel(title:string, subtitle:string, children:ReactNode, accent="rgba(59,130,246,.28)"){
  return <section className="rounded-3xl p-4 md:p-5 bg-white/[.035] border" style={{borderColor:accent,boxShadow:"0 12px 45px rgba(0,0,0,.22)"}}>
    <div className="mb-4"><div className="text-white font-black text-base md:text-lg">{title}</div><div className="text-slate-400 text-xs mt-1">{subtitle}</div></div>{children}
  </section>;
}

function Stat({label,value,sub}:{label:string;value:string|number;sub?:string}){
  return <div className="rounded-2xl p-3 bg-black/25 border border-white/10"><div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div><div className="text-xl md:text-2xl font-black font-mono text-white mt-1">{value}</div>{sub&&<div className="text-[10px] text-slate-500 mt-1">{sub}</div>}</div>
}

function statusLabel(x:Analysis107Result){
  if(x.evidence==='SUPPORT') return {t:"SUPPORT",c:"text-emerald-300 bg-emerald-500/10 border-emerald-500/20"};
  if(x.evidence==='CONFLICT') return {t:"CONFLICT",c:"text-red-300 bg-red-500/10 border-red-500/20"};
  if(x.evidence==='INSUFFICIENT_DATA') return {t:"INSUFFICIENT",c:"text-amber-300 bg-amber-500/10 border-amber-500/20"};
  if(x.evidence==='NOT_APPLICABLE') return {t:"N/A",c:"text-slate-400 bg-white/5 border-white/10"};
  return {t:"NEUTRAL",c:"text-sky-300 bg-sky-500/10 border-sky-500/20"};
}

function scoreEvidence(rows:Analysis107Result[], sample:number){
  const applicable=rows.filter(x=>x.applicable);
  const support=applicable.filter(x=>x.evidence==='SUPPORT').length;
  const neutral=applicable.filter(x=>x.evidence==='NEUTRAL').length;
  const conflict=applicable.filter(x=>x.evidence==='CONFLICT').length;
  const dataFactor=Math.min(1,sample/200);
  const agreement=applicable.length ? (support + .5*neutral)/(applicable.length) : 0;
  const penalty=conflict/Math.max(1,applicable.length)*.35;
  return Math.max(0,Math.min(99.9,100*(.35*dataFactor+.65*Math.max(0,agreement-penalty))));
}

function digitFrequency(results:ResultRow[]){
  const c=Array(10).fill(0); let n=0;
  for(const r of results){ for(const num of [r.first,r.second,r.third]) for(const ch of num){c[Number(ch)]++;n++;} }
  return c.map((count,digit)=>({digit,count,share:n?count/n:0})).sort((a,b)=>b.count-a.count);
}

function candidateScore(num:string, freq:{digit:number;count:number;share:number}[], rows:Analysis107Result[]){
  const map=new Map(freq.map(x=>[x.digit,x.share]));
  const base=num.split("").reduce((s,d)=>s+(map.get(Number(d))??0),0)/4;
  const support=rows.filter(x=>x.evidence==='SUPPORT').length/Math.max(1,rows.length);
  return Math.min(99.9,Math.max(0,(base*70+support*30)*100));
}

export function AllAnalysisResultsPage({results}:Props){
  const [query,setQuery]=useState("");
  const [family,setFamily]=useState("ALL");
  const draws=useMemo(()=>results.map(r=>r as unknown as CanonicalDraw),[results]);
  const analysis=useMemo(()=>run107Analysis(draws),[draws]);
  const families=useMemo(()=>["ALL",...Array.from(new Set(analysis.map(x=>familyOf(x.id))))],[analysis]);
  const filtered=analysis.filter(x=>(family==='ALL'||familyOf(x.id)===family)&&(x.name.toLowerCase().includes(query.toLowerCase())||String(x.id)===query.trim()));
  const support=analysis.filter(x=>x.evidence==='SUPPORT').length;
  const conflicts=analysis.filter(x=>x.evidence==='CONFLICT').length;
  const insufficient=analysis.filter(x=>x.evidence==='INSUFFICIENT_DATA').length;
  const implemented=analysis.filter(x=>x.status===1).length;
  return <div className="max-w-7xl mx-auto p-3 md:p-5 space-y-4">
    {panel("① ALL ANALYSIS RESULTS","107টি canonical analysis-এর live output — একই dataset, একই calculation engine, একই evidence vocabulary.",<>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 mb-4"><Stat label="Analyses" value={analysis.length}/><Stat label="Implemented" value={implemented}/><Stat label="Support" value={support}/><Stat label="Conflict" value={conflicts}/><Stat label="Insufficient" value={insufficient}/></div>
      <div className="flex flex-col md:flex-row gap-2 mb-3"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Analysis ID বা নাম খুঁজুন…" className="flex-1 rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm text-white outline-none"/><select value={family} onChange={e=>setFamily(e.target.value)} className="rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm text-white">{families.map(f=><option key={f} value={f}>{f}</option>)}</select></div>
      <div className="overflow-auto rounded-2xl border border-white/10"><table className="w-full text-xs min-w-[900px]"><thead className="bg-slate-950 sticky top-0"><tr className="text-slate-500"><th className="p-2 text-left">#</th><th className="p-2 text-left">Analysis</th><th className="p-2 text-left">Family</th><th className="p-2 text-left">Category</th><th className="p-2 text-left">Evidence</th><th className="p-2 text-left">State</th><th className="p-2 text-right">n</th><th className="p-2 text-left">Note</th></tr></thead><tbody>{filtered.map(x=>{const s=statusLabel(x);return <tr key={x.id} className="border-t border-white/5"><td className="p-2 text-slate-600">{x.id}</td><td className="p-2 text-white font-semibold">{x.name}</td><td className="p-2 text-purple-300">{familyOf(x.id)}</td><td className="p-2 text-slate-400">{categoryOf(x.id)}</td><td className="p-2"><span className={`inline-flex rounded-full border px-2 py-1 text-[9px] font-black ${s.c}`}>{s.t}</span></td><td className="p-2 text-slate-400">{x.status===1?"IMPLEMENTED":x.status===5?"INSUFFICIENT_DATA":x.status===6?"NOT_APPLICABLE":`STATUS ${x.status}`}</td><td className="p-2 text-right text-slate-500">{x.sampleSize}</td><td className="p-2 text-slate-500 max-w-[280px]">{x.note||"—"}</td></tr>})}</tbody></table></div>
      <div className="mt-3 text-[10px] text-slate-600">Dataset rows: {results.length.toLocaleString()} · 107-core-v1 · ফলাফল descriptive/evidence output; কোনো row future outcome guarantee করে না।</div>
    </>)}
  </div>;
}

export function ResearchIntelligencePage({results}:Props){
  const draws=useMemo(()=>results.map(r=>r as unknown as CanonicalDraw),[results]);
  const analysis=useMemo(()=>run107Analysis(draws),[draws]);
  const score=scoreEvidence(analysis,results.length);
  const families=useMemo(()=>Array.from(new Set(analysis.map(x=>familyOf(x.id)))),[analysis]);
  const familyStats=families.map(f=>{const a=analysis.filter(x=>familyOf(x.id)===f);return{f,n:a.length,s:a.filter(x=>x.evidence==='SUPPORT').length,c:a.filter(x=>x.evidence==='CONFLICT').length}}).sort((a,b)=>b.s-a.s);
  return <div className="max-w-7xl mx-auto p-3 md:p-5 space-y-4">
    {panel("② RESEARCH INTELLIGENCE INFRASTRUCTURE","107টি ফলাফল থেকে evidence-aware research architecture: signal → validation → stability → OOS → decision.",<>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2"><Stat label="Evidence Index" value={`${score.toFixed(1)}%`} sub="descriptive research index"/><Stat label="Dataset" value={results.length.toLocaleString()} sub="records"/><Stat label="Families" value={families.length}/><Stat label="Support" value={analysis.filter(x=>x.evidence==='SUPPORT').length}/><Stat label="Conflict" value={analysis.filter(x=>x.evidence==='CONFLICT').length}/></div>
      <div className="grid lg:grid-cols-5 gap-2 items-stretch mt-4">{["DATA INTEGRITY","107 ANALYSIS","EVIDENCE FILTER","OOS / STABILITY","RESEARCH DECISION"].map((x,i)=><div key={x} className="relative rounded-2xl p-4 bg-black/25 border border-white/10 min-h-[100px]"><div className="text-[10px] text-slate-500">LAYER {i+1}</div><div className="text-white font-black mt-2 text-sm">{x}</div><div className="text-slate-500 text-[10px] mt-2">{["validity · duplicates · chronology","descriptive · structural · statistical · model","support · neutral · conflict · insufficiency","walk-forward · stability · blind split","publish / hold / investigate"][i]}</div>{i<4&&<span className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 text-slate-600 text-lg">→</span>}</div>)}</div>
      <div className="grid lg:grid-cols-2 gap-3 mt-4"><div className="rounded-2xl bg-black/20 border border-white/10 p-4"><div className="text-white font-bold text-sm mb-3">Family Evidence Map</div><div className="space-y-2">{familyStats.slice(0,12).map(x=><div key={x.f}><div className="flex justify-between text-[10px] mb-1"><span className="text-slate-300">{x.f}</span><span className="text-slate-500">S {x.s} · C {x.c} · N {x.n}</span></div><div className="h-2 rounded-full bg-white/5 overflow-hidden"><div className="h-full rounded-full" style={{width:`${x.n?Math.min(100,x.s/x.n*100):0}%`,background:"linear-gradient(90deg,#22c55e,#06b6d4)"}}/></div></div>)}</div></div><div className="rounded-2xl bg-black/20 border border-white/10 p-4"><div className="text-white font-bold text-sm mb-3">Research Governance</div><div className="space-y-2 text-xs text-slate-400">{["No automatic future-certainty claim","Conflicts remain visible","Insufficient data blocks over-interpretation","OOS validation is required before predictive claims","Every result is tied to dataset + calculation version"].map((x,i)=><div key={x} className="flex gap-2"><span className="text-emerald-400">{i<4?"✓":"◆"}</span><span>{x}</span></div>)}</div></div></div>
    </>)}
  </div>;
}

function finalTitle(kind:FinalKind){
  const labels:Record<FinalKind,string>={HOT_4D:'🔥 HOT 4-DIGIT',COOL_4D:'❄️ COOL 4-DIGIT',PAIR:'PAIR',HOT_PAIR:'🔥 HOT PAIR',COOL_PAIR:'❄️ COOL PAIR',SINGLE:'SINGLE DIGIT',HOT_SINGLE:'🔥 HOT SINGLE',COOL_SINGLE:'❄️ COOL SINGLE',HOT_3D:'🔥 HOT 3-DIGIT',COOL_3D:'❄️ COOL 3-DIGIT'};
  return labels[kind];
}
function decisionClass(d:FinalCandidate['decision']){
  if(d==='SUPPORTED')return 'text-emerald-300 bg-emerald-500/10 border-emerald-500/20';
  if(d==='CONFLICTED')return 'text-red-300 bg-red-500/10 border-red-500/20';
  if(d==='INSUFFICIENT_DATA')return 'text-amber-300 bg-amber-500/10 border-amber-500/20';
  return 'text-sky-300 bg-sky-500/10 border-sky-500/20';
}

const BASELINE_KEY='4d-hospital-final-result-baseline-v1';
function matchLevel(value:string, actual:string){
  if(value===actual)return 'EXACT 4D';
  const positions=value.split('').filter((d,i)=>actual[i]===d).length;
  if(value.slice(0,2)===actual.slice(0,2)||value.slice(2)===actual.slice(2))return `${positions} POSITION + PAIR`;
  if(positions>=3)return '3 POSITION';
  if(positions>=2)return '2 POSITION';
  const overlap=[...new Set(value.split(''))].filter(d=>actual.includes(d)).length;
  if(overlap>=2)return '2 DIGIT OVERLAP';
  if(overlap===1)return '1 DIGIT OVERLAP';
  return 'NO DIRECT MATCH';
}
function MissAutopsyPage({results}:{results:ResultRow[]}){
  const [baseline,setBaseline]=useState<any>(null);
  const [message,setMessage]=useState('');
  const current=useMemo(()=>buildFinalResultReport(results.map(r=>r as unknown as CanonicalDraw)),[results]);
  const actual=useMemo(()=>[...results].sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id).at(-1)?.first??null,[results]);
  useEffect(()=>{try{const raw=localStorage.getItem(BASELINE_KEY);if(raw)setBaseline(JSON.parse(raw));}catch{}},[results]);
  const saveCurrent=()=>{try{localStorage.setItem(BASELINE_KEY,JSON.stringify(current));setBaseline(current);setMessage('Baseline result সংরক্ষণ হয়েছে। নতুন data যোগ করার পর এই sheet-এ ফিরে আসুন।');}catch{setMessage('Baseline সংরক্ষণ করা যায়নি।')}};
  const categories:FinalKind[]=['HOT_4D','COOL_4D','PAIR','HOT_PAIR','COOL_PAIR','SINGLE','HOT_SINGLE','COOL_SINGLE','HOT_3D','COOL_3D'];
  const rows=baseline&&actual?categories.flatMap(k=>(baseline.findings?.[k]??[]).map((x:any)=>({kind:k,value:x.value,score:x.score,decision:x.decision,match:matchLevel(x.value,actual)}))):[];
  const exact=rows.filter(x=>x.match==='EXACT 4D').length;
  return <div className="max-w-[1500px] mx-auto p-3 md:p-5 space-y-4">
    {panel('④ RESULT MISS AUTOPSY','এটি Final Result-এর অংশ নয়। আগের সংরক্ষিত result এবং নতুন actual result আলাদা করে পরীক্ষা করে কেন মিলেনি/কোথায় মিলেছিল তা দেখায়।','', 'rgba(251,146,60,.30)')}
    <section className="rounded-[2rem] border border-orange-400/20 bg-gradient-to-br from-orange-500/10 via-red-500/5 to-purple-500/10 p-5 md:p-7">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4"><div><div className="text-[10px] tracking-[.25em] text-orange-300 font-black">POST-RESULT FAILURE INTELLIGENCE</div><h2 className="text-white text-2xl md:text-3xl font-black mt-2">কেন আগের Result মেলেনি?</h2><p className="text-slate-400 text-xs mt-2">আগের result-এর snapshot → নতুন data → নতুন actual result। Final Result-এ কোনো পরিবর্তন করা হয় না।</p></div><button onClick={saveCurrent} className="rounded-xl border border-orange-400/30 bg-orange-500/10 px-4 py-3 text-xs font-black text-orange-200">CURRENT RESULT → SAVE BASELINE</button></div>
      <div className="grid md:grid-cols-4 gap-2 mt-5"><Stat label="BASELINE" value={baseline?'SAVED':'NOT SAVED'}/><Stat label="CURRENT RECORDS" value={current.dataset.validRecords}/><Stat label="ACTUAL LATEST" value={actual??'—'}/><Stat label="EXACT BASELINE HITS" value={exact}/></div>
      {message&&<div className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-500/5 p-3 text-xs text-emerald-200">{message}</div>}
    </section>
    {!baseline?<section className="rounded-3xl border border-white/10 bg-black/20 p-8 text-center"><div className="text-white font-black text-lg">প্রথমে একটি Final Result baseline সংরক্ষণ করুন</div><div className="text-slate-500 text-xs mt-2">Result দেওয়ার পর এখানে baseline save করুন। এরপর নতুন 23/যতগুলো data যোগ করে actual result এলে এই আলাদা sheet-এ ফিরে আসুন।</div></section>:
    <>
      <section className="rounded-3xl border border-white/10 bg-black/20 p-5"><div className="text-white font-black">MISS / MATCH MAP</div><div className="text-slate-500 text-xs mt-1">প্রতিটি পুরোনো candidate actual-এর সঙ্গে কোথায় মিলেছে তা দেখানো হচ্ছে।</div><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mt-4">{rows.map((x,i)=><div key={`${x.kind}-${x.value}-${i}`} className={`rounded-2xl border p-3 ${x.match==='EXACT 4D'?'border-emerald-400/30 bg-emerald-500/10':'border-white/10 bg-black/25'}`}><div className="text-[9px] text-slate-600">{x.kind}</div><div className="font-mono text-2xl font-black text-white mt-1">{x.value}</div><div className="text-[10px] text-cyan-200 mt-2">{x.match}</div><div className="text-[9px] text-slate-500 mt-1">Previous index {x.score} · {x.decision}</div></div>)}</div></section>
      <section className="grid lg:grid-cols-2 gap-3"><div className="rounded-3xl border border-white/10 bg-black/20 p-5"><div className="text-white font-black">কেন miss হতে পারে — ENGINE DIAGNOSTIC</div><div className="space-y-2 mt-4 text-xs text-slate-400">{[
        `Baseline candidate-গুলো বর্তমান data-তে একই rank ধরে রাখেনি: নতুন data যোগ হলে sensor evidence recompute হয়েছে।`,
        `Current fusion coverage: 107=${current.fusion.coverage.core107}, 28=${current.fusion.coverage.signals28}, Math=${current.fusion.coverage.mathProperties}, Investigator=${current.fusion.coverage.investigatorFindings}, Advanced tests=${current.fusion.coverage.advancedTests}.`,
        `Current scientific status: ${current.validation.oosAvailable?'OOS available':'OOS limited'}; FDR ${current.validation.fdrChecked?'checked':'limited'}.`,
        `যদি actual result baseline-এর বাইরে থাকে, সেটিকে failure হিসেবে log করা হবে; system retrospectiveভাবে result বদলাবে না।`
      ].map((x,i)=><div key={i} className="rounded-xl border border-white/5 bg-white/[.025] p-3">◆ {x}</div>)}</div></div>
      <div className="rounded-3xl border border-white/10 bg-black/20 p-5"><div className="text-white font-black">BASELINE → CURRENT</div><div className="space-y-2 mt-4 text-xs">{categories.map(k=>{const a=(baseline.findings?.[k]??[]).map((x:any)=>x.value);const b=(current.findings?.[k]??[]).map(x=>x.value);const changed=a.join(',')!==b.join(',');return <div key={k} className="rounded-xl border border-white/5 bg-black/20 p-3"><div className="text-[9px] text-slate-600">{k}</div><div className="text-slate-300 mt-1">Old: <span className="font-mono">{a.join(' · ')||'—'}</span></div><div className="text-cyan-200 mt-1">New: <span className="font-mono">{b.join(' · ')||'—'}</span></div><div className={`text-[9px] mt-1 ${changed?'text-orange-300':'text-emerald-300'}`}>{changed?'RANK CHANGED':'STABLE'}</div></div>})}</div></div></section>
    </>}
  </div>;
}

function FinalDigitVault(){
  const [open,setOpen]=useState(false); const [selected,setSelected]=useState<string[]>([]); const [locked,setLocked]=useState(false);
  const toggle=(d:string)=>{if(locked)return;setSelected(s=>s.includes(d)?s.filter(x=>x!==d):s.length<4?[...s,d]:s)};
  const reset=()=>{setLocked(false);setSelected([])};
  return <section className="relative overflow-hidden rounded-[2.5rem] border border-cyan-300/20 p-5 md:p-8 bg-[radial-gradient(circle_at_20%_20%,rgba(34,211,238,.16),transparent_30%),radial-gradient(circle_at_80%_70%,rgba(168,85,247,.18),transparent_35%),linear-gradient(135deg,#07131c,#111022,#05070b)] shadow-[0_30px_100px_rgba(0,0,0,.45)]"><div className="absolute inset-0 pointer-events-none opacity-30" style={{backgroundImage:'radial-gradient(circle,rgba(255,255,255,.18) 1px,transparent 1px)',backgroundSize:'28px 28px'}}/><div className="relative"><div className="text-[10px] tracking-[.35em] text-cyan-300 font-black">FINAL DIGIT · PRIVATE VAULT</div><div className="flex flex-col md:flex-row md:items-end justify-between gap-3"><div><h2 className="text-white text-2xl md:text-3xl font-black mt-2">FINAL DIGIT</h2><p className="text-slate-400 text-xs mt-1">এটি আপনার ব্যক্তিগত/manual selection box — Master Final Result-এর evidence calculation পরিবর্তন করে না।</p></div><button onClick={()=>setOpen(v=>!v)} className="rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-4 py-2 text-xs font-black text-cyan-100">{open?'CLOSE BALLS':'OPEN 10 BALLS'}</button></div>
    <div className="grid grid-cols-4 gap-3 mt-6 max-w-xl">{Array.from({length:4},(_,i)=><div key={i} className={`h-20 rounded-2xl border border-white/10 bg-black/30 flex items-center justify-center font-mono text-2xl font-black text-white ${locked?'animate-pulse':''}`}>{locked?'●':selected[i]??'—'}</div>)}</div>
    {open&&!locked&&<div className="grid grid-cols-5 sm:grid-cols-10 gap-2 mt-5 max-w-4xl">{Array.from({length:10},(_,i)=>String(i)).map(d=><button key={d} onClick={()=>toggle(d)} className={`aspect-square rounded-full border text-lg font-black transition ${selected.includes(d)?'border-cyan-300 bg-cyan-400/20 text-cyan-100 shadow-[0_0_25px_rgba(34,211,238,.25)]':'border-white/10 bg-white/[.04] text-slate-300 hover:bg-white/10'}`}>{d}</button>)}</div>}
    <div className="flex flex-wrap gap-2 mt-5">{!locked&&<button disabled={selected.length!==4} onClick={()=>setLocked(true)} className="rounded-xl bg-emerald-500/15 border border-emerald-400/30 px-4 py-2 text-xs font-black text-emerald-200 disabled:opacity-30">LOCK / HIDE FINAL DIGIT</button>}{locked&&<button onClick={reset} className="rounded-xl bg-orange-500/10 border border-orange-400/30 px-4 py-2 text-xs font-black text-orange-200">UNLOCK / RESET</button>}</div>
    {locked&&<div className="mt-4 text-[10px] text-slate-500">৪টি বলের ভিতরের digit UI-তে hidden। নড়াচড়া/animation শুধু visual privacy cue; এই manual selection Final Result-এর evidence score-এ যোগ হয় না।</div>}
  </div></section>;
}

function ResultSet({kind,items,onSelect}:{kind:FinalKind;items:FinalCandidate[];onSelect:(x:FinalCandidate)=>void}){
  return <section className="rounded-3xl border border-white/10 bg-black/25 p-4 md:p-5 shadow-[0_18px_55px_rgba(0,0,0,.25)]">
    <div className="flex items-center justify-between gap-3 mb-3"><div><div className="text-white font-black text-base">{finalTitle(kind)}</div><div className="text-slate-500 text-[10px] mt-1">৪টি canonical set · historical evidence ranking</div></div><span className="text-[9px] uppercase tracking-widest text-slate-600">LIVE</span></div>
    <div className="grid grid-cols-2 xl:grid-cols-4 gap-2">
      {items.map(x=><button key={x.id} onClick={()=>onSelect(x)} className="text-left rounded-2xl border border-white/10 bg-slate-950/70 hover:bg-white/[.06] hover:border-cyan-400/30 transition p-3 group">
        <div className="flex items-center justify-between"><span className="text-[9px] text-slate-600">SET {String(x.set).padStart(2,'0')}</span><span className={`text-[8px] px-1.5 py-0.5 rounded-full border ${decisionClass(x.decision)}`}>{x.decision}</span></div>
        <div className="font-mono font-black text-2xl md:text-3xl tracking-[.12em] text-white mt-2 group-hover:text-cyan-200">{x.value}</div>
        <div className="grid grid-cols-2 gap-2 mt-3 text-[9px]"><div><span className="text-slate-600">COUNT</span><div className="text-slate-200 font-bold">{x.count}</div></div><div><span className="text-slate-600">INDEX</span><div className="text-emerald-300 font-bold">{x.score.toFixed(1)}</div></div></div>
      </button>)}
      {!items.length&&<div className="col-span-full rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5 text-center text-amber-200 text-xs">INSUFFICIENT DATA — কোনো কৃত্রিম ফল তৈরি করা হয়নি।</div>}
    </div>
  </section>;
}

function MasterCandidateCard({x}:{x:any}){
  const hot=x.band==='HOT';
  return <div className={`rounded-2xl border p-3 ${hot?'border-orange-400/20 bg-orange-500/[.045]':'border-cyan-400/15 bg-cyan-500/[.035]'}`}>
    <div className="flex items-center justify-between gap-2">
      <span className="text-[8px] text-slate-600 font-black">SET {String(x.set).padStart(2,'0')}</span>
      <span className={`text-[8px] px-1.5 py-0.5 rounded-full border font-black ${hot?'text-orange-200 border-orange-400/20 bg-orange-500/10':'text-cyan-200 border-cyan-400/20 bg-cyan-500/10'}`}>{hot?'🔥 HOT':'❄️ COLD'}</span>
    </div>
    <div className="font-mono font-black text-white text-2xl md:text-3xl tracking-[.12em] mt-2">{x.value}</div>
    <div className="grid grid-cols-3 gap-1.5 mt-3 text-[8px]">
      <div className="rounded-lg bg-black/25 p-2"><span className="text-slate-600">EVIDENCE</span><div className="text-emerald-200 font-black mt-0.5">{x.score.toFixed(1)}</div></div>
      <div className="rounded-lg bg-black/25 p-2"><span className="text-slate-600">CONSENSUS</span><div className="text-cyan-200 font-black mt-0.5">{x.consensus}/28</div></div>
      <div className="rounded-lg bg-black/25 p-2"><span className="text-slate-600">CONFLICT</span><div className="text-amber-200 font-black mt-0.5">{x.conflict}</div></div>
    </div>
    <div className="text-[8px] text-slate-500 mt-2">{x.evidence}</div>
  </div>;
}

function MasterLevelPanel({level,items}:{level:MasterLevel;items:any[]}){
  const hot=items.filter(x=>x.band==='HOT');
  const cold=items.filter(x=>x.band==='COLD');
  const is5=level==='5D';
  return <section className="rounded-[1.5rem] border border-white/10 bg-black/25 p-3 md:p-4">
    <div className="flex items-center justify-between gap-2 mb-3">
      <div><div className="text-white font-black font-mono text-lg">{level}</div><div className="text-[8px] text-slate-600">{is5?'DERIVED COMPOSITE · 5 SETS':'RESEARCH CANDIDATES · 4 SETS'}</div></div>
      <div className="text-[8px] text-slate-500">{items.length}/{is5?5:4}</div>
    </div>
    <div className="grid md:grid-cols-2 gap-2">
      <div><div className="text-[9px] tracking-widest text-orange-300 font-black mb-2">🔥 HOT</div><div className="space-y-2">{hot.map(x=><MasterCandidateCard key={`${level}-${x.value}`} x={x}/>)}</div></div>
      <div><div className="text-[9px] tracking-widest text-cyan-300 font-black mb-2">❄️ COLD</div><div className="space-y-2">{cold.map(x=><MasterCandidateCard key={`${level}-${x.value}`} x={x}/>)}</div></div>
    </div>
    {!items.length&&<div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4 text-center text-[10px] text-amber-200">INSUFFICIENT DATA — কোনো কৃত্রিম ফল তৈরি করা হয়নি।</div>}
  </section>;
}


function EvidenceVisual({bundle,level,onClose}:{bundle:MasterResearchBundle;level:MasterLevel;onClose:()=>void}){
  const value=level==='5D'?bundle.fiveD:level==='4D'?bundle.fourD:level==='3D'?bundle.threeD:level==='2D'?bundle.twoD:bundle.oneD;
  const title=level==='5D'?'5D · DERIVED COMPOSITE':`${level} · EVIDENCE VIEW`;
  const sensor=bundle.sensorProfile ?? {core107:0,signals28:bundle.consensus/28*100,mathematics:0,investigator:0,advanced:0,scientific:0,validation:0};
  const steps=[
    ['107 ANALYSES','Core analysis coverage','107/107'],
    ['11 PARTS','Part-level synthesis','11/11'],
    ['28 MODULES','Candidate signal agreement',`${bundle.consensus}/28`],
    ['FUSION','Consensus + conflict',`${bundle.conflict} conflict`],
    ['RESULT','Ranked research candidate',`${bundle.score.toFixed(1)}`],
  ];
  return <div className="fixed inset-0 z-[90] bg-black/80 backdrop-blur-md p-3 md:p-8 flex items-center justify-center" onClick={onClose}>
    <div className="w-full max-w-5xl max-h-[92vh] overflow-auto rounded-[2rem] border border-cyan-400/20 bg-[#071018] shadow-[0_35px_120px_rgba(0,0,0,.75)] p-5 md:p-7" onClick={e=>e.stopPropagation()}>
      <div className="flex items-start justify-between gap-4">
        <div><div className="text-[9px] tracking-[.3em] text-cyan-300 font-black">VISUAL RESULT EXPLANATION</div><h3 className="text-white text-2xl md:text-4xl font-black mt-2">{title}</h3><div className="font-mono text-cyan-100 text-4xl md:text-6xl font-black tracking-[.12em] mt-3">{value}</div></div>
        <button onClick={onClose} className="w-10 h-10 rounded-xl border border-white/10 bg-white/5 text-slate-300">✕</button>
      </div>
      <div className="grid md:grid-cols-5 gap-2 mt-6">
        {steps.map(([a,b,c],i)=><div key={a} className="relative rounded-2xl border border-white/10 bg-black/25 p-3 min-h-[100px]"><div className="text-[8px] text-cyan-300 font-black">STEP {i+1}</div><div className="text-white font-black text-xs mt-2">{a}</div><div className="text-[9px] text-slate-500 mt-1">{b}</div><div className="text-emerald-200 font-mono font-black mt-2">{c}</div>{i<4&&<span className="hidden md:block absolute -right-2 top-1/2 text-cyan-300">→</span>}</div>)}
      </div>
      <div className="grid lg:grid-cols-3 gap-3 mt-4">
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-black/25 p-4">
          <div className="text-white font-black">কেন এই Result?</div>
          <div className="text-[10px] text-slate-500 mt-1">এই visualটি একই run-এর evidence lineage দেখায়—শুধু decorative chart নয়।</div>
          <div className="mt-5 h-36 flex items-end gap-2">{[
            ['107',sensor.core107],['28',sensor.signals28],['MATH',sensor.mathematics],['INV',sensor.investigator],['ADV',sensor.advanced],['SCI',sensor.scientific],['OOS',sensor.validation],['FINAL',bundle.score]
          ].map(([label,raw],i)=>{const h=Math.max(4,Math.min(100,Number(raw)||0));return <div key={i} className="flex-1 h-full flex flex-col justify-end"><div className="rounded-t-xl bg-gradient-to-t from-cyan-500/20 to-cyan-300/70" style={{height:`${h}%`}}/><div className="text-[7px] text-slate-600 text-center mt-1">{label}</div></div>})}</div>
          <div className="grid grid-cols-3 gap-2 mt-4"><Stat label="Rank" value={`#${bundle.rank}`}/><Stat label="Consensus" value={`${bundle.consensus}/28`}/><Stat label="Conflict" value={bundle.conflict}/></div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
          <div className="text-white font-black">Research Meaning</div>
          <div className={`mt-3 inline-flex px-3 py-1 rounded-full border text-xs font-black ${bundle.band==='HOT'?'text-orange-200 border-orange-400/20 bg-orange-500/10':'text-cyan-200 border-cyan-400/20 bg-cyan-500/10'}`}>{bundle.band==='HOT'?'🔥 HOT':'❄️ COLD'}</div>
          <div className="text-slate-300 text-xs mt-4 leading-6">Evidence: <b>{bundle.evidence}</b><br/>Score: <b>{bundle.score.toFixed(1)}</b><br/>Source: <b>full research pipeline</b></div>
          <div className="mt-4 rounded-xl border border-amber-400/15 bg-amber-500/5 p-3 text-[9px] text-amber-200">এটি historical research evidence ranking; ভবিষ্যৎ ফলের নিশ্চয়তা নয়। 5D হলো derived composite.</div>
        </div>
      </div>
    </div>
  </div>;
}

function TenSetResearchBoard({master}:{master:ReturnType<typeof buildMasterResultSheet>}){
  const storageKey=`4d-hospital-master-10set-v2-${master.traceability.datasetFingerprint}-${master.traceability.calculationVersion}`;
  const lockKey=`${storageKey}-locks`;
  const [rows,setRows]=useState<MasterResearchBundle[]>(()=>{
    try{const raw=localStorage.getItem(storageKey);if(raw){const parsed=JSON.parse(raw);if(Array.isArray(parsed)&&parsed.length===10)return parsed;}}catch{} return master.researchSets10;
  });
  const [locked,setLocked]=useState<boolean[]>(()=>{
    try{const raw=localStorage.getItem(lockKey);if(raw){const parsed=JSON.parse(raw);if(Array.isArray(parsed)&&parsed.length===10)return parsed;}}catch{} return Array(10).fill(false);
  });
  const [visual,setVisual]=useState<{bundle:MasterResearchBundle;level:MasterLevel}|null>(null);
  const update=(i:number,key:keyof MasterResearchBundle,value:string)=>{
    const limits:{fiveD:number;fourD:number;threeD:number;twoD:number;oneD:number}={fiveD:5,fourD:4,threeD:3,twoD:2,oneD:1};
    if(!['fiveD','fourD','threeD','twoD','oneD'].includes(key))return;
    const clean=value.replace(/\D/g,'').slice(0,limits[key as keyof typeof limits]);
    setRows(prev=>prev.map((r,idx)=>idx===i?{...r,[key]:clean}:r));
  };
  const save=()=>{try{localStorage.setItem(storageKey,JSON.stringify(rows));localStorage.setItem(lockKey,JSON.stringify(locked));}catch{}};
  return <section className="rounded-[2rem] border border-fuchsia-400/20 bg-gradient-to-br from-fuchsia-500/[.07] via-cyan-500/[.04] to-orange-500/[.06] p-4 md:p-6">
    <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-3"><div><div className="text-[9px] tracking-[.25em] text-fuchsia-300 font-black">10-SET RESEARCH RESULT · VISUAL BOARD</div><h3 className="text-white text-xl md:text-3xl font-black mt-2">১০টি Evidence Bundle</h3><p className="text-slate-500 text-[10px] md:text-xs mt-1">প্রতিটি bundle একই full research pipeline-এর উপর ভিত্তি করে 5D → 4D → 3D → 2D → 1D visual lineage দেখায়।</p></div><button onClick={save} className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-2 text-xs font-black text-emerald-200">SAVE 10-SET EDITS</button></div>
    <div className="overflow-auto mt-5 rounded-2xl border border-white/10"><table className="w-full min-w-[980px] text-xs"><thead className="bg-black/40"><tr className="text-slate-500"><th className="p-3 text-left">RANK</th><th className="p-3 text-left">5D</th><th className="p-3 text-left">4D</th><th className="p-3 text-left">3D</th><th className="p-3 text-left">2D</th><th className="p-3 text-left">1D</th><th className="p-3 text-left">EVIDENCE</th><th className="p-3 text-left">VISUAL</th><th className="p-3 text-left">LOCK</th></tr></thead>
      <tbody>{rows.slice(0,10).map((r,i)=><tr key={i} className="border-t border-white/5"><td className="p-2"><span className="font-black text-white">#{i+1}</span><div className={`text-[8px] mt-1 ${r.band==='HOT'?'text-orange-300':'text-cyan-300'}`}>{r.band}</div></td>
        {(['fiveD','fourD','threeD','twoD','oneD'] as const).map((k)=><td key={k} className="p-2"><input value={r[k]} disabled={locked[i]} onChange={e=>update(i,k,e.target.value)} className="w-[120px] rounded-xl bg-black/30 border border-white/10 px-2 py-2 font-mono font-black text-white focus:border-cyan-300/40 outline-none" maxLength={k==='fiveD'?5:k==='fourD'?4:k==='threeD'?3:k==='twoD'?2:1}/></td>)}
        <td className="p-2"><div className="text-emerald-200 font-black">{r.score.toFixed(1)}</div><div className="text-[8px] text-slate-500">{r.consensus}/28 · C{r.conflict}</div></td>
        <td className="p-2"><div className="flex gap-1">{(['5D','4D','3D','2D','1D'] as MasterLevel[]).map(l=><button key={l} onClick={()=>setVisual({bundle:r,level:l})} className="rounded-lg border border-cyan-400/20 bg-cyan-500/5 px-2 py-1 text-[8px] font-black text-cyan-200">{l}</button>)}</div></td>
        <td className="p-2"><button onClick={()=>setLocked(a=>a.map((v,idx)=>idx===i?!v:v))} className={`rounded-xl px-3 py-2 text-[9px] font-black border ${locked[i]?'border-orange-400/30 bg-orange-500/10 text-orange-200':'border-emerald-400/20 bg-emerald-500/5 text-emerald-200'}`}>{locked[i]?'🔒 LOCKED':'EDIT / LOCK'}</button></td>
      </tr>)}</tbody></table></div>
    <div className="mt-3 text-[9px] text-slate-500">এই box-এ manual edit/lock হলো আপনার research workspace; edit করা সংখ্যা মূল sensor score বদলায় না।</div>
    {visual&&<EvidenceVisual bundle={visual.bundle} level={visual.level} onClose={()=>setVisual(null)}/>} 
  </section>;
}

function MasterResultSheetPanel({results}:{results:ResultRow[]}){
  const master=useMemo(()=>buildMasterResultSheet(results.map(r=>r as unknown as CanonicalDraw)),[results]);
  const levels:MasterLevel[]=["5D","4D","3D","2D","1D"];
  const totalExpected=5+4+4+4+4;
  const actual=levels.reduce((n,l)=>n+master.levels[l].length,0);
  return <section className="rounded-[2rem] border border-cyan-400/20 bg-gradient-to-br from-cyan-500/[.08] via-purple-500/[.05] to-emerald-500/[.07] p-4 md:p-6 shadow-[0_25px_80px_rgba(0,0,0,.28)]">
    <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-3">
      <div><div className="text-[9px] tracking-[.24em] text-cyan-300 font-black">MASTER RESULT SHEET · {master.version}</div><h2 className="text-white text-xl md:text-3xl font-black mt-2">5D × 5 · 4D × 4 · 3D × 4 · 2D × 4 · 1D × 4</h2><p className="text-slate-400 text-[10px] md:text-xs mt-2 max-w-4xl">সকল 107 Analysis + 11 Parts + 28 Signal Modules + Mathematical + Investigator + Advanced/Scientific/Validation → Sensor Evidence Fusion → Master Result. HOT ও COLD আলাদা evidence lane.</p></div>
      <div className="grid grid-cols-3 gap-2 text-center"><Stat label="107" value={`${master.coverage.analysis107}/107`}/><Stat label="Parts" value={`${master.coverage.parts11}/11`}/><Stat label="Modules" value={`${master.coverage.modules28}/28`}/></div>
    </div>

    <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4">
      <Stat label="5D" value={`${master.levels['5D'].length}/5`} sub="derived"/><Stat label="4D" value={`${master.levels['4D'].length}/4`} sub="core"/><Stat label="3D" value={`${master.levels['3D'].length}/4`} sub="derived"/><Stat label="2D" value={`${master.levels['2D'].length}/4`} sub="derived"/><Stat label="1D" value={`${master.levels['1D'].length}/4`} sub="derived"/>
    </div>

    <div className="grid xl:grid-cols-2 gap-3 mt-4">{levels.map(level=><MasterLevelPanel key={level} level={level} items={master.levels[level]}/>)}</div>

    <div className="mt-4 rounded-2xl border border-white/10 bg-black/25 p-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2"><div><div className="text-white font-black">SENSOR SYSTEM · EVIDENCE HEALTH</div><div className="text-[9px] text-slate-500 mt-1">ফাইনাল ফলের আগে কোন layer কাজ করেছে, কোনটি limited, এবং কোথায় conflict আছে—সব দৃশ্যমান।</div></div><div className="text-xs font-black text-cyan-200">{actual}/{totalExpected} candidates populated</div></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-2 mt-3">{master.sensors.map((x:any)=><div key={x.name} className="rounded-xl border border-white/5 bg-white/[.02] p-3"><div className="flex justify-between gap-2"><span className="text-[9px] text-white font-black">{x.name}</span><span className={`text-[8px] font-black ${x.status==='READY'?'text-emerald-300':x.status==='LIMITED'?'text-amber-300':'text-red-300'}`}>{x.status}</span></div><div className="text-[8px] text-slate-500 mt-1">{x.detail}</div></div>)}</div>
    </div>

    <div className="grid md:grid-cols-4 gap-2 mt-3"><Stat label="Active Signal Modules" value={master.sensorSummary.activeModules}/><Stat label="107 Support" value={master.sensorSummary.support}/><Stat label="107 Conflict" value={master.sensorSummary.conflict}/><Stat label="Insufficient" value={master.sensorSummary.insufficient}/></div>
    <div className="mt-3 grid md:grid-cols-2 gap-2 text-[9px]"><div className="rounded-xl border border-white/5 bg-black/20 p-3"><span className="text-slate-600">DATASET FINGERPRINT</span><div className="font-mono text-cyan-200 mt-1 break-all">{master.traceability.datasetFingerprint}</div><span className="text-slate-600 block mt-2">CALCULATION</span><div className="font-mono text-slate-300 mt-1">{master.traceability.calculationVersion}</div><span className="text-slate-600 block mt-2">FUSION</span><div className="font-mono text-slate-300 mt-1">{master.traceability.fusionVersion}</div></div><div className="rounded-xl border border-amber-500/15 bg-amber-500/[.03] p-3 text-amber-200">{master.boundary.map(x=><div key={x} className="mb-1">• {x}</div>)}</div></div>
  </section>;
}

export function FinalResearchResultPage({results}:Props){
  const [company,setCompany]=useState("ALL");
  const [selected,setSelected]=useState<FinalCandidate|null>(null);
  const filtered=useMemo(()=>company==='ALL'?results:results.filter(r=>r.company===company),[results,company]);
  const report=useMemo(()=>buildFinalResultReport(filtered.map(r=>r as unknown as CanonicalDraw)),[filtered]);
  const sections:FinalKind[]=['HOT_4D','COOL_4D','PAIR','HOT_PAIR','COOL_PAIR','SINGLE','HOT_SINGLE','COOL_SINGLE','HOT_3D','COOL_3D'];
  const integrity=report.validation.dataIntegrity&&report.validation.duplicateCount===0&&report.validation.chronological;
  return <div className="max-w-[1500px] mx-auto p-3 md:p-5 space-y-4">
    <section className="rounded-[2rem] border border-emerald-400/20 bg-gradient-to-br from-emerald-500/10 via-cyan-500/5 to-purple-500/10 p-5 md:p-7 shadow-[0_25px_80px_rgba(0,0,0,.35)]">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div><div className="text-[10px] tracking-[.28em] text-emerald-300 font-black">FINAL RESEARCH RESULT · LIVE EVIDENCE LAYER</div><h1 className="text-white text-2xl md:text-4xl font-black mt-2">১০টি Final Result Surface · ৪টি Set করে</h1><p className="text-slate-400 text-xs md:text-sm mt-2 max-w-3xl">107 Core + 28 Signal Sensor + Mathematical + Investigator + Advanced + Scientific/Validation evidence fusion করে এই Final Result তৈরি হয়। এটি কোনো winning probability নয়।</p></div>
        <select value={company} onChange={e=>setCompany(e.target.value)} className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm text-white"><option value="ALL">সব কোম্পানি</option><option value="magnum">Magnum 4D</option><option value="toto">Toto 4D</option><option value="damacai">Da Ma Cai</option><option value="singapore">Singapore 4D</option></select>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-2 mt-5">
        <Stat label="Records" value={report.dataset.validRecords.toLocaleString()} />
        <Stat label="107 Analysis" value={report.analysis.total} sub="canonical" />
        <Stat label="Support" value={report.analysis.support} />
        <Stat label="Conflict" value={report.analysis.conflict} />
        <Stat label="Coverage" value={`${(report.analysis.coverage*100).toFixed(0)}%`} />
        <Stat label="Integrity" value={integrity?'PASS':'CHECK'} />
        <Stat label="FDR" value={report.validation.fdrChecked?'CHECKED':'PENDING'} />
        <Stat label="OOS" value={report.validation.oosAvailable?'AVAILABLE':'LIMITED'} />
      </div>
    </section>

    <section className="flex flex-wrap gap-2 rounded-2xl border border-white/10 bg-black/20 p-4"><button onClick={()=>{try{localStorage.setItem(BASELINE_KEY,JSON.stringify(report));}catch{}}} className="rounded-xl border border-orange-400/30 bg-orange-500/10 px-4 py-2 text-xs font-black text-orange-200">SAVE THIS FINAL RESULT AS BASELINE</button><span className="text-[10px] text-slate-500 self-center">পরের data batch যোগ হলে ④ Result Miss Autopsy-তে কেন মিলল না তা পরীক্ষা করা যাবে।</span></section>

    <section className="grid lg:grid-cols-4 gap-3">
      {[['DATA INTEGRITY',integrity?'PASS':'CHECK',integrity?'All canonical rows valid and chronological.':`duplicates=${report.validation.duplicateCount}`],['MATHEMATICAL',report.validation.mathChecked?'CONNECTED':'LIMITED','Digit/number-theory layer is connected to the 107-core run.'],['FDR / NULL',report.validation.fdrChecked?'CHECKED':'PENDING','Multiple-testing state is surfaced instead of hidden.'],['OOS / ADVANCED',report.validation.oosAvailable?'AVAILABLE':'INSUFFICIENT','Predictive claims remain gated by validation.']].map(([a,b,c])=><div key={String(a)} className="rounded-2xl border border-white/10 bg-white/[.025] p-4"><div className="text-[9px] tracking-widest text-slate-600">{a}</div><div className="text-white font-black mt-2">{b}</div><div className="text-slate-500 text-[10px] mt-1">{c}</div></div>)}
    </section>

    <div className="grid xl:grid-cols-2 gap-4">
      {sections.map(k=><ResultSet key={k} kind={k} items={report.findings[k]} onSelect={setSelected}/>)}
    </div>

    <MasterResultSheetPanel results={results}/>

    <TenSetResearchBoard master={buildMasterResultSheet(results.map(r=>r as unknown as CanonicalDraw))}/>

    <section className="rounded-3xl border border-white/10 bg-black/25 p-5">
      <div className="text-white font-black">FINAL DECISION / TRACEABILITY</div>
      <div className="text-slate-500 text-xs mt-1">প্রতিটি result-এর source, count, score, status এবং dataset fingerprint একই run-এর সঙ্গে বাঁধা।</div>
      <div className="grid md:grid-cols-3 gap-2 mt-4 text-xs"><div className="rounded-xl bg-black/30 p-3 border border-white/5"><span className="text-slate-600">DATASET FINGERPRINT</span><div className="font-mono text-cyan-200 mt-1">{report.dataset.fingerprint}</div></div><div className="rounded-xl bg-black/30 p-3 border border-white/5"><span className="text-slate-600">CALCULATION</span><div className="font-mono text-cyan-200 mt-1">{report.analysis.calculationVersion}</div></div><div className="rounded-xl bg-black/30 p-3 border border-white/5"><span className="text-slate-600">DATA RANGE</span><div className="text-slate-200 mt-1">{report.dataset.oldest??'—'} → {report.dataset.newest??'—'}</div></div></div>
      <div className="mt-4 grid md:grid-cols-2 gap-2">{report.notes.map(n=><div key={n} className="rounded-xl bg-white/[.025] border border-white/5 p-3 text-[11px] text-slate-400">◆ {n}</div>)}</div>
    </section>

    <FinalDigitVault />

    <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-4 text-xs text-red-200">⚠️ <b>Research boundary:</b> Hot/Cool/Pair/Single/3-Digit rankings describe the historical dataset and model-governed evidence. They do not establish that any specific number will appear next and must not be presented as a guarantee.</div>

    {selected&&<div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-sm p-4 flex items-center justify-center" onClick={()=>setSelected(null)}><div className="w-full max-w-xl rounded-[2rem] border border-cyan-400/20 bg-[#0b1018] shadow-[0_30px_100px_rgba(0,0,0,.65)] p-5" onClick={e=>e.stopPropagation()}><div className="flex justify-between gap-3"><div><div className="text-[9px] tracking-[.2em] text-cyan-300">{finalTitle(selected.kind)}</div><div className="font-mono text-5xl font-black text-white mt-2">{selected.value}</div></div><button onClick={()=>setSelected(null)} className="w-9 h-9 rounded-xl bg-white/5 text-slate-300">✕</button></div><div className="grid grid-cols-2 gap-2 mt-5"><Stat label="Set" value={selected.set}/><Stat label="Historical Count" value={selected.count}/><Stat label="Share" value={`${(selected.share*100).toFixed(3)}%`}/><Stat label="Evidence Index" value={selected.score.toFixed(1)}/></div><div className="mt-4 space-y-2 text-xs"><div className="rounded-xl border border-white/5 bg-black/20 p-3"><span className="text-slate-600">DECISION</span><div className="text-white font-black mt-1">{selected.decision}</div></div><div className="rounded-xl border border-white/5 bg-black/20 p-3"><span className="text-slate-600">LAST SEEN</span><div className="text-slate-200 font-mono mt-1">{selected.lastSeen??'—'}</div></div><div className="rounded-xl border border-white/5 bg-black/20 p-3"><span className="text-slate-600">SOURCE</span><div className="text-slate-400 mt-1">{selected.source}</div></div><div className="rounded-xl border border-white/5 bg-black/20 p-3 text-amber-200">Index ≠ winning probability. Historical evidence only.</div></div></div></div>}
  </div>;
}

export function ResearchResultTriad({results,onView}:Props){
  const [tab,setTab]=useState<"all"|"infra"|"final"|"autopsy">("all");
  return <div className="min-h-full"><div className="sticky top-0 z-20 px-3 md:px-5 py-3 bg-[#0f0f0f]/95 backdrop-blur border-b border-white/10"><div className="max-w-7xl mx-auto flex gap-2 overflow-x-auto"><button onClick={()=>setTab("all")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='all'?"bg-blue-500/20 text-blue-200 border border-blue-500/30":"bg-white/5 text-slate-400"}`}>① All Analysis Results</button><button onClick={()=>setTab("infra")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='infra'?"bg-purple-500/20 text-purple-200 border border-purple-500/30":"bg-white/5 text-slate-400"}`}>② Research Intelligence</button><button onClick={()=>setTab("final")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='final'?"bg-emerald-500/20 text-emerald-200 border border-emerald-500/30":"bg-white/5 text-slate-400"}`}>③ Final Research Result</button><button onClick={()=>setTab("autopsy")} className={`px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap ${tab==='autopsy'?"bg-orange-500/20 text-orange-200 border border-orange-500/30":"bg-white/5 text-slate-400"}`}>④ Result Miss Autopsy</button></div></div>{tab==='all'?<AllAnalysisResultsPage results={results} onView={onView}/>:tab==='infra'?<ResearchIntelligencePage results={results} onView={onView}/>:tab==='final'?<FinalResearchResultPage results={results} onView={onView}/>:<MissAutopsyPage results={results}/>}</div>;
}
