# 4D HOSPITAL — Release Gate Repair Report (2026-10-09)

## What was repaired in this iteration

1. Removed `--ignore-scripts` from the three clean CI dependency-install steps. Build tools such as esbuild/Vite and some native dependencies may rely on install lifecycle scripts; disabling them risks an incomplete or unusable build environment.
2. Added an explicit npm registry connectivity preflight before each clean `npm ci` stage. It retries three times and exits with a clear `BLOCKED` message if the runner cannot reach the registry. It does not report a false PASS or silently skip dependency installation.
3. Updated the GitHub/Android workflow static audit to expect the normal `npm ci --no-audit --no-fund` command.

## Verification actually performed in this environment

- Lockfile v3 / package dependency preflight: PASS (66 declared packages represented).
- Dependency lock audit: PASS.
- 107-analysis static audit: PASS.
- Data permanence audit: PASS.
- Storage/security audit: PASS.
- Master Result count/coverage audit: PASS.
- Visual architecture audit: PASS (107 analyses, 11 Parts, 28 modules, 428 analysis page instances, 45 additional/system views).
- Visual analysis layer audit: PASS.
- Forensic release audit: PASS.
- GitHub/Android workflow static audit: PASS.
- Workflow YAML parse: PASS.
- Workflow lifecycle-script policy: PASS (`npm ci` no longer disables scripts).

## External gates that remain NOT VERIFIED

This sandbox cannot resolve `registry.npmjs.org` (`curl` returns `Could not resolve host: registry.npmjs.org`; `getent hosts` returns no address). Therefore `npm ci` was not able to run to completion here, and these dependent gates have not been executed here:

1. Clean npm ci — NOT VERIFIED in this sandbox (blocked by registry DNS/network).
2. Vite production build — NOT VERIFIED.
3. Android Gradle APK build — NOT VERIFIED.
4. APK integrity on a newly built APK — NOT VERIFIED.
5. Android emulator install/launch smoke test — NOT VERIFIED.

The GitHub workflow is designed to run these gates on a fresh GitHub-hosted runner. The repository must be pushed to GitHub and the workflow must actually run before these can be marked PASS. This report deliberately does not label them PASS without execution evidence.

## Release decision

**Release candidate only — not yet a verified release.** Do not label the app RELEASE READY until the clean GitHub Actions run reports success through emulator smoke test.
