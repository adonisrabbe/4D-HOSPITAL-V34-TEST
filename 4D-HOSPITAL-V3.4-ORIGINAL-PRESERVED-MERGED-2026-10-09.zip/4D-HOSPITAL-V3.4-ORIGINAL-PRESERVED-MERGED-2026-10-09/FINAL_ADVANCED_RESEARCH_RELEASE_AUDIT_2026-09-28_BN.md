# 4D Hospital — Advanced Research A-to-Z Release Audit — 2026-09-28

## Release
Advanced Research Laboratory v2 has been integrated into the existing Investigator workflow.

### New research capabilities
- Evidence Quality Engine
- Bayesian posterior + credible interval
- Sequential Probability Ratio Test (SPRT)
- Information Theory: entropy, conditional entropy, mutual information, information gain, permutation entropy
- Higher-order transition analysis (order 1–3)
- Variable-memory context tree
- Change-point / regime diagnostics
- Permutation null-model laboratory with empirical p-value and effect size
- Benjamini-Hochberg FDR correction
- Redundancy graph with mathematical dependency groups
- Stability surface
- Motif / approximate subsequence discovery
- Lightweight interpretable symbolic discovery with chronological train/test split
- Conformal-style calibration diagnostics
- Meta-evidence weighting
- Research Constitution gates

## Integration
The Investigator panel now exposes the new research laboratory metrics and gate status. The public 107-analysis catalog remains 107; the new methods are validation/evidence infrastructure, not additional independent votes.

## Tests performed
| Test | Result |
|---|---|
| Advanced Research standalone TypeScript compile | PASS |
| Advanced Research 250-row runtime smoke test | PASS |
| 107 engine deep audit | PASS |
| Research Cycle E2E | PASS |
| Core 6 research layers audit | PASS |
| Mathematical Research audit | PASS |
| Investigator audit | PASS |
| TS/TSX syntax transpile audit | PASS — 93 files |
| Advanced Research static audit | PASS |

## Environment gates
- Full dependency installation could not complete within the sandbox time budget.
- npm registry/cache was unavailable for offline package-lock generation; no fake package-lock was created.
- Full application `tsc` / Vite production build therefore remains environment-dependent on installed React/Vite packages.
- Android SDK/device APK validation remains an external device/build gate.

## Research safety rule
Research scores, Bayesian posteriors, model agreement, formulas, motifs, or meta-weights are historical diagnostics. They are not represented as guaranteed future outcomes or winning probabilities.
