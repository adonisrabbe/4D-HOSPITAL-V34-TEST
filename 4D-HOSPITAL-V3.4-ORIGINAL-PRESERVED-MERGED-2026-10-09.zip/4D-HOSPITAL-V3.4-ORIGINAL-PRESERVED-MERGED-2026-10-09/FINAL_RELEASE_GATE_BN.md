> **Historical snapshot — superseded for current release instructions.** This file records an earlier project state. For the current lockfile, workflow, and release-gate status, use `CURRENT_RELEASE_TRUTH_BN.md` and `RELEASE_GATE_REPORT_V3.2_BN.md`.

# 4D HOSPITAL — Final Release Gate — 2026-10-05 (Hardened)

## Source-level gates verified

1. 107 public analysis boundary — PASS
2. Analysis contract/registry — PASS
3. Mathematical known-answer regression — PASS (64/64)
4. 107-engine execution verification — PASS (107/107)
5. Global inferential FDR architecture — PASS (59 hypotheses)
6. Scientific-gap regression — PASS
7. Advanced research layer — PASS
8. Investigator layer — PASS
9. Research-cycle E2E — PASS
10. Storage/security hardening audit — PASS
11. Stability/worker/error-boundary audit — PASS
12. GitHub/Android workflow audit — PASS
13. Independent benchmark fixture audit — PASS (5 deterministic fixtures)
14. Production-integrity audit — PASS
15. Offline-font/runtime external-font scan — PASS
16. Local authentication hardening audit — PASS

## Release infrastructure added

- Canonical `package-lock.json` is required by release CI and is **not present in this ZIP**.
- One-time GitHub lockfile bootstrap workflow is provided; the generated lockfile must be committed before release certification.
- CodeQL workflow added.
- Dependabot configuration added.
- SECURITY.md added.
- Issue/PR research-validity templates added.
- Deterministic independent benchmark protocol added.
- CSP and bundled local font configuration added.

## Not honestly marked PASS in this sandbox

- Full `npm ci` with the final lockfile: network/registry unavailable here.
- Full TypeScript compiler run: dependencies are not installed in this source-only sandbox.
- Vite production build.
- Capacitor Android generation/sync.
- Gradle APK compilation.
- Android emulator smoke test.
- Native/offline OCR implementation certification.
- Full 107-analysis Android performance certification at 100k–1M records (synthetic harness PASS থাকলেও device certification আলাদা)।

## Security boundary

Local authentication is a device-local application boundary, not a trusted remote identity system. Multi-device administration requires a backend with server-side authorization.

## Scientific boundary

Passing the research gates proves software/protocol correctness to the tested extent. It does **not** prove that future random 4-digit outcomes are predictable, nor does any evidence score represent a winning probability.
