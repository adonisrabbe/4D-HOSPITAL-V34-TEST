# 4D HOSPITAL — Production Upgrade v3 Release Report

তারিখ: 2026-09-28

## Release scope

এই release-এ দুটি বড় upgrade একসঙ্গে দেওয়া হয়েছে:

1. **Scientific Research Core v3** — adversarial research, temporal-leakage gate, evidence arbitration, reproducibility fingerprint, failure intelligence এবং research-memory snapshot.
2. **World-class Research Dashboard** — Evidence Profile, Research Gates, Adversarial Findings, Failure Intelligence, Provenance/Reproducibility এবং Research Memory এক স্ক্রিনে।

## নতুন Research Core

- Scientific Core v3.1 protocol
- Deterministic dataset fingerprint
- Feature-set provenance
- Temporal leakage process gate
- Chronological OOS gate
- Adversarial challenge pass
- Duplicate/concentration stress flag
- Regime-drift challenge
- Null-separation challenge
- Evidence profile with support/stability/OOS/null/redundancy/uncertainty dimensions
- Failure intelligence and failure-mode registry
- Research snapshot memory
- Deterministic reproducibility fingerprint

## Existing research preserved

- 107 Core analysis
- 28 signal layer
- Mathematical Laboratory
- Advanced Research Laboratory v2
- Bayesian
- SPRT
- Information Theory
- Higher-order transitions
- Context Tree
- Change-point
- Null model
- FDR
- Redundancy graph
- Stability surface
- Motif
- Symbolic discovery
- Conformal calibration
- Research Constitution
- Investigator
- Research Cycle / OOS feedback

## UI upgrade

নতুন navigation entry: **Scientific Core v3**

Dashboard sections:
- Evidence Profile
- Research Gates
- Adversarial Research
- Failure Intelligence
- Provenance & Reproducibility
- Research Memory
- Locked Research Snapshot

## Verification

PASS:
- Scientific Core v3 source audit
- Scientific Core v3 syntax audit
- Scientific Core v3 runtime smoke test (250 records)
- Advanced Research audit
- Investigator audit
- Research Cycle E2E
- Static audit
- Runtime contract audit
- Storage/security audit

### Environment limitation

`node_modules` উপস্থিত না থাকায় `npm run typecheck` এবং `npm run build` dependency-resolution পর্যায়ে সম্পন্ন করা যায়নি। `npm install --ignore-scripts --no-audit --no-fund` পরিবেশের timeout-এর কারণে শেষ হয়নি। তাই এই release-এ typecheck/build-কে PASS হিসেবে দাবি করা হয়নি।

## Scientific safety rule

এই upgrade historical evidence quality এবং research reproducibility উন্নত করে। এটি future 4-digit outcome-এর certainty, guarantee বা winning probability হিসেবে কোনো score ব্যবহার করে না।
