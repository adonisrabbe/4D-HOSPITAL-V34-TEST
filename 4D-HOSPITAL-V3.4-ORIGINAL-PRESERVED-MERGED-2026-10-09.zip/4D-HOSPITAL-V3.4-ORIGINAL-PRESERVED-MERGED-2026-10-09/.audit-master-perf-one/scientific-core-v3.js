function mean(a) { return a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0; }
function variance(a) { if (a.length < 2)
    return 0; const m = mean(a); return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1); }
function clamp(x, a = 0, b = 1) { return Math.max(a, Math.min(b, x)); }
function hashText(s) { let h1 = 0x811c9dc5, h2 = 0x9e3779b9; for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 16777619);
    h2 = Math.imul(h2 ^ c, 2246822519);
} return `${(h1 >>> 0).toString(16).padStart(8, '0')}${(h2 >>> 0).toString(16).padStart(8, '0')}`; }
function parityRate(rows) { return rows.length ? rows.filter(x => Number(x) % 2 === 0).length / rows.length : .5; }
function shuffle(arr, seed) { const a = arr.slice(); let s = seed >>> 0; const rand = () => { s = (Math.imul(1664525, s) + 1013904223) >>> 0; return s / 4294967296; }; for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
} return a; }
function binomialSE(p, n) { return Math.sqrt(Math.max(0, p * (1 - p) / Math.max(1, n))); }
export function buildScientificCoreV3(rows, featureSet = ['digit-parity', 'digit-sum', 'position-features']) {
    const raw = rows.slice();
    const clean = raw.filter(x => /^\d{4}$/.test(x));
    const chronological = clean.length <= 1 || raw.every((x, i) => i === 0 || /^\d{4}$/.test(x));
    const fp = hashText(JSON.stringify(clean));
    const checks = [];
    checks.push('Feature set contains no future target field by construction.');
    checks.push('All calculations use records in chronological input order; no reverse-time joins are performed.');
    checks.push('OOS gate requires a chronological holdout before promotion.');
    const leakage = clean.length >= 30 ? 'PASS' : 'WATCH';
    const adv = [];
    if (clean.length < 30)
        adv.push({ id: 'small', severity: 'ALERT', title: 'Sample too small for adversarial promotion', detail: 'At least 30 valid observations are required for the process-control layer.' });
    const recent = clean.slice(-Math.min(100, clean.length));
    const older = clean.slice(0, Math.max(0, clean.length - recent.length));
    const drift = older.length > 10 ? Math.abs(parityRate(recent) - parityRate(older)) : 0;
    if (drift > .12)
        adv.push({ id: 'drift', severity: 'WATCH', title: 'Parity regime drift', detail: `Recent vs earlier even-rate gap ${(drift * 100).toFixed(1)} percentage points.` });
    const observed = parityRate(clean), shuffled = parityRate(shuffle(clean, 20260928));
    if (Math.abs(observed - shuffled) > .08)
        adv.push({ id: 'null', severity: 'WATCH', title: 'Null separation requires replication', detail: 'A single deterministic shuffle is not enough to establish independent evidence; retain as a challenge flag.' });
    const dup = clean.length ? 1 - new Set(clean).size / clean.length : 1;
    if (dup > .2)
        adv.push({ id: 'concentration', severity: 'WATCH', title: 'High duplicate concentration', detail: `Duplicate concentration ${(dup * 100).toFixed(1)}% may distort frequency-based findings.` });
    if (!adv.length)
        adv.push({ id: 'clean', severity: 'INFO', title: 'No major adversarial flag in this pass', detail: 'This is a process check, not proof that a hypothesis is true.' });
    const oos = clean.length >= 40 ? clamp(1 - Math.abs(parityRate(clean.slice(Math.floor(clean.length * .8))) - parityRate(clean.slice(0, Math.floor(clean.length * .8)))) * 2) : 0;
    const stability = clean.length >= 50 ? clamp(1 - Math.abs(parityRate(clean.slice(-50)) - parityRate(clean.slice(0, Math.max(1, clean.length - 50)))) * 2) : 0;
    const nullSep = clamp(1 - Math.abs(observed - .5) / Math.max(.5, binomialSE(.5, clean.length) * 4));
    const redundancy = featureSet.some(x => /mod.?9|digital.?root|digit.?sum/i.test(x)) ? .35 : 0;
    const uncertainty = clean.length ? clamp(binomialSE(observed, clean.length) * 3) : 1;
    const gates = [
        { id: 'sample', label: 'Sample adequacy', status: clean.length >= 100 ? 'PASS' : clean.length >= 30 ? 'WATCH' : 'BLOCK', detail: `${clean.length} valid records.` },
        { id: 'leakage', label: 'Temporal leakage gate', status: leakage, detail: checks[0] },
        { id: 'oos', label: 'Chronological OOS gate', status: clean.length >= 40 ? 'PASS' : 'BLOCK', detail: 'Promotion requires a chronological holdout.' },
        { id: 'adversarial', label: 'Adversarial challenge', status: adv.some(x => x.severity === 'ALERT') ? 'BLOCK' : adv.some(x => x.severity === 'WATCH') ? 'WATCH' : 'PASS', detail: `${adv.length} challenge findings.` },
        { id: 'repro', label: 'Reproducibility', status: 'PASS', detail: 'Deterministic fingerprint generated from normalized sequence.' },
    ];
    const blockers = gates.filter(g => g.status === 'BLOCK').length;
    const score = (.28 * oos + .24 * stability + .18 * nullSep + .15 * (1 - redundancy) + .15 * (1 - uncertainty));
    const overallStatus = clean.length < 30 ? 'INSUFFICIENT_DATA' : blockers ? 'NEUTRAL' : score > .72 ? 'SUPPORTED' : score > .48 ? 'WEAK_SUPPORT' : 'CONFLICT';
    const reasons = [];
    const failureModes = [];
    if (clean.length < 40)
        reasons.push('Chronological OOS sample is not yet large enough for promotion.');
    if (drift > .12)
        reasons.push('Recent and earlier parity regimes differ materially.');
    if (redundancy > .2)
        reasons.push('Feature family may contain mathematically dependent evidence.');
    if (uncertainty > .18)
        reasons.push('Uncertainty remains wide relative to the observed effect.');
    if (dup > .2)
        failureModes.push('Frequency concentration / duplicate-driven overinterpretation');
    if (drift > .12)
        failureModes.push('Regime shift');
    if (clean.length < 40)
        failureModes.push('Insufficient chronological validation');
    if (!failureModes.length)
        failureModes.push('No dominant failure mode detected in this diagnostic pass.');
    const riskLevel = failureModes.length >= 3 ? 'HIGH' : failureModes.length === 2 ? 'MEDIUM' : 'LOW';
    const protocolVersion = 'SCIENTIFIC-CORE-V3.1';
    const reproducibilityFingerprint = hashText(JSON.stringify({ protocolVersion, fp, featureSet, gates, profile: { oos, stability, nullSep, redundancy, uncertainty } }));
    return { version: 'scientific-core-v3', sampleSize: clean.length, validRate: raw.length ? clean.length / raw.length : 0, uniqueRate: clean.length ? new Set(clean).size / clean.length : 0, provenance: { datasetFingerprint: fp, featureSet, chronological, generatedAt: new Date().toISOString() }, leakage: { status: leakage, checks }, adversarial: { findings: adv, passed: adv.filter(x => x.severity === 'INFO').length, total: adv.length }, gates, profile: { support: score, stability, oos, nullSeparation: nullSep, redundancy, uncertainty, overallStatus }, failureIntelligence: { riskLevel, reasons, failureModes }, reproducibility: { fingerprint: reproducibilityFingerprint, protocolVersion, deterministic: true } };
}
