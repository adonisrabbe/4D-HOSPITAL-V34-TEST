import { classify4D, MATH_PROPERTY_CATALOG } from './number-theory-lab.js';
import { correctedChangePoints, spectralPeakSignificance, globalBenjaminiHochberg, leakageSafeSymbolicDiscovery, discreteConformal4D } from './scientific-guards.js';
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const mean = (a) => a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0;
const variance = (a) => { if (a.length < 2)
    return 0; const m = mean(a); return mean(a.map(x => (x - m) ** 2)); };
const entropy = (a) => { if (!a.length)
    return 0; const c = new Map(); for (const x of a)
    c.set(x, (c.get(x) || 0) + 1); return [...c.values()].reduce((s, n) => { const p = n / a.length; return s - p * Math.log2(p); }, 0); };
const betaLogGamma = (z) => { const p = [676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109509572012, 9.984369578019572e-6, 1.5056327351493116e-7]; if (z < .5)
    return Math.log(Math.PI) - Math.log(Math.sin(Math.PI * z)) - betaLogGamma(1 - z); let x = .9999999999998099, t = z - 1; for (let i = 0; i < p.length; i++)
    x += p[i] / (t + i + 1); const q = t + p.length - .5; return .5 * Math.log(2 * Math.PI) + (t + .5) * Math.log(q) - q + Math.log(x); };
const logBeta = (a, b) => betaLogGamma(a) + betaLogGamma(b) - betaLogGamma(a + b);
function betaQuantile(a, b, q) {
    let lo = 0, hi = 1;
    const pdf = (x) => x <= 0 || x >= 1 ? 0 : Math.exp((a - 1) * Math.log(x) + (b - 1) * Math.log(1 - x) - logBeta(a, b));
    const n = 1800, dx = 1 / n;
    let total = 0;
    for (let i = 0; i < n; i++) {
        const x = (i + .5) * dx;
        total += pdf(x) * dx;
    }
    let acc = 0;
    for (let i = 0; i < n; i++) {
        const x = (i + .5) * dx;
        acc += pdf(x) * dx / Math.max(total, 1e-12);
        if (acc >= q)
            return x;
    }
    return q;
}
function seedRand(seed) { let s = seed >>> 0; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; }
;
function normalApproxP(z) { return Math.max(0, Math.min(1, Math.exp(-0.5 * z * z) * .8)); }
export function bayesianBernoulli(successes, trials, baseline = .1) {
    if (trials < 5)
        return { successes, trials, baseline, posteriorMean: 0, credibleLow: 0, credibleHigh: 1, bayesFactorApprox: 1, status: 'INSUFFICIENT_DATA' };
    const priorStrength = 2, a0 = baseline * priorStrength, b0 = (1 - baseline) * priorStrength, a = a0 + successes, b = b0 + trials - successes;
    const pm = a / (a + b), lo = betaQuantile(a, b, .025), hi = betaQuantile(a, b, .975);
    const ll1 = successes * Math.log(Math.max(pm, 1e-9)) + (trials - successes) * Math.log(Math.max(1 - pm, 1e-9));
    const ll0 = successes * Math.log(Math.max(baseline, 1e-9)) + (trials - successes) * Math.log(Math.max(1 - baseline, 1e-9));
    const bf = Math.exp(clamp(ll1 - ll0, -30, 30));
    const status = lo > baseline ? 'SUPPORT' : hi < baseline ? 'CONFLICT' : (Math.abs(pm - baseline) < .03 ? 'NEUTRAL' : 'WEAK_SUPPORT');
    return { successes, trials, baseline, posteriorMean: pm, credibleLow: lo, credibleHigh: hi, bayesFactorApprox: bf, status };
}
export function sprt(successes, trials, p0 = .1, p1 = .2, alpha = .05, beta = .1) {
    if (trials < 5)
        return { logLikelihoodRatio: 0, threshold: Math.log((1 - beta) / alpha), decision: 'INSUFFICIENT_DATA', observations: trials };
    const ll = successes * Math.log(p1 / p0) + (trials - successes) * Math.log((1 - p1) / (1 - p0));
    const upper = Math.log((1 - beta) / alpha), lower = Math.log(beta / (1 - alpha));
    return { logLikelihoodRatio: ll, threshold: upper, decision: ll >= upper ? 'H1' : ll <= lower ? 'H0' : 'CONTINUE', observations: trials };
}
function mutualInformation(a, b) {
    if (a.length !== b.length || a.length === 0)
        return 0;
    const joint = new Map();
    const ca = new Map();
    const cb = new Map();
    for (let i = 0; i < a.length; i++) {
        const k = `${a[i]}|${b[i]}`;
        joint.set(k, (joint.get(k) || 0) + 1);
        ca.set(a[i], (ca.get(a[i]) || 0) + 1);
        cb.set(b[i], (cb.get(b[i]) || 0) + 1);
    }
    let r = 0;
    for (const [k, n] of joint) {
        const [x, y] = k.split('|').map(Number);
        const p = n / a.length;
        const px = (ca.get(x) || 0) / a.length;
        const py = (cb.get(y) || 0) / a.length;
        r += p * Math.log2(p / Math.max(px * py, 1e-12));
    }
    return Math.max(0, r);
}
function permutationEntropy(a, order = 3) { if (a.length < order)
    return 0; const c = new Map(); for (let i = 0; i <= a.length - order; i++) {
    const w = a.slice(i, i + order);
    const key = w.map((v, j) => [v, j]).sort((x, y) => x[0] - y[0] || x[1] - y[1]).map(x => x[1]).join('');
    c.set(key, (c.get(key) || 0) + 1);
} return entropy([...c.values()]) / Math.log2(Math.max(2, c.size)); }
export function informationLayer(rows) {
    const digits = rows.flatMap(x => x.split('').map(Number)), a = rows.map(x => Number(x[0])), b = rows.map(x => Number(x[1]));
    const h = entropy(digits), mi12 = mutualInformation(a, b), cond = Math.max(0, entropy(a) - mi12);
    return { entropy: h, conditionalEntropy: cond, mutualInformation: mi12, informationGain: mi12 / Math.max(entropy(a), 1e-9), permutationEntropy: permutationEntropy(digits, 3), sampleSize: rows.length };
}
export function transitionLayer(rows, maxOrder = 3) {
    const out = [];
    for (let order = 1; order <= maxOrder; order++) {
        const counts = new Map();
        let total = 0;
        for (const n of rows) {
            const s = n.split('').map(Number);
            for (let i = order; i < s.length; i++) {
                const from = s.slice(i - order, i).join(''), to = String(s[i]);
                const m = counts.get(from) || new Map();
                m.set(to, (m.get(to) || 0) + 1);
                counts.set(from, m);
                total++;
            }
        }
        let h = 0, maxc = 0;
        for (const m of counts.values()) {
            const t = [...m.values()].reduce((a, b) => a + b, 0);
            for (const v of m.values()) {
                const p = v / t;
                h += (t / Math.max(total, 1)) * (-p * Math.log2(p));
            }
            maxc = Math.max(maxc, Math.max(...m.values()) / t);
        }
        out.push({ order, states: counts.size, transitions: total, entropyRate: h, concentration: maxc });
    }
    return out;
}
export function contextTree(rows, maxDepth = 3) {
    const nodes = [];
    for (let d = 1; d <= maxDepth; d++) {
        const map = new Map();
        for (const n of rows) {
            const s = n.split('');
            for (let i = d; i < s.length; i++) {
                const k = s.slice(i - d, i).join('');
                const a = map.get(k) || [];
                a.push(Number(s[i]));
                map.set(k, a);
            }
        }
        for (const [context, a] of map)
            nodes.push({ context, count: a.length, entropy: entropy(a), depth: d });
    }
    const byDepth = Array.from({ length: maxDepth }, (_, i) => nodes.filter(x => x.depth === i + 1));
    const scores = byDepth.map(ns => ns.length ? mean(ns.map(x => x.count * (Math.log2(10) - x.entropy))) : 0);
    let selectedDepth = scores.length ? scores.indexOf(Math.max(...scores)) + 1 : 1;
    return { maxDepth, nodes: nodes.slice(0, 400), selectedDepth, compressionGain: scores[selectedDepth - 1] || 0 };
}
export function detectChangePoints(values, minSegment = 20) {
    return correctedChangePoints(values, minSegment, 2000, 20261005).map(x => ({ index: x.index, score: x.score, pApprox: x.globalPValue, globalPValue: x.globalPValue, regimeBeforeMean: x.beforeMean, regimeAfterMean: x.afterMean, candidates: x.candidates, simulations: x.simulations }));
}
export function permutationNull(observed, values, stat, simulations = 1000, seed = 20260928) {
    // A permutation of observations cannot test a statistic that is invariant to order
    // (for example, the sample mean). This legacy helper therefore remains only for
    // order-sensitive statistics; group-comparison tests below are used for mean/rate
    // hypotheses.
    if (values.length < 10)
        return { observed, simulations: 0, mean: 0, sd: 0, empiricalP: 1, effectSize: 0 };
    const rand = seedRand(seed), sims = [];
    for (let s = 0; s < simulations; s++) {
        const a = values.slice();
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(rand() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        sims.push(stat(a));
    }
    const m = mean(sims), sd = Math.sqrt(variance(sims)), ge = sims.filter(x => Math.abs(x) >= Math.abs(observed)).length;
    return { observed, simulations, mean: m, sd, empiricalP: (ge + 1) / (simulations + 1), effectSize: sd ? (observed - m) / sd : 0 };
}
export function permutationGroupDifference(values, groupSize, simulations = 1000, seed = 20260928) {
    const n = values.length;
    if (n < 10 || groupSize < 2 || groupSize > n - 2)
        return { observed: 0, simulations: 0, mean: 0, sd: 0, empiricalP: 1, effectSize: 0 };
    const observed = mean(values.slice(0, groupSize)) - mean(values.slice(groupSize));
    const rand = seedRand(seed), sims = [];
    for (let s = 0; s < simulations; s++) {
        const a = values.slice();
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(rand() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        sims.push(mean(a.slice(0, groupSize)) - mean(a.slice(groupSize)));
    }
    const m = mean(sims), sd = Math.sqrt(variance(sims));
    const ge = sims.filter(x => Math.abs(x) >= Math.abs(observed) - 1e-12).length;
    return { observed, simulations, mean: m, sd, effectSize: sd ? (observed - m) / sd : 0, empiricalP: (ge + 1) / (simulations + 1) };
}
export function exactBinomialTwoSided(successes, trials, p0 = .5) {
    if (trials <= 0 || successes < 0 || successes > trials || p0 <= 0 || p0 >= 1)
        return 1;
    const logFact = (n) => { let x = 0; for (let i = 2; i <= n; i++)
        x += Math.log(i); return x; };
    const logProb = (k) => logFact(trials) - logFact(k) - logFact(trials - k) + k * Math.log(p0) + (trials - k) * Math.log(1 - p0);
    const observed = logProb(successes);
    let p = 0;
    for (let k = 0; k <= trials; k++) {
        if (logProb(k) <= observed + 1e-12)
            p += Math.exp(logProb(k));
    }
    return clamp(p);
}
function mutualInformationPValue(rows, simulations = 1000, seed = 20261005) {
    if (rows.length < 10)
        return 1;
    const a = rows.map(x => Number(x[0])), b = rows.map(x => Number(x[1]));
    const observed = mutualInformation(a, b);
    const rand = seedRand(seed);
    let ge = 0;
    for (let s = 0; s < simulations; s++) {
        const perm = b.slice();
        for (let i = perm.length - 1; i > 0; i--) {
            const j = Math.floor(rand() * (i + 1));
            [perm[i], perm[j]] = [perm[j], perm[i]];
        }
        if (mutualInformation(a, perm) >= observed - 1e-12)
            ge++;
    }
    return (ge + 1) / (simulations + 1);
}
export function benjaminiHochberg(items) {
    const s = items.map(x => ({ ...x, pValue: clamp(x.pValue) })).sort((a, b) => a.pValue - b.pValue);
    const n = s.length;
    let running = 1;
    const q = new Array(n);
    for (let i = n - 1; i >= 0; i--) {
        running = Math.min(running, s[i].pValue * n / (i + 1));
        q[i] = running;
    }
    return s.map((x, i) => ({ id: x.id, pValue: x.pValue, qValue: q[i], rejected: q[i] <= .05 }));
}
export function redundancyGraph(series, knownGroups = {}) {
    const keys = Object.keys(series), out = [];
    const corr = (a, b) => { const n = Math.min(a.length, b.length); if (n < 5)
        return 0; const ma = mean(a.slice(0, n)), mb = mean(b.slice(0, n)); let nu = 0, da = 0, db = 0; for (let i = 0; i < n; i++) {
        const x = a[i] - ma, y = b[i] - mb;
        nu += x * y;
        da += x * x;
        db += y * y;
    } return da && db ? nu / Math.sqrt(da * db) : 0; };
    for (let i = 0; i < keys.length; i++)
        for (let j = i + 1; j < keys.length; j++) {
            const c = Math.abs(corr(series[keys[i]], series[keys[j]]));
            if (c >= .85)
                out.push({ a: keys[i], b: keys[j], similarity: c, reason: 'high empirical correlation' });
        }
    for (const [g, members] of Object.entries(knownGroups))
        for (let i = 0; i < members.length; i++)
            for (let j = i + 1; j < members.length; j++)
                if (keys.includes(members[i]) && keys.includes(members[j]))
                    out.push({ a: members[i], b: members[j], similarity: 1, reason: `known mathematical dependency group: ${g}` });
    return out;
}
export function stabilitySurface(values, windows = [50, 100, 250, 500, 1000]) { const base = mean(values); return windows.filter(w => values.length >= w).map(w => { const v = mean(values.slice(-w)); return { window: w, value: v, baseline: base, delta: v - base }; }); }
function hamming(a, b) { let d = 0; for (let i = 0; i < Math.min(a.length, b.length); i++)
    if (a[i] !== b[i])
        d++; return d + Math.abs(a.length - b.length); }
export function motifSearch(query, rows, maxDistance = 1, limit = 10) { return rows.map((match, index) => ({ query, match, distance: hamming(query, match), index })).filter(x => x.distance <= maxDistance).sort((a, b) => a.distance - b.distance || a.index - b.index).slice(0, limit); }
function featureVector(n) { const d = n.split('').map(Number); return [d[0], d[1], d[2], d[3], d.reduce((a, b) => a + b, 0), new Set(d).size, Math.max(...d) - Math.min(...d)]; }
function expr(x, k) { switch (k) {
    case 0: return x;
    case 1: return Math.log1p(x);
    case 2: return Math.sqrt(Math.max(0, x));
    case 3: return x * x;
    case 4: return Math.sin(x / 10);
    default: return 1;
} }
export function symbolicDiscovery(rows) {
    const guard = leakageSafeSymbolicDiscovery(rows.filter(x => /^\d{4}$/.test(x)).map(Number));
    return guard.candidates.map(x => ({ expression: `${x.expression} linear fit`, mse: x.finalTestMse, complexity: x.complexity, trainMse: x.trainMse, testMse: x.finalTestMse, validationMse: x.validationMse, finalTestMse: x.finalTestMse, selected: x.selected }));
}
export function conformalCalibration(values, alpha = .1) {
    const guard = discreteConformal4D(values.map(x => String(Math.round(x)).padStart(4, '0')), alpha);
    return { alpha, coverage: guard.coverage, targetCoverage: guard.targetCoverage, avgSetSize: guard.avgSetSize, violations: guard.violations, calibrated: guard.calibrated, calibrationSize: guard.calibrationSize, testSize: guard.testSize, note: guard.note };
}
export function buildResearchConstitution(sampleSize, oosTests, fdrCount, hasRedundancy, hasNull, hasStability) {
    const gates = { sampleSize: sampleSize >= 30, oos: oosTests >= 10, multipleTesting: fdrCount >= 1, redundancy: hasRedundancy, nullModel: hasNull, stability: hasStability };
    const blockers = [];
    if (!gates.sampleSize)
        blockers.push('Sample size below minimum research threshold.');
    if (!gates.oos)
        blockers.push('Insufficient chronological OOS tests.');
    if (!gates.multipleTesting)
        blockers.push('No multiple-testing correction applied.');
    if (!gates.redundancy)
        blockers.push('Redundancy graph unavailable.');
    if (!gates.nullModel)
        blockers.push('Null-model test unavailable.');
    if (!gates.stability)
        blockers.push('Stability surface unavailable.');
    return { passed: blockers.length === 0, gates, blockers, warnings: ['Passing the constitution is not evidence of predictability; it only means the research process met its declared gates.', 'All inferential discoveries must remain inside the global FDR registry.', 'Final OOS data must remain untouched after signal freeze.'] };
}
export function buildAdvancedResearchReport(rows, featureSeries = {}) {
    const clean = rows.filter(x => /^\d{4}$/.test(x));
    const successes = clean.filter(x => Number(x) % 2 === 0).length;
    const bayesian = { evenRate: bayesianBernoulli(successes, clean.length, .5) };
    const sprts = { evenRate: sprt(successes, clean.length, .5, .6) };
    const info = informationLayer(clean), transitions = transitionLayer(clean), tree = contextTree(clean), cps = detectChangePoints(clean.map(Number));
    const spectralSignificance = spectralPeakSignificance(clean.map(Number), 1500, 20261007);
    const recentN = Math.max(10, Math.min(clean.length, Math.floor(clean.length * .2)));
    const recentBaseline = permutationGroupDifference(clean.map(Number), recentN, 1000, 20261005);
    const nullTests = { recentBaseline };
    const fdrCandidates = [
        { id: 'even-rate', pValue: exactBinomialTwoSided(successes, clean.length, .5) },
        { id: 'position-1-2-mutual-information', pValue: mutualInformationPValue(clean, 1000, 20261006) },
        ...(cps[0]?.globalPValue !== undefined ? [{ id: 'change-point-max-stat', pValue: cps[0].globalPValue }] : []),
        ...(spectralSignificance ? [{ id: 'spectral-max-peak', pValue: spectralSignificance.globalPValue }] : [])
    ];
    // Each boolean mathematical feature gets a real recent-vs-baseline randomization
    // p-value. Numeric features are deliberately excluded because their null model
    // requires a different scientific hypothesis than a binary occurrence-rate test.
    for (let i = 0; i < MATH_PROPERTY_CATALOG.length; i++) {
        const def = MATH_PROPERTY_CATALOG[i];
        if (['digitalRoot', 'digitSum', 'tau', 'sigma', 'phi', 'mobius'].includes(def.id))
            continue;
        const vals = clean.map(n => classify4D(n).properties[def.id] === true ? 1 : 0);
        if (vals.length >= 10 && recentN >= 5 && vals.length - recentN >= 5) {
            const test = permutationGroupDifference(vals, recentN, 500, 20262000 + i);
            fdrCandidates.push({ id: `math:${def.id}:recent-vs-baseline`, pValue: test.empiricalP });
        }
    }
    const fdr = benjaminiHochberg(fdrCandidates);
    // Global FDR family: every inferential hypothesis generated by this report is registered once.
    // This prevents silently treating each window/property as an independent discovery family.
    const globalHypotheses = fdrCandidates.map(x => ({ id: x.id, family: 'advanced-research-global', pValue: x.pValue, source: 'buildAdvancedResearchReport', description: x.id }));
    const globalFdr = globalBenjaminiHochberg(globalHypotheses, .05);
    const redundancy = redundancyGraph(featureSeries, { mod9: ['digit-sum', 'digital-root', 'mod-9', 'divisible-by-9'] });
    const stability = { numericMean: stabilitySurface(clean.map(Number)) };
    const motifs = clean.length ? motifSearch(clean[0], clean, 1, 8) : [];
    const symbolic = symbolicDiscovery(clean), conformal = conformalCalibration(clean.map(Number));
    const evidence = [
        { id: 'bayes', label: 'Bayesian evidence', support: bayesian.evenRate.posteriorMean, uncertainty: bayesian.evenRate.credibleHigh - bayesian.evenRate.credibleLow, redundancyPenalty: 0, status: bayesian.evenRate.status, reason: 'Posterior rate compared with explicit baseline.' },
        { id: 'information', label: 'Information theory', support: clamp(info.mutualInformation / Math.log2(10)), uncertainty: clean.length < 100 ? .5 : .2, redundancyPenalty: 0, status: clean.length < 30 ? 'INSUFFICIENT_DATA' : 'WEAK_SUPPORT', reason: 'Mutual information is descriptive and requires OOS confirmation.' },
        { id: 'null', label: 'Null-model laboratory', support: clamp(Math.abs(nullTests.recentBaseline.effectSize) / 3), uncertainty: nullTests.recentBaseline.sd ? 1 / Math.max(1, Math.abs(nullTests.recentBaseline.effectSize)) : 1, redundancyPenalty: 0, status: nullTests.recentBaseline.empiricalP < .05 ? 'SUPPORT' : 'NEUTRAL', reason: 'Observed statistic compared with shuffled historical sequences.' },
    ];
    const metaRaw = Object.fromEntries(evidence.map(e => [e.id, e.support / (1 + e.uncertainty + e.redundancyPenalty)]));
    const total = Object.values(metaRaw).reduce((a, b) => a + b, 0) || 1;
    const metaWeights = Object.fromEntries(Object.entries(metaRaw).map(([k, v]) => [k, v / total]));
    const constitution = buildResearchConstitution(clean.length, Math.max(0, clean.length - 20), fdr.length, redundancy.length > 0, true, stability.numericMean.length > 0);
    return { version: 'research-lab-v3', sampleSize: clean.length, evidence, bayesian, sprt: sprts, information: info, transitions, contextTree: tree, changePoints: cps, spectralSignificance, nullTests, fdr, globalFdr, redundancy, stability, motifs, symbolic, conformal, constitution, metaWeights };
}
