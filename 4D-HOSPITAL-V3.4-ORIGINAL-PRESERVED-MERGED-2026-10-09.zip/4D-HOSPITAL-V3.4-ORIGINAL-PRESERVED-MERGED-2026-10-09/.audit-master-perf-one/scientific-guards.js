const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const mean = (a) => a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0;
const variance = (a) => { if (a.length < 2)
    return 0; const m = mean(a); return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1); };
function rng(seed) { let s = seed >>> 0; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; }
function shuffle(a, r) { const x = [...a]; for (let i = x.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [x[i], x[j]] = [x[j], x[i]];
} return x; }
export function normalCdf(z) {
    const s = z < 0 ? -1 : 1, x = Math.abs(z) / Math.sqrt(2);
    let t = 1 / (1 + 0.3275911 * x);
    const poly = ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t;
    const erf = 1 - poly * Math.exp(-x * x);
    return .5 * (1 + s * erf);
}
function logGamma(z) {
    const p = [676.5203681218851, -1259.1392167224028, 771.3234287776531, -176.6150291621406, 12.5073432786869, -.1385710952657, 9.98436957801957e-6, 1.50563273514931e-7];
    if (z < .5)
        return Math.log(Math.PI) - Math.log(Math.sin(Math.PI * z)) - logGamma(1 - z);
    let x = .9999999999998099, t = z - 1;
    for (let i = 0; i < p.length; i++)
        x += p[i] / (t + i + 1);
    const q = t + p.length - .5;
    return .5 * Math.log(2 * Math.PI) + (t + .5) * Math.log(q) - q + Math.log(x);
}
function gammaP(a, x) {
    if (x <= 0)
        return 0;
    if (x < a + 1) {
        let ap = a, sum = 1 / a, del = sum;
        for (let n = 1; n < 300; n++) {
            ap++;
            del *= x / ap;
            sum += del;
            if (Math.abs(del) < Math.abs(sum) * 1e-13)
                break;
        }
        return clamp(sum * Math.exp(-x + a * Math.log(x) - logGamma(a)));
    }
    let b = x + 1 - a, c = 1e300, d = 1 / b, h = d;
    for (let i = 1; i < 300; i++) {
        const an = -i * (i - a);
        b += 2;
        d = an * d + b;
        if (Math.abs(d) < 1e-300)
            d = 1e-300;
        c = b + an / c;
        if (Math.abs(c) < 1e-300)
            c = 1e-300;
        d = 1 / d;
        const del = d * c;
        h *= del;
        if (Math.abs(del - 1) < 1e-13)
            break;
    }
    return clamp(1 - Math.exp(-x + a * Math.log(x) - logGamma(a)) * h);
}
export function chiSquarePValue(stat, df) { return clamp(1 - gammaP(df / 2, stat / 2)); }
export function sparseContingencyTest(table, simulations = 5000, seed = 20261005) {
    const rows = table.length, cols = table[0]?.length ?? 0, total = table.flat().reduce((a, b) => a + b, 0);
    if (!rows || !cols || !total)
        return { statistic: 0, pValue: 1, method: 'CHI_SQUARE', minExpected: 0, sparseCells: 0, simulations: 0 };
    const rowS = table.map(r => r.reduce((a, b) => a + b, 0)), colS = Array(cols).fill(0);
    for (const r of table)
        for (let j = 0; j < cols; j++)
            colS[j] += r[j];
    let stat = 0, minExpected = Infinity, sparseCells = 0;
    for (let i = 0; i < rows; i++)
        for (let j = 0; j < cols; j++) {
            const e = rowS[i] * colS[j] / total;
            minExpected = Math.min(minExpected, e);
            if (e < 5)
                sparseCells++;
            if (e > 0)
                stat += (table[i][j] - e) ** 2 / e;
        }
    if (sparseCells === 0)
        return { statistic: stat, pValue: chiSquarePValue(stat, (rows - 1) * (cols - 1)), method: 'CHI_SQUARE', minExpected, sparseCells, simulations: 0 };
    // Fixed margins Monte Carlo via random permutation of column labels. This preserves both margins.
    const a = [], b = [];
    for (let i = 0; i < rows; i++)
        for (let j = 0; j < cols; j++)
            for (let k = 0; k < table[i][j]; k++) {
                a.push(i);
                b.push(j);
            }
    const r = rng(seed), observed = stat;
    let ge = 0;
    for (let s = 0; s < simulations; s++) {
        const pb = shuffle(b, r), counts = Array.from({ length: rows }, () => Array(cols).fill(0));
        for (let k = 0; k < a.length; k++)
            counts[a[k]][pb[k]]++;
        let st = 0;
        for (let i = 0; i < rows; i++)
            for (let j = 0; j < cols; j++) {
                const e = rowS[i] * colS[j] / total;
                if (e > 0)
                    st += (counts[i][j] - e) ** 2 / e;
            }
        if (st >= observed - 1e-12)
            ge++;
    }
    return { statistic: stat, pValue: (ge + 1) / (simulations + 1), method: 'MONTE_CARLO_PERMUTATION', minExpected, sparseCells, simulations };
}
export function ljungBox(values, maxLag = 12) {
    const n = values.length;
    if (n < maxLag + 5)
        return { statistic: 0, df: 0, pValue: 1, lags: 0 };
    const m = mean(values);
    const den = values.reduce((s, x) => s + (x - m) ** 2, 0);
    if (!den)
        return { statistic: 0, df: maxLag, pValue: 1, lags: maxLag };
    const k = Math.min(maxLag, n - 2);
    let q = 0;
    for (let lag = 1; lag <= k; lag++) {
        let num = 0;
        for (let i = lag; i < n; i++)
            num += (values[i] - m) * (values[i - lag] - m);
        const rho = num / den;
        q += rho * rho / (n - lag);
    }
    q *= n * (n + 2);
    return { statistic: q, df: k, pValue: chiSquarePValue(q, k), lags: k };
}
export function runsTestBinary(values) {
    const b = values.map(x => x ? 1 : 0), n = b.length, n1 = b.filter(Boolean).length, n0 = n - n1;
    if (n < 10 || n1 === 0 || n0 === 0)
        return { runs: 0, expected: 0, z: 0, pValue: 1, valid: false };
    let runs = 1;
    for (let i = 1; i < n; i++)
        if (b[i] !== b[i - 1])
            runs++;
    const expected = 1 + 2 * n1 * n0 / n;
    const variance = 2 * n1 * n0 * (2 * n1 * n0 - n) / (n * n * (n - 1));
    const z = (runs - expected) / Math.sqrt(Math.max(variance, 1e-12));
    return { runs, expected, z, pValue: 2 * (1 - normalCdf(Math.abs(z))), valid: true };
}
export function percentileBootstrap(values, stat = (x) => mean(x), simulations = 4000, seed = 20261005) {
    if (!values.length)
        return { estimate: 0, lower: 0, upper: 0, method: 'PERCENTILE_BOOTSTRAP', simulations: 0 };
    const r = rng(seed), s = [];
    for (let i = 0; i < simulations; i++) {
        const sample = Array.from({ length: values.length }, () => values[Math.floor(r() * values.length)]);
        s.push(stat(sample));
    }
    s.sort((a, b) => a - b);
    const q = (p) => s[Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))];
    return { estimate: stat(values), lower: q(.025), upper: q(.975), method: 'PERCENTILE_BOOTSTRAP', simulations };
}
export function correctedChangePoints(values, minSegment = 20, simulations = 2000, seed = 20261005) {
    const n = values.length;
    if (n < minSegment * 2)
        return [];
    const step = Math.max(1, Math.floor(n / 100)), candidates = [];
    for (let i = minSegment; i <= n - minSegment; i += step)
        candidates.push(i);
    const scoreAt = (a, i) => { const l = a.slice(0, i), r = a.slice(i), se = Math.sqrt(variance(l) / l.length + variance(r) / r.length + 1e-12); return se ? Math.abs(mean(l) - mean(r)) / se : 0; };
    const scores = candidates.map(index => ({ index, score: scoreAt(values, index) }));
    const maxObserved = Math.max(...scores.map(x => x.score));
    const rr = rng(seed);
    let ge = 0;
    for (let s = 0; s < simulations; s++) {
        const p = shuffle(values, rr);
        let mx = 0;
        for (const i of candidates)
            mx = Math.max(mx, scoreAt(p, i));
        if (mx >= maxObserved - 1e-12)
            ge++;
    }
    const globalP = (ge + 1) / (simulations + 1);
    return scores.filter(x => x.score >= 2).sort((a, b) => b.score - a.score).slice(0, 10).map(x => ({ index: x.index, score: x.score, globalPValue: globalP, beforeMean: mean(values.slice(0, x.index)), afterMean: mean(values.slice(x.index)), candidates: candidates.length, simulations }));
}
export function spectralPeakSignificance(values, simulations = 2000, seed = 20261005) {
    const originalN = values.length;
    if (originalN < 16)
        return null;
    const maxN = 512, stride = Math.max(1, Math.ceil(originalN / maxN)), sampled = originalN > maxN ? values.filter((_, i) => i % stride === 0).slice(0, maxN) : values.slice();
    const n = sampled.length, m = mean(sampled), center = sampled.map(x => x - m), B = originalN > maxN ? Math.min(simulations, 100) : Math.min(simulations, 500);
    const powerAt = (a, k) => { let re = 0, im = 0; for (let t = 0; t < n; t++) {
        const q = 2 * Math.PI * k * t / n;
        re += a[t] * Math.cos(q);
        im -= a[t] * Math.sin(q);
    } return (re * re + im * im) / n; };
    const ks = Array.from({ length: Math.floor(n / 2) }, (_, i) => i + 1);
    const powers = ks.map(k => powerAt(center, k));
    let best = 0;
    for (let i = 1; i < powers.length; i++)
        if (powers[i] > powers[best])
            best = i;
    const observed = powers[best], rr = rng(seed);
    let ge = 0;
    for (let s = 0; s < B; s++) {
        const p = shuffle(center, rr);
        let mx = 0;
        for (const k of ks)
            mx = Math.max(mx, powerAt(p, k));
        if (mx >= observed - 1e-12)
            ge++;
    }
    return { frequency: ks[best] / n, power: observed, globalPValue: (ge + 1) / (B + 1), simulations: B, testedPeaks: ks.length };
}
export function globalBenjaminiHochberg(items, alpha = .05) { const clean = items.filter(x => Number.isFinite(x.pValue)).map(x => ({ ...x, pValue: clamp(x.pValue) })); const s = [...clean].sort((a, b) => a.pValue - b.pValue); const q = Array(s.length); let running = 1; for (let i = s.length - 1; i >= 0; i--) {
    running = Math.min(running, s[i].pValue * s.length / (i + 1));
    q[i] = running;
} return s.map((x, i) => ({ ...x, qValue: q[i], rejected: q[i] <= alpha })); }
function fitLinear(y) { const x = y.map((_, i) => i), mx = mean(x), my = mean(y), vx = variance(x); let cov = 0; for (let i = 0; i < y.length; i++)
    cov += (x[i] - mx) * (y[i] - my) / (Math.max(1, y.length - 1)); const slope = vx ? cov / vx : 0, inter = my - slope * mx; return { inter, slope }; }
function mse(y, start, model) { return mean(y.map((v, i) => (v - (model.inter + model.slope * (start + i))) ** 2)); }
export function leakageSafeSymbolicDiscovery(values) {
    const n = values.length;
    if (n < 45)
        return { candidates: [], selected: null, finalTestMse: null, trainSize: 0, validationSize: 0, finalTestSize: 0, frozen: false };
    const trainSize = Math.floor(n * .6), validationSize = Math.floor(n * .2), train = values.slice(0, trainSize), validation = values.slice(trainSize, trainSize + validationSize), test = values.slice(trainSize + validationSize);
    const transforms = [['linear', 1], ['quadratic', 2], ['sqrt', 3], ['log', 4], ['sin', 5]];
    const models = transforms.map(([name, k]) => { let model; if (k === 1)
        model = fitLinear(train);
    else {
        const x = train.map((_, i) => k === 2 ? i * i : k === 3 ? Math.sqrt(i) : k === 4 ? Math.log1p(i) : Math.sin(i / 10));
        const y = train;
        const mx = mean(x), my = mean(y), vx = variance(x);
        let cov = 0;
        for (let i = 0; i < y.length; i++)
            cov += (x[i] - mx) * (y[i] - my) / Math.max(1, y.length - 1);
        const slope = vx ? cov / vx : 0;
        model = { slope, inter: my - slope * mx };
    } const pred = (arr, offset) => mean(arr.map((v, j) => { const i = offset + j; const x = k === 1 ? i : k === 2 ? i * i : k === 3 ? Math.sqrt(i) : k === 4 ? Math.log1p(i) : Math.sin(i / 10); return (v - (model.inter + model.slope * x)) ** 2; })); return { expression: `${name} linear fit`, name, complexity: k, trainMse: pred(train, 0), validationMse: pred(validation, trainSize), finalTestMse: pred(test, trainSize + validationSize) }; });
    const ordered = [...models].sort((a, b) => a.validationMse - b.validationMse || a.complexity - b.complexity), selected = ordered[0];
    return { candidates: models.map(x => ({ ...x, selected: x.name === selected.name })), selected: selected.name, finalTestMse: selected.finalTestMse, trainSize, validationSize, finalTestSize: test.length, frozen: true };
}
export function discreteConformal4D(values, alpha = .1) {
    const nums = values.filter(x => /^\d{4}$/.test(x)).map(Number);
    if (nums.length < 60)
        return { coverage: 0, targetCoverage: 1 - alpha, avgSetSize: 0, violations: 0, calibrated: false, calibrationSize: 0, testSize: 0, note: 'Need >=60 valid observations for train/calibration/test split.' };
    const trainEnd = Math.floor(nums.length * .5), calEnd = Math.floor(nums.length * .75), train = nums.slice(0, trainEnd), cal = nums.slice(trainEnd, calEnd), test = nums.slice(calEnd);
    const center = mean(train), scores = cal.map(x => Math.abs(x - center)).sort((a, b) => a - b);
    const q = scores[Math.min(scores.length - 1, Math.ceil((1 - alpha) * (scores.length + 1)) - 1)];
    let covered = 0;
    for (const x of test)
        if (Math.abs(x - center) <= q)
            covered++;
    const coverage = covered / Math.max(1, test.length);
    return { coverage, targetCoverage: 1 - alpha, avgSetSize: 2 * q + 1, violations: test.length - covered, calibrated: coverage + 0.05 >= 1 - alpha, calibrationSize: cal.length, testSize: test.length, note: 'Discrete scalar interval over 0000–9999; coverage is empirical, not a guarantee.' };
}
