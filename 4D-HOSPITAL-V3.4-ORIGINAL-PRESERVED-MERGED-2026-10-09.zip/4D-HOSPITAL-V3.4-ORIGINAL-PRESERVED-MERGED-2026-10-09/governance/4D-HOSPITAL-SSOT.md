# 4D HOSPITAL — SSOT v1.6

## Canonical architecture
DATA → 107 ANALYSES → 107 VISUAL ANALYSES → 11 PART RESULTS → 28 SIGNAL MODULES → MATHEMATICAL → INVESTIGATOR → ADVANCED → SENSOR/EVIDENCE FUSION → MASTER RESULT SHEET.

## Public analysis boundary
Exactly 107 public analyses. Exactly 11 Parts with locked ranges:
- P01 01–18
- P02 19–25
- P03 26–37
- P04 38–51
- P05 52–70
- P06 71–75
- P07 76–88
- P08 89–94
- P09 95–98
- P10 99–103
- P11 104–107

## Visual workflow
Each Part exposes exactly four named workflow pages:
1. WHAT / মূল বিশ্লেষণ
2. WHY / কেন পরিবর্তন হলো
3. NEXT / পরবর্তীতে কীভাবে পরিবর্তন হতে পারে
4. FINAL / চূড়ান্ত বিশ্লেষণ ফলাফল

11 × 4 = 44 workflow surfaces; 107 × 4 = 428 analysis-page instances.

## Evidence/status rules
UNKNOWN ≠ PASS. UNTESTED ≠ PASS. IMPLEMENTED ≠ VERIFIED. DOCUMENTED ≠ IMPLEMENTED.
Permitted states: PLANNED, IN_PROGRESS, IMPLEMENTED, TESTED, PASS, PARTIAL_PASS, FAILED, BLOCKED, NOT_VERIFIED, NOT_APPLICABLE.

## Research boundary
Historical analysis is not a guarantee of a future outcome. 5D in the Master Result Sheet is a derived composite research signal, not an observed historical 5-digit source.

## Visual reference policy
The three supplied reference images are stored under `public/design-reference/` as design references. They guide layout, density, dark analytical styling and chart-card language; they are not presented as measured data or copied as application output.
