# 4D HOSPITAL — Master Result Performance Gate

The release gate now runs the real Master Result engine in isolated Node processes at 1,000 / 5,000 / 10,000 canonical historical rows. Each target must produce the complete 5D/4D/3D/2D/1D contract and 10 research bundles within the CI budget.

Budgets: 1k ≤ 60s, 5k ≤ 120s, 10k ≤ 180s.

This is a full engine/CI performance gate, not an Android-device certification. Android device performance remains a separate runtime concern.
