# 4D HOSPITAL — Android build ও release verification

## Canonical release path

এই source ZIP-এ generated `android/` project intentionally রাখা হয়নি। Release build-এর authoritative path হলো GitHub Actions-এর:

`.github/workflows/build-and-validate.yml`

এই current source bundle-এ genuine `package-lock.json` আছে। Canonical `build-and-validate.yml` সেটির exact version/integrity audit করে একই artifact হিসেবে validation/performance/Android jobs-এ hand-off করে `npm ci` চালায়। Lockfile অনুপস্থিত হলে আলাদা `Bootstrap package-lock.json` recovery workflow চালিয়ে generated lockfile commit করতে হবে; canonical workflow নিজে lockfile তৈরি করে না.

Canonical sequence:

```text
npm ci
→ npm run typecheck
→ npm run validate
→ npm run build
→ npx cap add android
→ npx cap sync android
→ Android wrapper / configuration audit
→ ./gradlew assembleDebug
→ APK ZIP integrity + SHA-256
→ API 35 emulator install
→ app launch + PID/process check
```

## Local/manual development

Networked development environment-এ genuine lockfile committed থাকার পরে:

```bash
npm ci
npm run validate
npm run build
npx cap add android
npx cap sync android
```

তারপর Android Studio দিয়ে generated `android/` project খোলা যেতে পারে। এটি development convenience; **final release certification-এর authoritative gate হলো canonical GitHub workflow**।

## Important boundaries

- `android/` generated platform directory; source ZIP-এ intentionally vendored নয়।
- Android SDK/Gradle/emulator এই source-only environment-এ locally certified নয়।
- Native Android Keystore bridge CI build-এর সময় generated/install হয় এবং final APK-তে বাস্তবে execute হওয়া আবশ্যক।
- OCR online-only: internet থাকলে Tesseract.js CDN থেকে engine load হবে; offline অবস্থায় Manual/Paste data entry ব্যবহার করতে হবে।
