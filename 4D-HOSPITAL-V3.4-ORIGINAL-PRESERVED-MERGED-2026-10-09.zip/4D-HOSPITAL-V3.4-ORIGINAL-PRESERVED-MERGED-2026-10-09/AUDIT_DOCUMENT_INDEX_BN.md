# 4D HOSPITAL — Audit Document Index (বাংলা)

## বর্তমান সিদ্ধান্তের জন্য এই ফাইলগুলো ব্যবহার করুন

1. `README.md` — বর্তমান app scope, offline/storage সীমা ও GitHub build নির্দেশনা।
2. `RELEASE_GATE_REPORT_V3.3_BN.md` — সর্বশেষ A-to-Z source review, সংশোধন, PASS এবং BLOCKED release gates।
3. `SECURITY.md` এবং `4D-HOSPITAL-STORAGE.md` — local authentication, storage ও backup সীমা।
4. `ANDROID_BUILD_BN.md` — Android build ও OCR সীমা।
5. `.github/workflows/build-and-validate.yml` — canonical end-to-end validation/APK workflow।

## পুরোনো রিপোর্ট সম্পর্কে

Root directory-তে আগের সংস্করণগুলোর audit, repair, completion, release-readiness এবং status রিপোর্ট রাখা হয়েছে, যাতে কাজের ইতিহাস হারিয়ে না যায়। সেগুলোর কিছুতে তখনকার package-lock, build বা UI অবস্থা বর্ণিত আছে; সেগুলো **বর্তমান V3.3 source-এর verdict নয়**। সর্বশেষ সিদ্ধান্তের জন্য শুধু `RELEASE_GATE_REPORT_V3.3_BN.md`-এর PASS/BLOCKED বিভাগ অনুসরণ করুন।

`HISTORICAL_RELEASE_GATE_REPORT_V3.2_BN.md` বিশেষভাবে V3.2 snapshot হিসেবে চিহ্নিত।

## Release certification boundary

Static/source audit PASS মানে সংশ্লিষ্ট source checks পাস করেছে। এটি `npm ci`, Vite production build, Gradle APK build, APK SHA-256 verification বা Android emulator launch PASS হওয়ার সমান নয়। এসব external build gates canonical GitHub Actions workflow-এ বাস্তবে PASS হওয়া প্রয়োজন।
