# 4D HOSPITAL — Current Source Layout

এই release-এ root directory-ই একমাত্র canonical application source tree।

- `App.tsx` — main application shell
- `main.tsx` — Vite entry point
- `lib/` — analysis, storage, validation and research engines
- `components/` — UI components
- `hooks/` — React hooks
- `pages/` — page components
- `types/` — shared types
- `public/` — static assets

পুরনো audit/history documents-এ `src/...` path দেখা গেলে সেগুলো historical notes হিসেবে গণ্য হবে; current runtime source path নয়।
