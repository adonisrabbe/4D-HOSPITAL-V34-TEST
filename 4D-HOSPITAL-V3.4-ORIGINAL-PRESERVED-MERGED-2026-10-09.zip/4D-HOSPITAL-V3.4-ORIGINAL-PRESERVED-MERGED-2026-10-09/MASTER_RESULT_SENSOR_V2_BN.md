# 4D HOSPITAL — Master Result Sensor System V2

## Final result contract

The Master Result Sheet is the **research aggregation endpoint**, not a standalone predictor.

Pipeline:

`DATA → 107 ANALYSES → 11 PARTS → 28 SIGNAL MODULES → MATHEMATICAL → INVESTIGATOR → ADVANCED / SCIENTIFIC / VALIDATION → SENSOR EVIDENCE FUSION → MASTER RESULT`

## Required result counts

- **5D:** 5 sets
- **4D:** 4 sets
- **3D:** 4 sets
- **2D:** 4 sets
- **1D:** 4 sets
- **Total:** 21 candidate sets

## HOT / COLD

Every level is presented through two visible evidence lanes:

- HOT — stronger/recently active historical signal according to the implemented evidence ranking.
- COLD — lower/recently absent historical signal according to the implemented evidence ranking.

COLD does **not** mean that a reversal is expected.

## Candidate metadata

Each Master candidate carries:

- evidence score
- HOT/COLD band
- consensus count across the 28 signal families
- conflict count
- source/provenance
- historical count where applicable
- dataset fingerprint
- calculation version
- fusion version
- evidence state
- research boundary warning

## 5D rule

Historical 5D observations are not assumed. A 5D candidate is a **derived composite** constructed only from observed 4D candidates plus observed digit evidence. No arbitrary 5D number is injected.

## Sensor-health layer

Before displaying the final candidates, the UI exposes the health of the fusion layers:

- 107 Core
- 28 Signal Sensor
- Mathematical
- Investigator
- Advanced Research / FDR
- Scientific Process Control

Each layer is shown as READY / LIMITED / BLOCKED.

## Research integrity

The Master Result does not claim guaranteed future outcomes or winning probability. If evidence is insufficient or conflicting, the uncertainty remains visible.

`IMPLEMENTED ≠ VERIFIED` and `VERIFIED ≠ SCIENTIFICALLY PROVEN`.
