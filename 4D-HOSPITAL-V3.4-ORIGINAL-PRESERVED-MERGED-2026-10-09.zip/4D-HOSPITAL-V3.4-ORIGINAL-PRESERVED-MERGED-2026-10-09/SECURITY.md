# Security Policy — 4D HOSPITAL

## Scope

4D HOSPITAL is an offline-first numerical research application. Local authentication, encrypted local storage, encrypted backups, and Android packaging are security boundaries, but they are **not equivalent to a server-side identity provider**.

## Reporting a vulnerability

Please do not publish credentials, private datasets, patient data, tokens, or exploit details in a public issue. Report privately through the repository's configured private vulnerability-reporting channel when enabled.

If private reporting is unavailable, open a minimal public issue containing only a non-sensitive description and request a private contact path.

## Security expectations

- Never commit secrets, signing keys, passwords, production datasets, or tokens.
- Do not treat client-side authentication as trusted remote authorization.
- Keep dependencies pinned and review Dependabot updates.
- Run CodeQL and the project security audits before release.
- Release builds should be signed outside source control; signing material must never be stored in the repository.
- Medical/patient data must not be placed into this numerical research product without a separate clinical/privacy/security review.

## Supported release principle

A release is not considered security-certified merely because automated audits pass. Device hardening, dependency review, penetration testing, and operational controls remain required for high-risk deployments.
