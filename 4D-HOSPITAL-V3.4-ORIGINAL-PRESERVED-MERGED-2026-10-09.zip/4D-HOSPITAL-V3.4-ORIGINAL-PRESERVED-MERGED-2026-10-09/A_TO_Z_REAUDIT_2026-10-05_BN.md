> **Historical snapshot — superseded for current release instructions.** This file records an earlier project state. For the current lockfile, workflow, and release-gate status, use `CURRENT_RELEASE_TRUTH_BN.md` and `RELEASE_GATE_REPORT_V3.2_BN.md`.

# 4D HOSPITAL — A→Z Fresh Forensic Re-Audit

Date: 2026-10-05
Scope: extracted final release source, fresh source inspection, regression tests, security/storage boundaries, research contracts, benchmark manifest, GitHub/Android workflow.

## Executive result

The source bundle passed all available network-independent application/research/security regression gates after the latest repairs.

### Repairs found during this fresh pass

1. Unified calendar-date validation across App import/restore paths, SQLite restore/upsert/sync, and research observations using `isValidISODate`.
2. Prevented impossible dates such as `2026-02-31` from entering through non-UI import/storage paths.
3. Added managed-user ID generation that avoids timestamp-only collision risk.
4. Added last-active-admin protection: the final active admin cannot be disabled, demoted, or deleted.
5. Aligned user-creation UI with the backend's minimum 10-character password policy.
6. Added A→Z regression guards so these defects cannot silently return.

## Fresh regression results

- 64/64 mathematical known-value cases: PASS
- 107/107 public analysis execution: PASS
- 59 global FDR hypotheses: PASS
- Research Cycle E2E: PASS
- Research inventory: PASS
- Research layers: PASS
- Stability hardening: PASS
- Mathematical research audit: PASS
- Advanced research audit: PASS
- Investigator audit: PASS
- Scientific-gap regression: PASS
- GitHub/Android workflow audit: PASS
- Benchmark manifest: PASS (5 deterministic datasets)
- Production integrity: PASS
- A→Z final regression: PASS
- Canonical calendar behaviour: PASS (leap-year and invalid-date cases)

## Security/storage checks

- SQLite encryption configuration: PASS
- Encrypted backup: PASS
- IndexedDB transaction/durability path: PASS
- Remote OCR CDN dependency: blocked/absent
- CSP present
- Local font bundled
- Duplicate `src/` runtime tree absent
- Local admin authorization uses in-memory session, not sessionStorage as the authority
- Password hashing uses PBKDF2/SHA-256 with cryptographic salts
- Invite tokens use `crypto.randomUUID`

## Scientific safeguards

- No fake 0.5 backtest fallback
- No cross-company proxy inside protected scorer
- No predictive-certainty API
- Chronological/OOS governance remains in place
- Global FDR remains active
- Research Constitution / evidence gates remain active
- Blind OOS / signal-freeze architecture remains documented
- 107 public entries remain a catalog of analyses, not 107 independently proven predictive models

## Important release limitation

`package-lock.json` is intentionally not fabricated in this bundle. The current sandbox could not resolve the npm registry reliably enough to generate a trustworthy lockfile.

Therefore the final GitHub release workflow deliberately requires a committed canonical `package-lock.json` and runs `npm ci`. The one-time bootstrap workflow generates that lockfile on GitHub; it must then be committed before a reproducible release build is accepted.

Likewise, a real Android APK/emulator build cannot be honestly certified inside this sandbox without the required Android SDK/Gradle environment. The GitHub workflow contains the actual Android build, APK integrity, and emulator smoke-test gates.

## Honest release status

**Source/research/security architecture:** PASS under available offline audits.

**Deterministic dependency installation:** BLOCKED until canonical `package-lock.json` is committed.

**Actual GitHub Android APK:** NOT CERTIFIED here; must pass the GitHub Actions release workflow.

This report intentionally does not label those two environment-dependent items as PASS.
