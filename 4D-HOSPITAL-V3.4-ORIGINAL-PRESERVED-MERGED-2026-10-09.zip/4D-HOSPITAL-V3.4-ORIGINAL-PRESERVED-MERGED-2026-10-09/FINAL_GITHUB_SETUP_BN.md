# 4D HOSPITAL — FINAL GITHUB → ANDROID SETUP

এই নথিটিই final setup-এর authoritative handoff.

## 0. বর্তমান release truth

Source/research/security architecture: source-level audits PASS; বিস্তারিত `RELEASE_GATE_REPORT_V3.2_BN.md`-এ।

Release build: **GitHub Actions-এ সম্পূর্ণ build ও emulator gate configured, কিন্তু এখনো real runner-এ PASS প্রমাণিত নয়।**

বর্তমান source bundle-এ genuine `package-lock.json` v3 আছে। Canonical workflow lockfile যাচাই করে একই artifact validation/performance/Android jobs-এ hand-off করে। এই sandbox-এ registry DNS `EAI_AGAIN`, তাই `npm ci`, TypeScript typecheck, Vite build, APK build ও emulator launch এখানে সম্পন্ন হয়নি।

## 1. GitHub repository-তে source upload/commit

সব source file repository root-এ রাখুন। `package.json`, `.github/workflows/`, `scripts/`, `lib/`, `components/`, `App.tsx` অবশ্যই থাকবে।

## 2. Genuine lockfile

বর্তমান ZIP-এ `package-lock.json` আছে; Windows-এ আলাদা করে lockfile বানাতে হবে না। Canonical workflow এটি verify করে `npm ci` চালাবে।

যদি কোনো কারণে lockfile অনুপস্থিত থাকে, **Bootstrap package-lock.json** নামে আলাদা manual recovery workflow চালিয়ে lockfile commit করুন; তারপর canonical workflow চালান। Canonical build workflow নিজে lockfile তৈরি বা commit করে না।

## 3. Canonical validation/build

GitHub Actions → **4D HOSPITAL - Validate and Build Android APK** → Run workflow.

Pipeline:

`npm ci → typecheck → research validation → release readiness → Vite build → Capacitor → Android/Gradle → APK integrity → emulator smoke`

## 4. APK

Successful run-এর `4D-HOSPITAL-debug-APK` artifact থেকে `app-debug.apk` নিন।

## 5. Data entry — প্রথম ব্যবহার

App → **Screenshot OCR / Data Entry / Live Results / Data Vault**.

Manual/Paste entry ব্যবহার করে company, date, first, second, third, optional special/consolation দিন। Validate করে Save করুন।

Bulk historical data-এর জন্য Data Vault → Old Data Migration / Import ব্যবহার করুন। Existing data overwrite না করে conflict আলাদা করে রাখা হয়।

Encrypted backup: Data Vault → Backup. Restore করতে একই backup password প্রয়োজন।

## 6. Analysis flow

`Data → Canonical Dataset → 107 Analysis → Visual Dashboard → Detail → Deep Research → Functional Analysis → Validation/OOS → Report`

Visual dashboard-এর 12টি tile একই repeated bar-chart নয়; প্রতিটির motif আলাদা।

## 7. Important non-claims

- 99.9% future winning probability software নিজে থেকে দাবি করবে না।
- Visual confidence/index বাস্তব winning probability নয়।
- 1M stress result synthetic harness; এটি full 107-analysis Android certification নয়।
- Android Keystore/native bridge এবং OCR-এর real-device behaviour final APK/emulator test-এ verify করতে হবে।
- Browser/source-only audit সফল হওয়া APK certification-এর সমান নয়।

## 8. OCR

OCR এখন **online-only**। Internet থাকলে Screenshot OCR Tesseract.js CDN থেকে engine load করে কাজ করবে; internet না থাকলে OCR চলবে না। Offline অবস্থায় Manual/Paste Data Entry, Data Vault এবং অন্যান্য local analysis ব্যবহার করা যাবে। OCR result Save করার আগে user verification বাধ্যতামূলক।

## 9. Final acceptance rule

Release only when the canonical GitHub workflow shows PASS for:

1. lockfile
2. dependency audit
3. typecheck
4. research validation
5. Vite build
6. Capacitor/Android build
7. APK integrity/hash
8. API 35 emulator install
9. app launch/PID smoke test

**এই ৯টি gate-এর সব PASS না হওয়া পর্যন্ত APK-কে final certified release বলা যাবে না।**

## Visual Analysis Final Hardening — 2026-10-05

The Analysis visual workspace has been hardened as a data-bound interface: the 12-card main layer follows the second reference composition, while the detail layer uses the first reference's information-dense presentation. Visual metrics are derived from the historical dataset and the existing research engines; decorative predictive-looking percentages are not used as future-win probabilities. Dashboard → Details → Deep Research → Full Functional Analysis remains wired.

See `VISUAL_ANALYSIS_FINAL_HARDENING_BN.md` for the exact mapping and verification status.
