# Personal Number Console — 4D HOSPITAL

এই পেজটি ব্যক্তিগত/manual number workspace। এটি 4D HOSPITAL-এর historical analysis engine-এর prediction result নয়।

## Features

- FIRST PRIZE
- SECOND PRIZE
- THIRD PRIZE
- SPECIAL
- প্রতিটি prize-এর জন্য একটি 4-digit primary number
- প্রতিটি prize-এর জন্য 12টি batch-number slot (10–12টি ব্যবহার করা যায়)
- Primary number Save
- Batch Save
- Prize workspace Lock / Unlock
- Local device persistence (`localStorage`)
- Animated frequency/heartbeat visual layer এবং rolling-number background
- Responsive mobile/desktop UI
- Admin-only access; non-admin users ফলাফল dashboard-এ ফেরত যায়

## Important security note

`LOCKED` এখানে edit-lock: locked অবস্থায় UI থেকে ওই workspace পরিবর্তন করা যায় না। এটি cryptographic secrecy বা tamper-proof security নয়। Sensitive data-এর জন্য production-grade encrypted storage/Keystore layer প্রয়োজন।
