# 4D HOSPITAL — Master Evidence Fusion Sensor v2

## উদ্দেশ্য
Final Result এখন 107 Core Analysis-এ থামে না। Canonical historical dataset থেকে একাধিক evidence family একত্রে arbitration করে:

`Raw Data → 107 Core → 28 Signal Sensor → Mathematical → Investigator → Advanced Research/FDR → Scientific Process Control → Validation/OOS → Master Evidence Fusion → Final Result`

## Sensor disposition
- **TAKE** — evidence families-এর সম্মিলিত support শক্তিশালী এবং conflict সীমিত।
- **WATCH** — evidence mixed/uncertain; final ranking-এ সতর্কতা দেখানো হয়।
- **DROP** — conflict/weakness বেশি; final result-এ promoted candidate হিসেবে রাখা হয় না।
- **INSUFFICIENT_DATA** — পর্যাপ্ত data নেই; system fabricated result তৈরি করে না।

## Redundancy rule
একই mathematical dependency বা একই underlying feature-এর বহু output-কে independent vote হিসেবে গণনা করা হয় না। Advanced research redundancy এবং Investigator warnings trace-এ থাকে।

## Candidate evidence passport
প্রতিটি candidate-এর সঙ্গে layer-level score, support/conflict count, reasons, warnings এবং source calculation version থাকে।

## গুরুত্বপূর্ণ সীমা
এটি historical research/evidence engine। কোনো specific future outcome-এর guarantee বা winning probability তৈরি করে না।
