## Change summary

## Scientific impact
- [ ] No change to statistical interpretation
- [ ] Mathematical formula changed
- [ ] Null model changed
- [ ] Multiple-testing/FDR changed
- [ ] OOS/leakage governance changed

## Validation
- [ ] Typecheck/build (where environment permits)
- [ ] Relevant regression audit
- [ ] Research-cycle E2E
- [ ] No new guarantee/predictive-certainty language

## Security
- [ ] No secrets/tokens added
- [ ] No personal/medical data added
