---
name: Research validity issue
about: Statistical, mathematical, leakage, null-model, or reproducibility concern
labels: research-validity
---

## Claim or analysis ID

## Why the claim may be invalid

## Dataset / source / time range

## Null model or validation concern

## Reproduction steps

Never include confidential or personally identifying data.
