---
name: Bug report
about: Reproducible technical defect
labels: bug
---

## Reproduction

## Expected behaviour

## Actual behaviour

## Dataset / analysis version

## Device / browser / Android version

## Logs or screenshots

Do not include passwords, tokens, patient data, or private personal information.
