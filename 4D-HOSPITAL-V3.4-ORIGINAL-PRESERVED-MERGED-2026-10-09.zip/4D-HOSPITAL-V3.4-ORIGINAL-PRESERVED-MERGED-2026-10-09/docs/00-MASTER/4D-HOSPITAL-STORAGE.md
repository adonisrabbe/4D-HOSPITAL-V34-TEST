# 4D HOSPITAL — Local-First Data Storage Policy

## Live data location
- **Android:** the live dataset is stored locally on the Android device in SQLite (`4d_hospital_data`). Gmail/Google Drive is NOT the live database.
- **Laptop/Desktop browser:** the live dataset is stored locally in IndexedDB. It remains on that laptop/browser profile unless the user clears site data or resets the browser/profile.
- The application does not require a cloud database for normal data storage.

## Backup policy
- Use the app's JSON export/restore as the portable backup mechanism.
- Keep at least two backups on separate storage (for example, the laptop plus an external drive).
- Google Drive/cloud storage may be used as a **backup copy**, not as the live database.

## Capacity
- There is no hard-coded 10,000-record ceiling in the storage layer.
- SQLite uses indexes for company/date/draw and digit fields; IndexedDB is used on web instead of localStorage.
- 10,000+ historical records are an intended operational scale. Larger datasets should be benchmarked against the 107-analysis workload before being treated as a certified performance limit.

## Safety behavior
- Invalid records are rejected instead of silently stored.
- Duplicate company/date/draw conflicts are rejected rather than silently overwriting another record.
- Restore/import uses a transaction and rolls back on failure.
- Imported IDs are remapped deterministically when collisions occur.
- If native SQLite is unavailable, the application falls back to local storage rather than requiring a remote database.

## Important limitation
Device-local storage is durable, but it is not an automatic backup. A device failure, browser profile deletion, app-data deletion, or factory reset can still destroy local-only data. Export backups are therefore required for long-term protection.
