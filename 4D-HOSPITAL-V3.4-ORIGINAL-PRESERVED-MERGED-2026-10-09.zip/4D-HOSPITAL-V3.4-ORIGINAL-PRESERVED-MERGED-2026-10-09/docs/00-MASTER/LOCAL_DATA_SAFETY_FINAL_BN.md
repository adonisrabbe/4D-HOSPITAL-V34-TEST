# 4D HOSPITAL — Local Data Safety / Final Release Note

আপনার চাওয়া অনুযায়ী 4D HOSPITAL-এর মূল ডাটা cloud database-এ নির্ভরশীল নয়।

- Android ফোনে live data → device-local SQLite.
- Laptop/Desktop web app-এ live data → device-local IndexedDB.
- Google Drive/Gmail → live database নয়; backup হিসেবে ব্যবহার করা যাবে।
- 10,000+ records-এর কোনো hard-coded storage limit নেই।
- Import/restore transactional; ভুল row হলে পুরো restore rollback হতে পারে।
- Duplicate company + date + draw number silently overwrite করা হয় না।
- নিয়মিত JSON backup রাখা বাধ্যতামূলক, কারণ local-only data device/browser data loss থেকে নিজে নিজে রক্ষা পায় না।

এই release ZIP-এ `node_modules` রাখা হয়নি। ফলে ZIP ছোট, portable এবং download/upload-এর জন্য উপযোগী। GitHub-এ `npm ci` lockfile থেকে dependencies পুনরায় install করবে।
