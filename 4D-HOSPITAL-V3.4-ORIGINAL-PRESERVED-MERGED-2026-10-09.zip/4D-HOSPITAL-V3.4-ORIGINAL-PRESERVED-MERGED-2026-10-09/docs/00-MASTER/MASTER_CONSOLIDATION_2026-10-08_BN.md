# 4D HOSPITAL — Master Consolidation Record — 2026-10-08

## Canonical merge
এই release-এ একটি মাত্র canonical source tree রাখা হয়েছে। চারটি project package-এর overlap থেকে সবচেয়ে পূর্ণ source হিসেবে **MASTER-FUSION-SENSOR-V3** codebase নেওয়া হয়েছে।

### Integrated sources
1. **107 Analysis A→Z** — canonical 107 analysis contract, four-part WHAT/WHY/NEXT/FINAL workspace, mathematical/FDR verification and research-cycle controls.
2. **Visual Set & Audit** — dashboard/part/result/detail reference images and visual verification record.
3. **Master Fusion Sensor V3** — Master Evidence Fusion, Final Result Engine and Result Miss Autopsy.
4. **Local Data Repaired** — local-first storage, SQLite/IndexedDB durability and data-safety documentation.

## Count truth
- **107** = canonical independent public analysis contracts.
- **28** = active signal/sensor layer; these overlap with the 107 and are not counted as 28 additional independent analyses.
- **6** = meta-validation layers.
- **1** = Master Evidence Fusion / Final Result decision surface; it is a meta-analysis layer, not a fabricated 108th independent statistical test.

Therefore this release deliberately does **not invent a fake 108th independent analysis** merely to make the number say 108. If the product requirement is exactly 108 independent analyses, the specification of that 108th method must be defined and independently validated before it is added.

## Four-page analysis contract
Every canonical analysis is presented as:
1. মূল বিশ্লেষণ / WHAT
2. কেন পরিবর্তন হলো / WHY
3. পরবর্তীতে কীভাবে পরিবর্তন হতে পারে / NEXT
4. চূড়ান্ত বিশ্লেষণ ফলাফল / FINAL

Insufficient data is surfaced explicitly; fabricated results are not generated.

## Final Result / sensor flow
`Canonical Data → 107 Core → 28 Signal Sensors → Mathematical/Investigator/Advanced Research → Validation/OOS → Master Evidence Fusion → Final Result → Result Miss Autopsy`

The Final Result layer records traceability and historical evidence. It is not a winning-probability or future-guarantee engine.

## Storage policy
- Android: encrypted native SQLite is the primary live store.
- Web/laptop: IndexedDB is the primary live store.
- JSON backup/restore remains available for portability.
- Cloud storage is a backup destination, not the live database.
- There is no fixed 10,000-row ceiling in the storage design; actual capacity depends on the device/database environment.

## Release verification boundary
Source-level audits included in this package are authoritative for the checks they actually execute. A clean production build/APK and real Android-device test require a dependency-complete, network-enabled CI or local build environment. This release therefore never labels an unperformed APK/device test as PASS.
