# Visual Reference Set

এই folder-এ 4D HOSPITAL-এর consolidated visual references রাখা হয়েছে। এগুলো decorative data নয়; UI implementation যাচাই ও design regression-এর reference.

মূল app-এর runtime data source historical dataset এবং analysis engines; reference PNG-গুলো runtime result হিসেবে ব্যবহৃত হয় না।
