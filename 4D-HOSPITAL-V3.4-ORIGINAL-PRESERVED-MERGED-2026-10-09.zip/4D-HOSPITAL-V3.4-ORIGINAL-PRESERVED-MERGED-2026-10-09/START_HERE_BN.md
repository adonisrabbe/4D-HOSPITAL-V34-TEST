# 4D HOSPITAL — Start Here

## প্রথম release step — বর্তমান source truth

এই ZIP/source tree-তে genuine `package-lock.json` আছে। আলাদা lockfile তৈরি করার দরকার নেই। GitHub repository root-এ source file upload/commit করার পর **4D HOSPITAL - Validate and Build Android APK** workflow চালান। প্রথম job lockfile-এর exact version ও integrity metadata যাচাই করে; পরের jobs একই lockfile ব্যবহার করে `npm ci` চালাবে।

যদি কোনো কারণে `package-lock.json` অনুপস্থিত থাকে, আগে **Bootstrap package-lock.json** নামের আলাদা recovery workflow চালিয়ে generated lockfile commit করুন; তারপর canonical release workflow চালান। বর্তমান ZIP-এর জন্য এটি প্রয়োজন নয়।

**বর্তমান সত্য:** source/static audit-এ local PASS আছে, কিন্তু এই sandbox-এ npm registry DNS `EAI_AGAIN` হওয়ায় `npm ci`, Vite build, APK build এবং emulator test এখনও সম্পন্ন হয়নি। APK-কে verified বলা যাবে না যতক্ষণ canonical GitHub Actions সব release gate PASS না করে।

## Canonical validation/build flow

```bash
npm ci
npm run validate
npm run build
```

Android release-এর authoritative workflow:

`.github/workflows/build-and-validate.yml`

এটি `cap add/sync → Android audit → Gradle assembleDebug → APK integrity/hash → API 35 emulator smoke test` পর্যন্ত যায়।

## Research Cycle

Sidebar → 📐 বিশ্লেষণ → 🔒 Research Cycle

1. Current company ও historical data প্রস্তুত করুন।
2. Batch size ও candidate pool দিন।
3. `LOCK NEW PREDICTION` চাপুন।
4. Actual batch আসার আগে snapshot সংরক্ষিত থাকবে।
5. Actual batch একসঙ্গে paste করুন।
6. `VALIDATE & TRACE` চাপুন।
7. Exact/digit/position match ও mismatch diagnostics দেখুন।
8. যাচাইয়ের পরে `APPLY TO DATASET` চাপুন।

## Important

এই app historical mathematical/statistical analysis ও validation করে। কোনো model ভবিষ্যৎ 4D ফল নিশ্চিত করে না।

OCR **online-only**: internet থাকলে Tesseract.js CDN থেকে engine load হবে; internet না থাকলে OCR চলবে না। Offline অবস্থায় Manual/Paste Data Entry ব্যবহার করুন।
