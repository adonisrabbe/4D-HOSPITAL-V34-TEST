# 4D HOSPITAL — Historical 4-Digit Numerical Research Laboratory

> **Research software, not a guaranteed prediction system.**

4D HOSPITAL is an offline/local-first historical 4-digit data analysis and validation platform. It is designed to make calculations, evidence, validation, failure modes, and reproducibility explicit.

## What “100% implemented” means

In this project, **100% implemented means the declared software roadmap and its engineering controls are implemented in the codebase and covered by the project's available audits/regression checks.**

It does **not** mean:

- 100% scientific proof that any future 4-digit outcome is predictable;
- a guaranteed future result;
- a guaranteed winning probability;
- that a high evidence/validation score is a probability of a future outcome;
- that all 107 catalogued analyses are independently proven predictive models.

## Scientific position

The platform follows:

**Data → Analysis → Evidence → Validation → Reproducibility**

Historical patterns, statistical significance, model scores, backtests, OOS results, FDR-adjusted findings, Bayesian diagnostics, conformal coverage, or evidence grades are interpreted only within their declared assumptions and sample sizes. Passing a research gate means the **research process** satisfied its declared controls; it does not prove that a random future draw can be predicted.

## Prediction/model screens

Some screens retain prediction/model terminology because they evaluate candidate signals and historical model performance. These outputs must be treated as **research candidates and validation diagnostics**, not guaranteed future numbers.

## Evidence hierarchy

A finding should move through progressively stronger controls:

Observation → Hypothesis → Statistical Test → Null Model → Effect Size → Multiple-Testing Control → Stability → Chronological OOS → Blind OOS → Reproducibility

No single pattern or model is automatically treated as independent proof.

## Reproducibility

Research runs can record dataset fingerprints, analysis/protocol versions, parameters, environment information, result hashes, and a tamper-evident run ledger. Blind OOS controls are intended to prevent discovery information from silently changing the confirmatory test.

## Scope and limitations

This repository is a historical mathematical/statistical research platform. It is not a lottery guarantee service, financial advice service, or medical decision system. Real-world conclusions remain subject to data quality, sampling assumptions, model assumptions, statistical uncertainty, and independent validation.

## Release honesty

The repository distinguishes **software verification** from **scientific truth**. A passing software audit demonstrates that the tested implementation behaved according to its specified checks. It does not manufacture evidence that future 4-digit outcomes are predictable.

## Final release certification boundary

The current source bundle includes a committed, genuine `package-lock.json` (lockfile v3). The canonical GitHub workflow verifies the lockfile and its integrity metadata, hands the same file to validation/performance/Android jobs, then runs `npm ci`, TypeScript validation, research regression checks, the Vite production build, Android/Gradle APK build, APK SHA-256/integrity checks, and an API 35 emulator install/launch test. If the lockfile is missing in a future repository copy, run the separate **Bootstrap package-lock.json** workflow, commit the generated lockfile, and then run the canonical build. The APK is considered certified only when all required GitHub Actions gates PASS.

The included 1M performance check is a **synthetic stress-harness check**, not a certification that all 107 analyses complete within a fixed budget on every Android device.

## Current source release package — V3.3 (2026-10-09)

This release uses the root project as the single canonical source tree. The duplicate `hosp/` tree and bundled `node_modules/` were removed from the release package. Install dependencies from the lockfile before building:

```bash
npm ci
npm run typecheck
npm run build
```

See `RELEASE_GATE_REPORT_V3.3_BN.md` for the current verification record and limitations. `AUDIT_DOCUMENT_INDEX_BN.md` explains which reports are current versus historical. Older dated audit files document earlier source states and are not the authority for the current package; the current bundle contains `package-lock.json`.

## Offline behavior and local accounts

- The web/PWA shell is cached by a service worker after the first successful online visit; open the GitHub Pages app once while connected before relying on it offline. The native Android APK bundles its app shell locally.
- Result data is stored locally per device/browser: IndexedDB for web/PWA and SQLite for native Android. It is not automatically synchronized between a laptop and phone; use an encrypted backup/restore to move data.
- OCR is intentionally online-only because its Tesseract engine/model are loaded from a CDN. Manual/Paste data entry and local analysis do not require the OCR CDN.
- Admin and managed-user login is device-local. It is not a cloud identity system. Invite links only validate on the same browser/device where the local invite token was created; use local account creation separately on another device.
- If the durable result store cannot initialize or a write fails, the app stops normal editing and offers an encrypted recovery snapshot rather than silently pretending the data was saved.

## Final Result Engine V1 (2026-10-07)

The Final Result page now uses a deterministic live-result layer with four-set surfaces for Hot/Cool 4-Digit, Pair/Hot Pair/Cool Pair, Single/Hot Single/Cool Single, and Hot/Cool 3-Digit. Results are derived from the current canonical dataset and the 107-core research/validation state; no random or hardcoded candidate values are injected. See `FINAL_RESULT_ENGINE_V1_BN.md` for the exact contract and scientific boundary.


## Visual System v1.6
The visual system follows the supplied dark analytical dashboard references while keeping live charts data-driven. The canonical surface is 11 Parts × 4 workflow pages, covering 107 analyses. Reference assets are stored in `public/design-reference/`.

## Master Result — 10-Set Visual Research Board

The Master Result keeps the canonical 5D/4D/3D/2D/1D evidence lanes and adds a compact **10 Evidence Bundle** presentation layer. Each bundle shows 5D, 4D, 3D, 2D, 1D, rank, HOT/COLD, evidence score, consensus, conflict and a clickable visual explanation of how the result was formed. The manual number box supports edit/lock/save without changing sensor calculations. See `MASTER_RESULT_10SET_VISUAL_UPGRADE_BN.md`.

## Master Result Sheet
The final research surface presents 5D (derived composite), 4D, 3D, 2D and 1D evidence bands with traceability to the dataset fingerprint, 107-analysis run, 28 signal modules and fusion layer. It is not a future-outcome guarantee.
