# 4D HOSPITAL — Visual Analysis Layer Architecture

## উদ্দেশ্য
দ্বিতীয় visual concept-এর মতো analysis dashboard-কে research navigation-এর প্রথম স্তর করা হয়েছে। প্রতিটি analysis-এর visual motif আলাদা, কিন্তু brand/system একই।

## 3-Layer navigation
1. **Layer 1 — Visual Analysis Studio**
   - 12টি প্রধান analysis dashboard tile
   - LSTM → waves
   - Markov → matrix/network
   - Genetic → DNA/evolution
   - Cluster → 3D particle clusters
   - Backtest → candle/timeline
   - Sliding Window → layered windows
   - Consensus → radial gauge
   - Alerts → alert HUD
   - Performance → gauge
   - Neighbor Digits → orbit
   - Deep Analysis → 3D surface
   - Predictions → 4D globe

2. **Layer 2 — Analysis Detail**
   - dataset summary
   - 4D value count
   - unique value count
   - last date
   - Overview / Evidence / Calculation / Validation / OOS / Raw Data / Report navigation
   - `GO DEEPER` action

3. **Layer 3 — Deep Research**
   - Evidence
   - Calculation
   - Validation
   - OOS
   - Raw Data
   - Report
   - `OPEN FULL FUNCTIONAL ANALYSIS` action

## গুরুত্বপূর্ণ বৈজ্ঞানিক নীতি
Visual dashboard-এর decorative metrics কোনো ভবিষ্যৎ winning probability নয়। প্রকৃত calculation/result বিদ্যমান analysis engine থেকে আসবে। Deep layer-এ evidence, calculation trace এবং validation-কে আলাদা রাখা হয়েছে।

## Zoom / responsive লক্ষ্য
- CSS/SVG visual ব্যবহার করা হয়েছে; raster screenshot নয়।
- Mobile/desktop breakpoint রাখা হয়েছে।
- reduced-motion preference সম্মান করা হবে।
- মূল dashboard card ও detail workspace responsive রাখা হয়েছে।

## Release note
এই layer source code-এ যুক্ত হয়েছে। Dependency install না থাকায় local production Vite build এখানে চালানো যায়নি; genuine `package-lock.json` এখনও release gate-এর blocker।
