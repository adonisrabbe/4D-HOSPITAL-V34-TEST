> **Historical snapshot — superseded for current release instructions.** This file records an earlier project state. For the current lockfile, workflow, and release-gate status, use `CURRENT_RELEASE_TRUTH_BN.md` and `RELEASE_GATE_REPORT_V3.2_BN.md`.

# 4D Hospital — A-to-Z Deep Audit & Corrections — 2026-09-27

## Audit scope
- 107 public analysis catalog and executable runner
- 28 active signals and advanced model layer
- six validation layers and leakage-safe research cycle
- additive cumulative data merge and result persistence
- native SQLite encryption + legacy DB migration
- web IndexedDB durability for large datasets
- crash/stability hardening
- OCR network-independence guard
- Number Theory & Mathematical Laboratory
- source-tree/config consistency

## Corrections made in this audit
1. Fixed the Mathematical Laboratory's Practical Number classifier to use the standard prime-factor prefix-sigma criterion.
2. Fixed Mathematical Evidence handling for numeric properties (digit sum, digital root, tau, sigma, phi, Mobius): they are now reported as numeric means/drift instead of being incorrectly treated as boolean true/false rates.
3. Ensured the Mathematical Laboratory receives observations in newest-first order before calculating its recent window.
4. Reworked the unused large-data compatibility store so it no longer writes the master dataset to localStorage; it now uses IndexedDB with transactional writes.
5. Corrected web dataset metadata to report `indexeddb` rather than `localStorage-fallback`.
6. Removed stale `src/` paths from the operational `filelist.txt`, `components.json`, and `tsconfig.audit-run.json` configuration.

## Verification
- 107 analysis deep audit: PASS
- 28 signal/model audit: PASS
- research layers: PASS
- runtime contract: PASS
- research-cycle E2E: PASS
- storage/security: PASS
- stability hardening: PASS
- mathematical research audit: PASS
- static audit: PASS
- changed TypeScript files: PASS
- duplicate `src/` tree: absent
- ZIP integrity: verified after packaging

## Remaining environment gate
`package-lock.json` is still not present because this sandbox has no npm registry/cache access. It must be generated in a networked build environment and committed; no fake lockfile/integrity data is being fabricated. Android SDK/device E2E and fully bundled native offline OCR also require a real Android build/test environment.
