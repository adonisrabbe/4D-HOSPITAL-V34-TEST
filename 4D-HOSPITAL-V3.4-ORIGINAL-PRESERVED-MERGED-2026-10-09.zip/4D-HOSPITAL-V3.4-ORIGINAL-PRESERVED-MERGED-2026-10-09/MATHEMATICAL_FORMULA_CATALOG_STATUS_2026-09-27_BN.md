# Mathematical Formula Catalog Status — 2026-09-27

## Implemented executable Mathematical Laboratory
61 deterministic properties/features are currently implemented and audited.

### Families
- Prime and prime relations
- Digit-pattern properties
- Polygonal/power/sequence properties
- Divisor/number-theory properties
- Collatz/Diophantine/Goldbach structural checks
- Aliquot/primorial relations

## Important interpretation rule
A mathematical property is first a deterministic feature. It becomes research evidence only after historical prevalence, recent-vs-baseline comparison, chronological stability and leakage-safe OOS validation. It is not automatically an independent vote and never constitutes a guaranteed future result.

## User-supplied concepts not forced into active signals
Riemann Hypothesis, Fermat's Last Theorem, Goldbach/Twin Prime conjectures and similar reference-level mathematics are kept as mathematical references rather than being presented as direct 4D outcome signals.
