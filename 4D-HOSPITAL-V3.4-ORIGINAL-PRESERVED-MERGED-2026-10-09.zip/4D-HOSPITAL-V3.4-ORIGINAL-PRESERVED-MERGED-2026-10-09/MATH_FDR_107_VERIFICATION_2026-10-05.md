# Mathematical / Null Model / FDR / 107-Analysis Verification — 2026-10-05

## Result

**PASS**

This release now contains a deterministic regression suite covering:

- 63 independent known-value mathematical cases, including edge cases and leading-zero 4D representation.
- All 61 entries in the Mathematical Property Catalog.
- Exactly 107 public analysis IDs, each executed once with non-empty output and no `REQUIRES_FIX` status on a sufficiently large valid dataset.
- Real recent-vs-baseline permutation null testing.
- Exact two-sided binomial p-values for the even-rate hypothesis.
- Mutual-information permutation p-value.
- 55 binary mathematical properties with real recent-vs-baseline permutation p-values.
- Benjamini-Hochberg FDR correction over all hypotheses that have a valid p-value.

## Null-model correction

The previous mean-value permutation was scientifically invalid because permuting observations leaves the sample mean unchanged. It has been replaced by a **group-label permutation test**: recent observations and baseline observations are pooled, labels are randomized while preserving group sizes, and the observed recent-minus-baseline statistic is compared with that null distribution.

The two-sided empirical p-value uses the finite-simulation correction `(extreme + 1) / (simulations + 1)`.

## FDR correction

FDR no longer creates p-values from qualitative Bayesian status labels. It now uses actual p-values from:

1. exact binomial testing for the even-rate hypothesis;
2. permutation testing for position-1/position-2 mutual information;
3. recent-vs-baseline permutation tests for binary mathematical properties.

Benjamini-Hochberg q-values are then calculated and hypotheses with `q <= 0.05` are marked rejected. Numeric mathematical features are deliberately excluded from this binary occurrence-rate family because they require a separate null hypothesis.

## Mathematical fixes found by the verification suite

The suite detected and the repair corrected:

- `Möbius μ(0)` incorrectly returning `+1`; it now returns `0`.
- Octahedral numbers using `k(2k²-1)/3`; corrected to the standard `k(2k²+1)/3`.
- Factorion digit handling now evaluates the integer's actual decimal digits rather than adding artificial `0!` terms from four-character padding.

## Verification commands

- `npm run audit:math-107`
- `npm run audit:advanced-research`
- `npm run audit:mathematical-research`
- `npm run audit:investigator`
- `npm run test:research-cycle`

All of the above passed in the repair environment.

## Scientific boundary

Passing these tests verifies **correct execution and statistical plumbing**, not that historical 4D data contain genuine predictive information. The app continues to treat these outputs as evidence/diagnostics rather than guaranteed future predictions.
