# Dependency Reproducibility — Current State (2026-10-09)

- `package.json` uses exact dependency versions; open-ended `latest`, `*`, and version ranges are rejected by the dependency-lock audit.
- `.npmrc` enables exact dependency saves and strict Node engine checking.
- This current source bundle contains a committed `package-lock.json` v3.
- The CI preflight verifies 66 exact direct dependencies plus all 421 lock entries for version, HTTPS resolution URL, and integrity metadata before installation.
- Release jobs use `npm ci` against the same canonical lockfile artifact. Do not run `npm install` as a substitute for `npm ci` during a normal release.
- If the lockfile is absent in a future copy, use the separate manual `Bootstrap package-lock.json` workflow to generate and commit it; then run the canonical release workflow.
- Current sandbox limitation: `registry.npmjs.org` fails DNS with `EAI_AGAIN`, so the live install/build cannot be verified here. This is an environment network block, not a passed release gate.
